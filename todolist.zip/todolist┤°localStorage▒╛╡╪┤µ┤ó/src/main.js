// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Vuex from 'vuex'
import VueComp from './components/loading/loading.vue' // 引入自定义组件
Vue.use(Vuex)
Vue.use(VueComp) // 使用自定义组件
Vue.component('VueComp', VueComp) // 初始化自定义组件
Vue.config.productionTip = false

/* eslint-disable no-new */
// 把整个APP.vue挂载到index.html上
new Vue({
  el: '#app',
  router,
  components: {
    App,
    VueComp // 全局声明自定义组件
  },
  template: '<App/>'
})
