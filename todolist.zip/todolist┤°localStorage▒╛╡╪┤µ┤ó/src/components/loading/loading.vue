<template>
  <div>
    <div>
      汪渊无敌
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
Vue.component('componA', {
  props: ['title'],
  data () {
    return {
      name: '张三',
      age: 19
    }
  },
  methods: {
    addNum: function () {
      console.log('相加')
    },
    spliceNum: () => {
      console.log('相减')
    }
  },
  computed: {
    sex: function () {
      return this.name
    }
  }
})
export default {
}
</script>
