<template>
  <div class="hello">
    <h1>{{msg}}</h1>
    <button @click="onClickMe">子组件按钮</button>
    <h1>{{msgFromParent}}</h1>
    <!-- <button @click="toDetail">查看详情</button> -->
    <!-- <test></test> -->
  </div>
</template>

<script>
import Vue from 'vue'
Vue.component('test', {
  template: `
  <div>我是自定义全局组建2</div>
  `
})
export default {
  name: 'componentsA',
  data () {
    return {
      msg: 'hello from componentA'
    }
  },
  props: ['msgFromParent', 'index'],
  methods: {
    onClickMe: function () {
      // this.$emit('children-tell-me', this.msg)
      this.$emit('children-tell-me', '/detail')
    }
  }
}
</script>

<style scoped>
</style>
