<template>
  <div class="content">
    <h1>{{msg}}</h1>
    <button @click="back">返回上一页</button>
    <button @click="goDetails">跳转到details页面</button>
    <vue-comp></vue-comp>
  </div>
</template>

<script>
// 定义全局组件
// Vue.component('todo-list', {
//   template: '<li>{{msg}}</li>'
// })

// 定义局部组件
// var todoirem = {
//   template: '<li>{{msg}}</li>'
// }
export default {
  name: 'Detail',
  data: function () {
    return ({
      msg: 'it is detail page'
    })
  },
  methods: {
    back () {
      this.$router.back()
    },
    goDetails () {
      this.$router.push({
        path: '/details'
      })
    }
  }
}
</script>

<style scoped>
</style>
