<template>
  <div class="detail-wrapp">
    <div>
      {{msg}}
    </div>
    <ul v-for="(item,name,index) in listArr"
        :key="index">
      <li>{{index}}---{{item.name}}</li>
    </ul>
    <vue-comp></vue-comp>
    <test></test>
    <compc></compc>
    <button @click="showMsg"
            class="{eatStyle: isEat}">吃大餐</button>
  </div>
</template>

<script>
// 在实例中全局注册组件
import Vue from 'vue'
Vue.component('test', {
  template: `
  <div>我是自定义全局组建2</div>
  `
})
// 在实例中局部注册组件
let compc = {
  template: `
    <div>我是自定义局部组建3</div>
  `
}
export default {
  name: 'Dtails',
  components: {
    compc
  },
  data: function () {
    return {
      name: 'details',
      age: 12,
      msg: '我爱你大阿宝',
      listArr: [
        {
          name: '陈阿宝'
        },
        {
          name: '汪大渊'
        }
      ],
      isEat: true
    }
  },
  methods: {
    showMsg () {
      this.msg = '大阿宝 俺带你吃大餐'
    }
  },
  mounted: () => {
  }
}
</script>
