<template>
  <div class="hello">
    <!-- <h1 v-text="title"></h1> -->
    <h1>{{title}}</h1>
    <input type="text"
           v-model="newItem"
           @keyup.enter="addNewItem">
    <button @click="clear">清空本地存储</button>
    <ul>
      <li v-for="(item , index) of items"
          :key="item.id"
          :index="index"
          @click="isTollege(index)"
          :class="{finished: item.isFinished}">{{item.label}}</li>
    </ul>
    <h1>{{this.childtellme}}</h1>
    <component-a :msgFromParent="msgFromParent"
                 v-on:children-tell-me="listenToMyBoy"></component-a>
    <test></test>
  </div>
</template>

<script>
import Store from '../store/store'
import componentA from './componentA'
export default {
  name: 'HelloWorld',
  components: {
    componentA
  },

  // 绑定视图数据
  data () {
    return {
      newItem: '',
      childtellme: '',
      msgFromParent: 'you die',
      title: 'this is a todo list',
      items: Store.fetch()
    }
  },

  // 监听
  watch: {
    items: {
      handler: function (items) {
        Store.save(items)
      },
      deep: true
    }
  },

  // 方法体
  methods: {// methods computed watch的简写形式是这样的 methods: {} data的是 data(){}
    isTollege: function (index) {
      // item.isFinished = !item.isFinished
      this.items.splice(index, 1)
    },

    // 添加
    addNewItem () {
      if (this.items === '') {
        this.items = []
      }
      let id = this.items.length + 1
      this.items.push({
        id: id,
        label: this.newItem,
        isFinished: false
      })
      localStorage.setItem('newItem', {
        id: id,
        label: this.label,
        isFinished: false
      })
      this.newItem = ''
    },

    // 删除
    clear: function () {
      Store.clear()
      this.items = ''
    },

    // 子传父监控操作
    listenToMyBoy: function (msg) {
      // this.childtellme = msg
      this.$router.push({
        path: '/detail'
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
ul {
  list-style-type: none;
  padding: 0;
}
.finished {
  cursor: pointer;
  text-decoration: underline;
}
a {
  color: #42b983;
}
</style>
