// window.localStorage状态管理工具
const STORAGE_KEY = 'todos-vuejs'
export default {
  // 取值
  fetch () {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '[]')
  },
  // 存值
  save (items) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  },
  // 清除存储
  clear () {
    window.localStorage.removeItem(STORAGE_KEY)
  }
}
