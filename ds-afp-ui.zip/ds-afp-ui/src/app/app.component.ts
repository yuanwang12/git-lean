import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { $ } from 'protractor';

@Component({
  selector: 'ds-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ds-afp-ui';

  constructor(private route: ActivatedRoute, private router: Router) {}
  public dictionaryServiceDemo(): void {
    alert('dictionaryServiceDemo');
    this.router.navigate(['/']);
  }

  public enumServiceDemo(): void {
    alert('enumServiceDemo');
    this.router.navigate(['/platform/enum/enum-service-demo']);
  }

  public userInfoServiceDemo(): void {
    this.router.navigate(['/platform/basic-data/user-info/user-info-demo']);
  }

  public openNewPage(): void {
    document.getElementById('flag').style.display = 'none';
    document.getElementById('utilty').style.display = 'block';
  }
}
