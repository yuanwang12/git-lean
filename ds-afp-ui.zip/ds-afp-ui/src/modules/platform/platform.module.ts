import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { TreeViewModule } from '@progress/kendo-angular-treeview';

import {
    OrgNodeComboTreeDemoComponent
} from './basic-data/org-node/org-node-combo-tree-demo/org-node-combo-tree-demo.component';
import {
    OrgNodeComboTreeComponent
} from './basic-data/org-node/org-node-combo-tree/org-node-combo-tree.component';
import {
    OrgNodeServiceDemoComponent
} from './basic-data/org-node/org-node-service-demo/org-node-service-demo.component';
import { OrgNodeService } from './basic-data/org-node/org-node.service';
import { OrgNodeServiceImpl } from './basic-data/org-node/org-node.service.impl';
import {
    UserInfoServiceDemoComponent
} from './basic-data/user-info/user-info-service-demo/user-info-service-demo.component';
import { UserInfoService } from './basic-data/user-info/user-info.service';
import { UserInfoServiceImpl } from './basic-data/user-info/user-info.service.impl';
import {
    ComboTreeDemoComponent
} from './common/component/combo-tree-demo/combo-tree-demo.component';
import { ComboTreeComponent } from './common/component/combo-tree/combo-tree.component';
import {
    SelectgroupDemoComponent
} from './common/component/selectgroup-demo/selectgroup-demo.component';
import { SelectgroupComponent } from './common/component/selectgroup/selectgroup.component';
import {
    ConfigServiceDemoComponent
} from './config/config-service-demo/config-service-demo.component';
import { ConfigService } from './config/config.service';
import { ConfigServiceImpl } from './config/config.service.impl';
import {
    DicsDropdownListDemoComponent
} from './dictionary/dics-dropdown-list-demo/dics-dropdown-list-demo.component';
import {
    DicsDropdownListComponent
} from './dictionary/dics-dropdown-list/dics-dropdown-list.component';
import {
    DicsSelectgroupDemoComponent
} from './dictionary/dics-selectgroup-demo/dics-selectgroup-demo.component';
import { DicsSelectgroupComponent } from './dictionary/dics-selectgroup/dics-selectgroup.component';
import {
    DictionaryPipeDemoComponent
} from './dictionary/dictionary-pipe-demo/dictionary-pipe-demo.component';
import {
    DictionaryServiceDemoComponent
} from './dictionary/dictionary-service-demo/dictionary-service-demo.component';
import { DictionaryPipe } from './dictionary/dictionary.pipe';
import { DictionaryService } from './dictionary/dictionary.service';
import { DictionaryServiceImpl } from './dictionary/dictionary.service.impl';
import {
    EnumDropdownListDemoComponent
} from './enum/enum-dropdown-list-demo/enum-dropdown-list-demo.component'; // 枚举下拉demo
import { EnumDropdownListComponent } from './enum/enum-dropdown-list/enum-dropdown-list.component'; // 枚举下拉组件
import { EnumPipeDemoComponent } from './enum/enum-pipe-demo/enum-pipe-demo.component'; // 枚举过滤demo
import {
    EnumSelectgroupDemoComponent
} from './enum/enum-selectgroup-demo/enum-selectgroup-demo.component';
import { EnumSelectgroupComponent } from './enum/enum-selectgroup/enum-selectgroup.component';
import { EnumServiceDemoComponent } from './enum/enum-service-demo/enum-service-demo.component';
import { EnumPipe } from './enum/enum.pipe'; // 枚举过滤
import { EnumService } from './enum/enum.service';
import { EnumServiceMock } from './enum/enum.service.mock';
import { InitServiceDemoComponent } from './init/init-service-demo/init-service-demo.component';
import { InitServiceImpl } from './init/init-service.impl';
import { InitService } from './init/init.service';
import { KendoDemoComponent } from './kendoui/kendo-demo/kendo-demo.component';
import { PlatformRoutingModule } from './platform-routing.module';
import { UtilityDemoComponent } from './common/utility/utility-demo/utility-demo.component';

@NgModule({
  imports: [
    CommonModule,
    PlatformRoutingModule,
    DropDownsModule,
    FormsModule,
    TreeViewModule,
    DateInputsModule,
    InputsModule
  ],
  declarations: [
    UserInfoServiceDemoComponent,
    ConfigServiceDemoComponent,
    KendoDemoComponent,
    OrgNodeServiceDemoComponent,
    ConfigServiceDemoComponent,
    EnumServiceDemoComponent,
    DictionaryServiceDemoComponent,
    OrgNodeComboTreeComponent,
    OrgNodeComboTreeDemoComponent,
    InitServiceDemoComponent,
    EnumDropdownListComponent,
    EnumDropdownListDemoComponent,
    EnumPipe,
    EnumPipeDemoComponent,
    EnumSelectgroupComponent,
    DictionaryPipe,
    DictionaryPipeDemoComponent,
    ComboTreeComponent,
    ComboTreeDemoComponent,
    SelectgroupComponent,
    DicsSelectgroupDemoComponent,
    SelectgroupDemoComponent,
    DicsDropdownListComponent,
    DicsDropdownListDemoComponent,
    DicsSelectgroupComponent,
    EnumSelectgroupDemoComponent,
    UtilityDemoComponent
  ],
  providers: [
    { provide: UserInfoService, useClass: UserInfoServiceImpl },
    { provide: ConfigService, useClass: ConfigServiceImpl },
    { provide: EnumService, useClass: EnumServiceMock },
    { provide: InitService, useClass: InitServiceImpl },
    { provide: OrgNodeService, useClass: OrgNodeServiceImpl },
    { provide: DictionaryService, useClass: DictionaryServiceImpl }
  ]
})
export class PlatformModule {}
