import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {
    OrgNodeComboTreeDemoComponent
} from './basic-data/org-node/org-node-combo-tree-demo/org-node-combo-tree-demo.component';
import {
    OrgNodeServiceDemoComponent
} from './basic-data/org-node/org-node-service-demo/org-node-service-demo.component';
import {
    UserInfoServiceDemoComponent
} from './basic-data/user-info/user-info-service-demo/user-info-service-demo.component';
import {
    ComboTreeDemoComponent
} from './common/component/combo-tree-demo/combo-tree-demo.component';
import {
    SelectgroupDemoComponent
} from './common/component/selectgroup-demo/selectgroup-demo.component';
import {
    ConfigServiceDemoComponent
} from './config/config-service-demo/config-service-demo.component';
import {
    DicsDropdownListDemoComponent
} from './dictionary/dics-dropdown-list-demo/dics-dropdown-list-demo.component';
import {
    DicsSelectgroupDemoComponent
} from './dictionary/dics-selectgroup-demo/dics-selectgroup-demo.component';
import {
    DictionaryPipeDemoComponent
} from './dictionary/dictionary-pipe-demo/dictionary-pipe-demo.component';
import {
    DictionaryServiceDemoComponent
} from './dictionary/dictionary-service-demo/dictionary-service-demo.component';
import {
    EnumDropdownListDemoComponent
} from './enum/enum-dropdown-list-demo/enum-dropdown-list-demo.component'; // 基于枚举下拉demo
import { EnumPipeDemoComponent } from './enum/enum-pipe-demo/enum-pipe-demo.component'; // 枚举过滤demo
import { EnumSelectgroupDemoComponent } from './enum/enum-selectgroup-demo/enum-selectgroup-demo.component'; // 枚举selectgroup demo
import { UtilityDemoComponent } from './common/utility/utility-demo/utility-demo.component'; // utility工具类demo
import { EnumServiceDemoComponent } from './enum/enum-service-demo/enum-service-demo.component';
import { InitServiceDemoComponent } from './init/init-service-demo/init-service-demo.component';
import { KendoDemoComponent } from './kendoui/kendo-demo/kendo-demo.component';

const routes: Routes = [
  {
    // platform/basic-data
    path: 'basic-data',
    children: [
      {
        // platform/basic-data/user-info
        path: 'user-info',
        children: [
          {
            // platform/basic-data/user-info/user-info-demo
            path: 'user-info-demo',
            component: UserInfoServiceDemoComponent
            // pathMatch: 'full'
          },
          {
            path: '',
            redirectTo: 'user-info-demo',
            pathMatch: 'full'
          }
        ]
      },
      {
        // platform/basic-data/org-node
        path: 'org-node',
        children: [
          {
            // platform/basic-data/org-node/org-node-service-demo
            path: 'org-node-service-demo',
            component: OrgNodeServiceDemoComponent
          },
          {
            // platform/basic-data/org-node/org-node-combo-tree-demo
            path: 'org-node-combo-tree-demo',
            component: OrgNodeComboTreeDemoComponent
          }
        ]
      },
      {
        path: '',
        redirectTo: 'user-info',
        pathMatch: 'full'
      }
    ]
  },
  {
    // platform/dictionary
    path: 'dictionary',
    children: [
      {
        // platform/dictionary/ds-dictionary-pipe-demo
        path: 'ds-dictionary-pipe-demo',
        component: DictionaryPipeDemoComponent
      }
    ]
  },
  {
    // platform/config/config-service-demo
    path: 'config/config-service-demo',
    component: ConfigServiceDemoComponent
  },
  {
    // platform/common
    path: 'common',
    children: [
      {
        // platform/common/ds-combo-tree-demo
        path: 'ds-combo-tree-demo',
        component: ComboTreeDemoComponent
      }
    ]
  },
  {
    // platform/enum/enum-service-demo
    path: 'enum/enum-service-demo',
    component: EnumServiceDemoComponent
  },
  {
    // platform/dictionary/dictionary-service-demo
    path: 'dictionary/dictionary-service-demo',
    component: DictionaryServiceDemoComponent
  },
  {
    // platform/init/init-service-demo
    path: 'init/init-service-demo',
    component: InitServiceDemoComponent
  },
  {
    // platform/dictionary/dics-dropdown-list-demo
    path: 'dictionary/dics-dropdown-list-demo',
    component: DicsDropdownListDemoComponent
  },
  {
    path: 'enum/enum-dropdownlist-demo',
    component: EnumDropdownListDemoComponent
  },
  {
    path: 'enum/enum-pipe-demo',
    component: EnumPipeDemoComponent
  },
  {
    path: 'common/utility/utility-demo',
    component: UtilityDemoComponent
  },
  {
    path: 'enum/enum-select-group-demo',
    component: EnumSelectgroupDemoComponent
  },
  {
    path: 'dictionary/dics-selectgroup-demo',
    component: DicsSelectgroupDemoComponent
  },
  {
    path: 'common/component/selectgroup-demo',
    component: SelectgroupDemoComponent
  },
  {
    path: '',
    redirectTo: 'basic-data',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlatformRoutingModule {}
