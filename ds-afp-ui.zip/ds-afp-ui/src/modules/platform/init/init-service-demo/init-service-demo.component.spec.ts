import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitServiceDemoComponent } from './init-service-demo.component';

describe('InitServiceDemoComponent', () => {
  let component: InitServiceDemoComponent;
  let fixture: ComponentFixture<InitServiceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitServiceDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitServiceDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
