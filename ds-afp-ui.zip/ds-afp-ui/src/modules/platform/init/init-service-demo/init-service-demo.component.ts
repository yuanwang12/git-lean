import { Component, OnInit } from '@angular/core';

import { InitService } from '../init.service';

@Component({
  selector: 'ds-init-service-demo',
  templateUrl: './init-service-demo.component.html',
  styleUrls: ['./init-service-demo.component.css']
})
export class InitServiceDemoComponent implements OnInit {
  constructor(private initService: InitService) {}

  ngOnInit() {
    const dicArr = new Array<string>();
    dicArr.push('SDMS_QQYY');
    this.initService.initAll(dicArr).subscribe({
      next: () => {
        alert('初始化完成！');
      },
      error: err => {
        alert(err);
      }
    });
  }
}
