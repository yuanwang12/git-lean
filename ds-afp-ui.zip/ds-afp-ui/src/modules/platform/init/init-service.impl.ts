import { Observable, of } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { LoginUser } from '../basic-data/user-info/login-user';
import { UserInfoService } from '../basic-data/user-info/user-info.service';
import { ConfigService } from '../config/config.service';
import { DictionaryService } from '../dictionary/dictionary.service';
import { InitService } from './init.service';

@Injectable()
export class InitServiceImpl implements InitService {
  constructor(
    private userInfoService: UserInfoService,
    private dictionaryService: DictionaryService,
    private httpClient: HttpClient,
    private configService: ConfigService
  ) {}

  // 初始化当前用户
  private initCurrentUser(): Observable<LoginUser> {
    const subject = new Subject<any>();
    this.userInfoService.getCurrentUser().subscribe({
      next: res => {
        subject.next(res);
      },
      error: err => {
        subject.error('初始化当前用户失败');
      }
    });
    return subject;
  }

  // 初始化kendo语言包
  private initKendoLangPackage(language: string): Observable<string> {
    const subject = new Subject<string>();
    // en-us 语言包 datepicker有问题
    language = language.replace('_', '-').replace('en', 'en-GB');
    // 语种为英文时,language为空
    if (language == null || language === '') {
      language = 'en-GB';
    }
    this.httpClient
      .get(
        '/resources/plugin/kendo/js/messages/kendo.messages.' +
          language +
          '.min.js',
        { responseType: 'text' }
      )
      .subscribe({
        next: () => {
          this.httpClient
            .get(
              '/resources/plugin/kendo/js/cultures/kendo.culture.' +
                language +
                '.min.js',
              { responseType: 'text' }
            )
            .subscribe({
              next: res => {
                subject.next('初始化kendo语言包成功');
              },
              error: err => {
                subject.error(err);
              }
            });
        },
        error: err => {
          subject.error(err);
        }
      });

    return subject;
  }

  // 初始化字典
  private initDictionary(dictionaryArr: Array<string>): Observable<string> {
    const subject = new Subject<string>();
    this.dictionaryService.loadDictionarys(dictionaryArr).subscribe({
      next: res => {
        subject.next('初始化字典项成功');
      },
      error: err => {
        subject.error('初始化字典项失败');
      }
    });
    return subject;
  }

  // 初始化配置服务configService
  private initConfigService(): Observable<string> {
    const subject = new Subject<string>();
    this.configService.initData().subscribe({
      next: data => {
        subject.next('初始化配置服务成功');
      },
      error: err => {
        subject.error('初始化配置服务错误');
      }
    });
    return subject;
  }

  // TODO 多语言没有初始化
  public initAll(dictionaryArr: Array<string>): Observable<string> {
    const subject = new Subject<string>();
    const that = this;
    // 初始化当前用户
    that.initCurrentUser().subscribe({
      next: res => {
        if (res != null) {
          const user = res as LoginUser;
          // 初始化配置服务
          this.configService.initData().subscribe({
            next: data => {
              if (dictionaryArr && dictionaryArr.length > 0) {
                // 初始化字典项
                that.initDictionary(dictionaryArr).subscribe({
                  next: () => {
                    // 初始化字典成功
                    subject.next('初始化成功');
                  },
                  error: err => {
                    subject.error('字典初始化失败');
                  }
                });
              } else {
                subject.next('初始化成功');
              }
            },
            error: err => {
              subject.error('初始化配置服务失败');
            }
          });
        } else {
          subject.error('未登录！');
        }
      },
      error: err => {
        subject.error(err);
      }
    });
    return subject;
  }
}
