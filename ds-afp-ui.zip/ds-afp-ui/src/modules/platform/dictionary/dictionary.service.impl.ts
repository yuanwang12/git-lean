import { Observable, of } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { DataStoreResponse } from '../common/protocol/data-store-response';
import { DictionaryItem } from './dictionary-item';
import { DictionaryValue } from './dictionary-value';
import { DictionaryService } from './dictionary.service';

@Injectable()
export class DictionaryServiceImpl implements DictionaryService {
  constructor(private httpClient: HttpClient) {}

  public loadDictionarysUrl =
    '/platform-web/rest/inner/platform/dictionary/loadDictionarys';
  public dicsCache: Map<string, DictionaryItem> = new Map<
    string,
    DictionaryItem
  >();

  public loadDictionarys(dicItemCodeArr: Array<string>): Observable<boolean> {
    const that = this;
    const subject = new Subject<boolean>();
    this.httpClient.post(this.loadDictionarysUrl, dicItemCodeArr).subscribe({
      next: res => {
        const response = res as DataStoreResponse;
        if (response.ret === 'ok') {
          const dics = response.content;
          for (const dicConfigItemCode of dicItemCodeArr) {
            that.dicsCache.set(dicConfigItemCode, dics[dicConfigItemCode]);
          }
          subject.next(true);
        } else if (response.ret === 'error') {
          subject.error(response.msg);
        }
      },
      error: err => {
        subject.error(err);
      }
    });
    return subject;
  }

  public getDicItemValuesByCode(
    dicItemCode: string
  ): Observable<Array<DictionaryValue>> {
    const that = this;
    const subject = new Subject<Array<DictionaryValue>>();
    if (!that.dicsCache.get(dicItemCode)) {
      // 拆分字典项字符串
      const dicItemArr = dicItemCode.split(',');
      const loadSubject = that.loadDictionarys(dicItemArr);
      loadSubject.subscribe({
        next: res => {
          // 所有缓存完成后读取出缓存数据
          let resData = new DictionaryItem();
          resData = that.dicsCache.get(dicItemCode);
          subject.next(resData.subValues);
        },
        error: err => {
          subject.error('根据字典项code获取字典值数组失败');
        }
      });
      return subject;
    } else {
      let resData = new DictionaryItem();
      resData = that.dicsCache.get(dicItemCode);
      const observable = of(resData.subValues);
      return observable;
    }
  }

  public getDicItemByCode(dicItemCode: string): Observable<DictionaryItem> {
    const that = this;
    const subject = new Subject<DictionaryItem>();
    if (!that.dicsCache.get(dicItemCode)) {
      // 拆分字典项字符串
      const dicItemArr = dicItemCode.split(',');
      const loadSubject = that.loadDictionarys(dicItemArr);
      loadSubject.subscribe({
        next: res => {
          // 所有缓存完成后读取出缓存数据
          let resData = new DictionaryItem();
          resData = that.dicsCache.get(dicItemCode);
          subject.next(resData);
        },
        error: err => {
          subject.error('根据字典项code获取字典项对象失败');
        }
      });
      return subject;
    } else {
      let resData = new DictionaryItem();
      resData = that.dicsCache.get(dicItemCode);
      const observable = of(resData);
      return observable;
    }
  }

  public getDicItemsByCodes(
    dicItemCodes: string
  ): Observable<Map<string, DictionaryItem>> {
    const that = this;
    const subject = new Subject<Map<string, DictionaryItem>>();
    // 拆分字典项字符串
    const dicItemArr = dicItemCodes.split(',');
    // 标志是否存在未缓存code
    let flag = false;
    for (const dicItem of dicItemArr) {
      if (!that.dicsCache.get(dicItem)) {
        flag = true;
        break;
      }
    }
    if (flag) {
      const loadSubject = that.loadDictionarys(dicItemArr);
      loadSubject.subscribe({
        next: res => {
          // 所有缓存完成后读取出缓存数据
          const resData = new Map<string, DictionaryItem>();
          // const resData = {};
          for (const dicItem of dicItemArr) {
            resData.set(dicItem, that.dicsCache.get(dicItem));
            resData[dicItem] = that.dicsCache.get(dicItem);
          }
          subject.next(resData);
        },
        error: err => {
          subject.error('根据code获取多个字典项对象失败');
        }
      });
      return subject;
    } else {
      const resData = new Map<string, DictionaryItem>();
      // const resData = {};
      for (const dicItem of dicItemArr) {
        resData.set(dicItem, that.dicsCache.get(dicItem));
        // resData[dicItem] = that.dicsCache.get(dicItem);
      }
      const observable = of(resData);
      return observable;
    }
  }

  public getDicItemValueByCode(
    dicItemCode: string,
    dicValueCode: string
  ): Observable<DictionaryValue> {
    const that = this;
    const subject = new Subject<DictionaryValue>();
    if (!that.dicsCache.get(dicItemCode)) {
      const dicItemArr = dicItemCode.split(',');
      const loadSubject = that.loadDictionarys(dicItemArr);
      loadSubject.subscribe({
        next: res => {
          // 所有缓存完成后读取出缓存数据
          let resData = new DictionaryValue();
          let dictionaryItem = new DictionaryItem();
          dictionaryItem = that.dicsCache.get(dicItemCode);
          for (const dicItemValue of dictionaryItem.subValues) {
            if (dicItemValue.code === dicValueCode) {
              resData = dicItemValue;
            }
          }
          subject.next(resData);
        },
        error: err => {
          subject.error('根据字典项code和字典值code获取字典值对象失败');
        }
      });
      return subject;
    } else {
      let resData = new DictionaryValue();
      const dictionaryItem = that.dicsCache.get(dicItemCode);
      for (const dicItemValue of dictionaryItem.subValues) {
        if (dicItemValue.code === dicValueCode) {
          resData = dicItemValue;
        }
      }
      const observable = of(resData);
      return observable;
    }
  }
}
