import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DicsSelectgroupComponent } from './dics-selectgroup.component';

describe('DicsSelectgroupComponent', () => {
  let component: DicsSelectgroupComponent;
  let fixture: ComponentFixture<DicsSelectgroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DicsSelectgroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DicsSelectgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
