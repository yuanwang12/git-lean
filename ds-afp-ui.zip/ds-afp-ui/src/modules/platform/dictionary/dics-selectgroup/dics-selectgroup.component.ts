import { element } from 'protractor';

import {
    Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2
} from '@angular/core';

import { DictionaryItem } from '../dictionary-item';
import { DictionaryValue } from '../dictionary-value';
import { DictionaryService } from '../dictionary.service';

@Component({
  selector: 'ds-dics-selectgroup',
  templateUrl: './dics-selectgroup.component.html',
  styleUrls: ['./dics-selectgroup.component.css']
})
export class DicsSelectgroupComponent implements OnInit {
  constructor(
    private render: Renderer2,
    private dictionaryService: DictionaryService,
    private ele: ElementRef
  ) {}

  public dicItemValues: Array<DictionaryValue>;
  @Input()
  public dicItemCode: string;
  @Input() isMultiSelect: boolean;
  @Input()
  public selectedDicValues: Array<DictionaryValue>;
  public values: Array<DictionaryValue>;
  @Output()
  public selectedDicValuesChange: EventEmitter<
    Array<DictionaryValue>
  > = new EventEmitter();
  @Output()
  public dicValueChange: EventEmitter<
    Array<DictionaryValue>
  > = new EventEmitter();
  ngOnInit() {
    // 加载字典
    if (!this.dicItemCode) {
      return;
    }
    this.loadDic(this.dicItemCode);
  }

  // 加载字典方法
  public loadDic(dicItemCode: string): void {
    // 通过字典项的code获取字典值
    this.dictionaryService.getDicItemValuesByCode(dicItemCode).subscribe({
      next: data => {
        if (data) {
          this.dicItemValues = data;
          this.values = this.selectedDicValues;
        }
      },
      error: err => {
        console.log('loadDic got an error: ', err);
      }
    });
  }

  public dicClick(e): void {
    this.selectedDicValuesChange.emit(this.values);
    this.dicValueChange.emit(this.values);
  }
}
