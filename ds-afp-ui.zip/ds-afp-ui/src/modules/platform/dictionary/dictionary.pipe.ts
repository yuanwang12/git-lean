import { Pipe, PipeTransform } from '@angular/core';

import { DictionaryService } from './dictionary.service';

@Pipe({
  name: 'dictionary'
})
export class DictionaryPipe implements PipeTransform {
  private dicValueName: string;
  constructor(public dictionaryService: DictionaryService) {}

  transform(dicValueCode: string, dicItemCode: string): any {
    this.dictionaryService
      .getDicItemValueByCode(dicItemCode, dicValueCode)
      .subscribe({
        next: data => {
          this.dicValueName = data.name;
        },
        error: err => {
          return err;
        }
      });
    return this.dicValueName;
  }
}
