import { Component, OnInit, ViewChild } from '@angular/core';

import { DicsDropdownListComponent } from '../dics-dropdown-list/dics-dropdown-list.component';

@Component({
  selector: 'ds-dics-dropdown-list-demo',
  templateUrl: './dics-dropdown-list-demo.component.html',
  styleUrls: ['./dics-dropdown-list-demo.component.css']
})
export class DicsDropdownListDemoComponent implements OnInit {
  @ViewChild(DicsDropdownListComponent)
  private dicsDropdownListComponent: DicsDropdownListComponent;
  constructor() {}
  public selectedJobType: string;
  ngOnInit() {}

  public onJobTypeSelect(selectCode: string): void {
    alert(selectCode);
  }

  public setDsModel(): void {
    this.selectedJobType = 'ZB';
  }

  public setDicDefine() {
    this.dicsDropdownListComponent.setDicDefCode('SDMS_QQYY');
  }
}
