import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ds-dics-selectgroup-demo',
  templateUrl: './dics-selectgroup-demo.component.html',
  styleUrls: ['./dics-selectgroup-demo.component.css']
})
export class DicsSelectgroupDemoComponent implements OnInit {
  constructor() {}

  public selectedDicValues = [
    { code: 'ZB', id: '40288a4a67b4fcfc0167e40a71c00035', name: '值班' }
  ];

  public selectedDicValues1 = [
    { code: 'ZB', id: '40288a4a67b4fcfc0167e40a71c00035', name: '值班' }
  ];

  public currentValues: string;
  public currentValues1: string;

  ngOnInit() {
    this.currentValues = JSON.stringify(this.selectedDicValues);
    this.currentValues1 = JSON.stringify(this.selectedDicValues1);
  }

  public dicClick(value): void {
    this.currentValues = JSON.stringify(this.selectedDicValues);
  }

  public dicClick1(value): void {
    this.currentValues1 = JSON.stringify(this.selectedDicValues1);
  }
}
