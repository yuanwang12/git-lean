import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DicsSelectgroupDemoComponent } from './dics-selectgroup-demo.component';

describe('DicsSelectgroupDemoComponent', () => {
  let component: DicsSelectgroupDemoComponent;
  let fixture: ComponentFixture<DicsSelectgroupDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DicsSelectgroupDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DicsSelectgroupDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
