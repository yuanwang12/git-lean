import { DictionaryPipe } from './dictionary.pipe';

describe('DictionaryPipe', () => {
  it('create an instance', () => {
    const pipe = new DictionaryPipe();
    expect(pipe).toBeTruthy();
  });
});
