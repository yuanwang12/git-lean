import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DicsDropdownListComponent } from './dics-dropdown-list.component';

describe('DicsDropdownListComponent', () => {
  let component: DicsDropdownListComponent;
  let fixture: ComponentFixture<DicsDropdownListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DicsDropdownListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DicsDropdownListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
