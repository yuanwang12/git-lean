import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { DictionaryItem } from '../dictionary-item';
import { DictionaryService } from '../dictionary.service';

@Component({
  selector: 'ds-dics-dropdown-list',
  templateUrl: './dics-dropdown-list.component.html',
  styleUrls: ['./dics-dropdown-list.component.css']
})
export class DicsDropdownListComponent implements OnInit {
  constructor(private dictionaryService: DictionaryService) {}
  public dictionary: Array<DictionaryItem>;
  public ngModel: string;
  public defaultItem: DictionaryItem;
  @Input()
  public defaultSelected: string;
  @Input()
  public dicDefCode: string;
  @Input()
  public optionLabel: string;
  @Output() dsModelChange = new EventEmitter();
  @Output()
  public dsOnSelect: EventEmitter<string> = new EventEmitter();

  @Input()
  set dsModel(v: string) {
    if (this.dictionary) {
      this.ngModel = v;
    } else {
      if (this.dicDefCode) {
        // 调用通用方法调取字典数据源
        this.commonServiceMethod(this.dicDefCode);
      }
    }
  }

  ngOnInit() {
    // 调用通用方法调取字典数据源
    this.commonServiceMethod(this.dicDefCode);
    if (this.optionLabel != null && this.optionLabel !== '') {
      this.defaultItem = {
        code: null,
        name: this.optionLabel,
        id: null,
        subValues: null
      };
    }
  }

  // 通用方法调取字典数据源
  public commonServiceMethod(dicDefCode: string): void {
    if (!dicDefCode) {
      this.dictionary = [];
      this.ngModel = null;
      return;
    }
    this.dictionaryService.getDicItemByCode(dicDefCode).subscribe({
      next: data => {
        if (data) {
          this.dictionary = data.subValues;
          if (!this.dsModel && this.defaultSelected) {
            this.ngModel = this.dictionary[0].code;
            this.dsModelChange.emit(this.ngModel);
          } else {
            this.ngModel = this.dsModel;
          }
        }
      },
      error: err => {
        console.log('commonServiceMethod got an error: ', err);
      }
    });
  }

  public onSelect(value) {
    this.dsModel = value;
    this.dsOnSelect.emit(value);
    this.dsModelChange.emit(this.ngModel);
  }

  public setDicDefCode(dicDefCode: string): void {
    if (!dicDefCode) {
      this.dictionary = [];
    } else {
      // 调用通用方法调取字典数据源
      this.commonServiceMethod(dicDefCode);
    }
  }
}
