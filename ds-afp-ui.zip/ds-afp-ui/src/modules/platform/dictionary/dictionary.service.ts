import { Observable } from 'rxjs';

import { Injectable } from '@angular/core';

import { DictionaryItem } from './dictionary-item';
import { DictionaryValue } from './dictionary-value';

@Injectable({
  providedIn: 'root'
})
export abstract class DictionaryService {
  constructor() {}

  abstract loadDictionarys(dicItemCodeArr: Array<string>): Observable<boolean>;

  abstract getDicItemValuesByCode(
    dicItemCode: string
  ): Observable<Array<DictionaryValue>>;

  abstract getDicItemByCode(dicItemCode: string): Observable<DictionaryItem>;

  abstract getDicItemsByCodes(
    dicItemCodes: string
  ): Observable<Map<string, DictionaryItem>>;

  abstract getDicItemValueByCode(
    dicItemCode: string,
    dicValueCode: string
  ): Observable<DictionaryValue>;
}
