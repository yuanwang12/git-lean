import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ds-dictionary-pipe-demo',
  templateUrl: './dictionary-pipe-demo.component.html',
  styleUrls: ['./dictionary-pipe-demo.component.css']
})
export class DictionaryPipeDemoComponent implements OnInit {
  private dicValueCode: string;
  private dicItemCode = 'SDMS_QQYY';
  constructor() {}

  ngOnInit() {}
}
