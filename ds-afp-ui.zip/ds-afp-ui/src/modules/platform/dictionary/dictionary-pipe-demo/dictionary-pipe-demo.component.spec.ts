import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DictionaryPipeDemoComponent } from './dictionary-pipe-demo.component';

describe('DictionaryPipeDemoComponent', () => {
  let component: DictionaryPipeDemoComponent;
  let fixture: ComponentFixture<DictionaryPipeDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DictionaryPipeDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DictionaryPipeDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
