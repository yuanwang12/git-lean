export class DictionaryValue {
  public id: string;
  public code: string;
  public name: string;
  public parent: DictionaryValue;
  public subValues: Array<DictionaryValue>;
}
