import { Component, OnInit } from '@angular/core';

import { DictionaryItem } from '../dictionary-item';
import { DictionaryValue } from '../dictionary-value';
import { DictionaryService } from '../dictionary.service';

@Component({
  selector: 'ds-dictionary-service-demo',
  templateUrl: './dictionary-service-demo.component.html',
  styleUrls: ['./dictionary-service-demo.component.css']
})
export class DictionaryServiceDemoComponent implements OnInit {
  constructor(private dictionaryService: DictionaryService) {}

  public dictionaryItemValues: string;
  public dictionaryItem: string;
  public dictionaryItems: string;
  public dictionaryItemValue: string;
  public getDicItemValuesByCode(dicItemCodeOne: string): void {
    const observable = this.dictionaryService.getDicItemValuesByCode(
      dicItemCodeOne
    );
    observable.subscribe({
      next: data => {
        this.dictionaryItemValues = JSON.stringify(data);
        console.log(data);
      }
    });
  }

  public getDicItemByCode(dicItemCodeTwo: string): void {
    const observable = this.dictionaryService.getDicItemByCode(dicItemCodeTwo);
    observable.subscribe({
      next: data => {
        this.dictionaryItem = JSON.stringify(data);
        console.log(data);
      }
    });
  }

  public getDicItemsByCodes(dicItemCodes: string): void {
    const observable = this.dictionaryService.getDicItemsByCodes(dicItemCodes);
    observable.subscribe({
      next: data => {
        this.dictionaryItems = JSON.stringify(data);
        console.log(data);
      }
    });
  }

  public getDicItemValueByCode(
    dicItemCodeThree: string,
    dicItemValueCode: string
  ): void {
    const observable = this.dictionaryService.getDicItemValueByCode(
      dicItemCodeThree,
      dicItemValueCode
    );
    observable.subscribe({
      next: data => {
        this.dictionaryItemValue = JSON.stringify(data);
        console.log(data);
      }
    });
  }
  ngOnInit() {}
}
