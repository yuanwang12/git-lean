import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DictionaryServiceDemoComponent } from './dictionary-service-demo.component';

describe('DictionaryServiceDemoComponent', () => {
  let component: DictionaryServiceDemoComponent;
  let fixture: ComponentFixture<DictionaryServiceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DictionaryServiceDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DictionaryServiceDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
