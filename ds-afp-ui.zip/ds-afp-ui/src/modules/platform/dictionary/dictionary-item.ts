import { DictionaryValue } from './dictionary-value';

export class DictionaryItem {
  public id: string;
  public code: string;
  public name: string;
  public subValues: Array<DictionaryValue>;
}
