import { Component, OnInit } from '@angular/core';

import { EnumService } from '../enum.service';

@Component({
  selector: 'ds-enum-service-demo',
  templateUrl: './enum-service-demo.component.html',
  styleUrls: ['./enum-service-demo.component.css']
})
export class EnumServiceDemoComponent implements OnInit {
  constructor(private enumService: EnumService) {}

  // public itemCode: string;
  public selectedEnumText: string;
  public selectedEnums: any;
  public selectedEnumItem: any;
  public selectedEnumItemArr: any;
  public getEnum(enumDefineCode: string): void {
    this.enumService.getEnumItemsByCode(enumDefineCode).subscribe({
      next: data => {
        this.selectedEnums = JSON.stringify(data);
        console.log(data);
      }
    });
  }

  public getEnumText(enumDefineCode: string, enumItemValue: string): void {
    this.enumService
      .getItemTextByValue(enumDefineCode, enumItemValue)
      .subscribe({
        next: data => {
          this.selectedEnumText = data;
        }
      });
  }

  public getEnumItem(enumDefineCode: string, enumItemValue: string): void {
    this.enumService
      .getEnumItemByValue(enumDefineCode, enumItemValue)
      .subscribe({
        next: data => {
          this.selectedEnumItem = JSON.stringify(data);
          console.log(data);
        }
      });
  }

  public getEnumItemArr(enumDefineCode: string): void {
    this.enumService.getEnumItemsArrayByCode(enumDefineCode).subscribe({
      next: data => {
        this.selectedEnumItemArr = JSON.stringify(data);
        console.log(data);
      }
    });
  }
  ngOnInit() {}
}
