import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumServiceDemoComponent } from './enum-service-demo.component';

describe('EnumServiceDemoComponent', () => {
  let component: EnumServiceDemoComponent;
  let fixture: ComponentFixture<EnumServiceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumServiceDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumServiceDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
