import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumSelectgroupDemoComponent } from './enum-selectgroup-demo.component';

describe('EnumSelectgroupDemoComponent', () => {
  let component: EnumSelectgroupDemoComponent;
  let fixture: ComponentFixture<EnumSelectgroupDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumSelectgroupDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumSelectgroupDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
