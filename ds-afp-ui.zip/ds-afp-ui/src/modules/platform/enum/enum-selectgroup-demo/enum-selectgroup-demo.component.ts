import { Component, OnInit } from '@angular/core';
// 引入子组件
import { EnumSelectgroupComponent } from '../enum-selectgroup/enum-selectgroup.component';

@Component({
  selector: 'ds-enum-selectgroup-demo',
  templateUrl: './enum-selectgroup-demo.component.html',
  styleUrls: ['./enum-selectgroup-demo.component.css']
})
export class EnumSelectgroupDemoComponent implements OnInit {
  constructor() { }
  // 设置默认值
  public selectedEnumItems = [
    {text: '在岗', value: 'ZG', nowStateDicDefineCode: 'SDMS_ZGJJZT'}
  ];

  public currentValues: string;
  ngOnInit() {
    this.currentValues = JSON.stringify(this.selectedEnumItems);
  }

  public Click(value): void {
    this.currentValues = JSON.stringify(value);
  }
}
