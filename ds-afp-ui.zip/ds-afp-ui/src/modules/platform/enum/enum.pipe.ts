import { Pipe, PipeTransform } from '@angular/core';
import { EnumService } from './enum.service';
@Pipe({
  name: 'enum'
})
export class EnumPipe implements PipeTransform {
  public enumText: string;
  constructor(public enumService: EnumService) {
  }
  transform(enumItemValue: string, enumDefineCode: string): string {
    this.enumService
      .getItemTextByValue(enumDefineCode, enumItemValue)
      .subscribe({
        next: data => {
          this.enumText = data;
        }
      });
    return this.enumText;
  }

}


