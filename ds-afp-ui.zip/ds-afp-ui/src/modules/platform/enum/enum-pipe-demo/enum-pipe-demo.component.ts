import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ds-enum-pipe-demo',
  templateUrl: './enum-pipe-demo.component.html',
  styleUrls: ['./enum-pipe-demo.component.css']
})
export class EnumPipeDemoComponent implements OnInit {

  public enumDefineCode: string;
  public enumItemValue: string;
  constructor() { }

  ngOnInit() {
    // 默认enumDefineCode = 'AttendanceState'
    this.enumDefineCode = 'AttendanceState';
  }

}
