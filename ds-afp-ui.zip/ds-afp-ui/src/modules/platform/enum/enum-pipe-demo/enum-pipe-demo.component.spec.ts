import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumPipeDemoComponent } from './enum-pipe-demo.component';

describe('EnumPipeDemoComponent', () => {
  let component: EnumPipeDemoComponent;
  let fixture: ComponentFixture<EnumPipeDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumPipeDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumPipeDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
