import { Component, OnInit, Pipe, Input, Output, EventEmitter } from '@angular/core';
import { SelectgroupComponent } from '../../common/component/selectgroup/selectgroup.component';
import { EnumService } from '../enum.service';

@Component({
  selector: 'ds-enum-selectgroup',
  templateUrl: './enum-selectgroup.component.html',
  styleUrls: ['./enum-selectgroup.component.css']
})
export class EnumSelectgroupComponent implements OnInit {
   constructor(public enumService: EnumService) {
  }
  public enumItemValues: Array<object>;
  public values: any;
  public item: any;
  public text: any;
  public value: any;
  public name: any;
  public code: any;

  @Input()
  public enumDefineCode: string;

  @Input()
  public dsModel: string;

  @Output()
  public enumItemChange: any = new EventEmitter();

  @Output()
  public selectedDicValuesChange: any = new EventEmitter();

  @Input()
  public isMultiSelect: boolean;

  ngOnInit() {
    // 加载枚举
    if (!this.enumDefineCode) {
      return;
    }
    this.loadEnum(this.enumDefineCode);
  }

  // 加载枚举方法
  public loadEnum(enumDefineCode: string): void {
    // 通过枚举项的code获取枚举值
    this.enumService.getEnumItemsArrayByCode(enumDefineCode).subscribe({
      next: data => {
        // 为了统一枚举字典数据源 故在次进行转化 text value 换成 name code
        if (data) {
          for (this.item of data) {
             this.item.name = this.item.text;
             this.item.code = this.item.value;
             delete this.item.text;
             delete this.item.value;
          }
          this.enumItemValues = data;
          this.values = this.dsModel;
        }
      }
    });
  }

  public enumClick(e): void {
    this.enumItemChange.emit(this.values);
  }

}
