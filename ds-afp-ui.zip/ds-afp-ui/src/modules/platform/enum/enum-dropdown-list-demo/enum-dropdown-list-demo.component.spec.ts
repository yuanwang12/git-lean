import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumDropdownListDemoComponent } from './enum-dropdown-list-demo.component';

describe('EnumDropdownListDemoComponent', () => {
  let component: EnumDropdownListDemoComponent;
  let fixture: ComponentFixture<EnumDropdownListDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumDropdownListDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumDropdownListDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
