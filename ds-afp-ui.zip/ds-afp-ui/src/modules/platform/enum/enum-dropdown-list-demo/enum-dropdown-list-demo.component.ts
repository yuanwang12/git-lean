import { Component, OnInit, Input } from '@angular/core';
import { EnumService } from '../enum.service';
// 引入子组件
import { EnumDropdownListComponent } from '../enum-dropdown-list/enum-dropdown-list.component';

@Component({
  selector: 'ds-enum-dropdown-list-demo',
  templateUrl: './enum-dropdown-list-demo.component.html',
  styleUrls: ['./enum-dropdown-list-demo.component.css']
})
export class EnumDropdownListDemoComponent implements OnInit {
  public value: string;
  public text: string;
  public dsModel: string;
  // public setEnumDefineCode: string;
  // public thisTypeSelectComp: any;
  // 组件激活时回调
  constructor(public enumService: EnumService) { }

  // 组件初始化完成过回调
  ngOnInit() {
    // 动态设置defineCode
    this.dsModel = 'XG';
  }

  // 选择事件
  public enumItemChange($event: any): void {
    this.value = $event.value;
    this.text = $event.text;
  }
}
