import { EnumServiceImpl } from './enum-service-impl';

describe('EnumServiceImpl', () => {
  it('should create an instance', () => {
    expect(new EnumServiceImpl()).toBeTruthy();
  });
});
