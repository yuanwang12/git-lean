import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumDropdownListComponent } from './enum-dropdown-list.component';

describe('EnumDropdownlistDemoComponent', () => {
  let component: EnumDropdownListComponent;
  let fixture: ComponentFixture<EnumDropdownListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumDropdownListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumDropdownListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
