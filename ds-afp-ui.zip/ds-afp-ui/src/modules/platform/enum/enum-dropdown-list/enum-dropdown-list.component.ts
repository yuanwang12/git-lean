import { Component, OnInit, Input, Output, NgModule, EventEmitter } from '@angular/core';
// 引入枚举服务
import { EnumService } from '../enum.service';

@Component({
  selector: 'ds-enum-dropdown-list',
  templateUrl: './enum-dropdown-list.component.html',
  styleUrls: ['./enum-dropdown-list.component.css']
})
export class EnumDropdownListComponent implements OnInit {
  public enums: Array<any>;
  public pleaseSelect: any;
  public defaultItem: object;
  public ngModel: string;
  public i: number;
  public item: string;
  public accepedModel: string;
  @Input() public enumDefineCode: string;
  @Input() public isShowSelect: string;
  @Input() public optionLabel: string;
  @Input() public defaultSelected: string;
  @Input()
   set dsModel(val: string) {
    if (this.enums) {
      // 调用通用方法调取字典数据源
      this.ngModel = val;
    } else {
      this.accepedModel = val;
      this.loadEnumDropdownList();
    }
  }
  @Output()
  dsModelChange = new EventEmitter();

  // 向外暴露事件
  @Output()
  public enumItemChange = new EventEmitter();

  // 选择事件
  public selectionChange(value: any): void {
    this.enumItemChange.emit(value);
    // 双向绑定向外暴露model值
    this.dsModelChange.emit(value.value);
  }

  // 激活组件时加载
  constructor(public enumService: EnumService) { }

  // 初始化组件后加载
  ngOnInit() {
    // 通过枚举服务请求下拉数据
    this.loadEnumDropdownList();
    if (this.optionLabel) {
      this.defaultItem = {
        value: null,
        text: this.optionLabel,
        id: null
      };
    }
  }

  /**
   * loadEnumDropdownList
   * 加载枚举数据服务
   */
  public loadEnumDropdownList() {
    if (!this.enumDefineCode) {
      this.enums = [];
      this.ngModel = null;
      return;
    }
    this.enumService.getEnumItemsArrayByCode(this.enumDefineCode).subscribe({
      next: data => {
        this.enums = data;
        // 通过设置默认值 展示第一条数据
        if (!this.accepedModel && this.defaultSelected) {
          this.ngModel = this.enums[0].value;
          this.dsModelChange.emit(this.ngModel);
        } else {
          this.ngModel = this.accepedModel;
        }
      }
    });
  }
}
