import { Observable, of } from 'rxjs';

import { EnumService } from './enum.service';

export class EnumServiceMock implements EnumService {
  private DS_ENUMS = {
    // 出勤状态
    AttendanceState: {
      ZG: {
        text: '在岗',
        value: 'ZG', // 次数据源 对应控件中展示问本为text 不建议修改text为name
        nowStateDicDefineCode: 'SDMS_ZGJJZT'
      },
      XG: {
        text: '下岗',
        value: 'XG'
      },
      // WPB: {
      //     "text": "未排班",
      //     "value": "WPB"
      // },
      QQ: {
        text: '缺勤',
        value: 'QQ',
        nowStateDicDefineCode: 'SDMS_QQYY'
      }
    },
    // 出行方式
    DutyWay: {
      WALK: {
        // value text形式
        text: '步行',
        value: 'WALK'
      },
      BICYCLE: {
        text: '自行车',
        value: 'BICYCLE'
      },
      VEHICLE: {
        text: '指定车辆',
        value: 'VEHICLE'
      }
    },
    // 任务类型
    TaskType: {
      NORMAL: {
        text: '常态',
        value: 'NORMAL'
      },
      GRADE: {
        text: '等级',
        value: 'GRADE'
      },
      SPECIAL: {
        text: '专项',
        value: 'SPECIAL'
      }
    },
    // 工作范畴
    DutyCategory: {
      OFFICE: {
        text: '行政值班',
        value: 'OFFICE'
      },
      PATROL: {
        text: '巡区值班',
        value: 'PATROL'
      }
    }
  };

  public getEnumItemsByCode(enumDefineCode: string): Observable<any> {
    return of(this.DS_ENUMS[enumDefineCode]);
  }

  public getItemTextByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<string> {
    return of(this.DS_ENUMS[enumDefineCode][enumItemValue].text);
  }

  public getEnumItemByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<any> {
    return of(this.DS_ENUMS[enumDefineCode][enumItemValue]);
  }

  public getEnumItemsArrayByCode(
    enumDefineCode: string
  ): Observable<Array<any>> {
    const arrEnumItems = new Array<any>();
    const data = this.DS_ENUMS[enumDefineCode];
    for (const key of Object.keys(data)) {
      if (data.hasOwnProperty(key)) {
        arrEnumItems.push(data[key]);
      }
    }
    return of(arrEnumItems);
  }
}
