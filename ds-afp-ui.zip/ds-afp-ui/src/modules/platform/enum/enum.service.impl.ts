import { Observable, of } from 'rxjs';

import { EnumService } from './enum.service';

export class EnumServiceImpl implements EnumService {
  public getEnumItemsByCode(enumDefineCode: string): Observable<any> {
    return of(null);
  }

  public getItemTextByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<string> {
    return of(null);
  }

  public getEnumItemByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<any> {
    return of(null);
  }

  public getEnumItemsArrayByCode(
    enumDefineCode: string
  ): Observable<Array<any>> {
    return of(null);
  }
}
