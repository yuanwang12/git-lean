import { EnumPipe } from './enum.pipe';

describe('EnumPipe', () => {
  it('create an instance', () => {
    const pipe = new EnumPipe();
    expect(pipe).toBeTruthy();
  });
});
