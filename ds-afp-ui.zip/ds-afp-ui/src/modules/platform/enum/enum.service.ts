import { Observable } from 'rxjs';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export abstract class EnumService {
  constructor() {}

  abstract getItemTextByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<string>;

  abstract getEnumItemByValue(
    enumDefineCode: string,
    enumItemValue: string
  ): Observable<any>;

  abstract getEnumItemsByCode(enumDefineCode: string): Observable<any>;

  abstract getEnumItemsArrayByCode(
    enumDefineCode: string
  ): Observable<Array<any>>;
}
