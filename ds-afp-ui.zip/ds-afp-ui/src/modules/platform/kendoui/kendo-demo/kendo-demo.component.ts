import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kendo-demo',
  templateUrl: './kendo-demo.component.html',
  styleUrls: ['./kendo-demo.component.css']
})
export class KendoDemoComponent implements OnInit {
  public allowCustom = true;
  public listItems: Array<string> = [
    'Baseball',
    'Basketball',
    'Cricket',
    'Field Hockey',
    'Football',
    'Table Tennis',
    'Tennis',
    'Volleyball'
  ];

  constructor() {}

  ngOnInit() {}
}
