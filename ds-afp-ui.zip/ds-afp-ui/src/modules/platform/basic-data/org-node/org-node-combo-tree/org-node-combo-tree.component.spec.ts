import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgNodeComboTreeComponent } from './org-node-combo-tree.component';

describe('OrgNodeComboTreeComponent', () => {
  let component: OrgNodeComboTreeComponent;
  let fixture: ComponentFixture<OrgNodeComboTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgNodeComboTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrgNodeComboTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
