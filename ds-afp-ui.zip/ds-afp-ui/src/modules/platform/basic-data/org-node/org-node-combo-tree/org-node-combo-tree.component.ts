import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';

import { UserInfoService } from '../../user-info/user-info.service';
import { OrgNode } from '../org-node';
import { OrgNodeService } from '../org-node.service';
import { TreeNode } from '../../../common/component/combo-tree/tree-node';
import { ComboTreeComponent } from '../../../common/component/combo-tree/combo-tree.component';
@Component({
  selector: 'ds-org-node-combo-tree',
  templateUrl: './org-node-combo-tree.component.html',
  styleUrls: ['./org-node-combo-tree.component.css']
})
export class OrgNodeComboTreeComponent implements OnInit {
  // private dsDataValueField: string;

  @Input() dsAutoInit: boolean;
  @Input() dsAutoClose: boolean;
  @Input() dsModel: string;
  @Input() dsModelText: string;
  @Input() dsRootOrgId: string;
  @Input() dsOrgRole: string;
  @Input() dsValuePrimitive: boolean;

  // todo 如何触发外界方法
  @Output() dsOnSelect = new EventEmitter<any>();

  // 调用子组件得变量和方法
  @ViewChild(ComboTreeComponent)
  private comboTreeComponent: ComboTreeComponent;

  private userInfoService: UserInfoService;

  private orgNodeService: OrgNodeService;

  private dsRootOrgCd: string;

  // private dsRootOrgId: string;

  // 根单位
  private orgNode: OrgNode = new OrgNode();

  private dsDataSourceOrg: Array<OrgNode>;

  public selectCode: string;

  public selectItem: OrgNode;

  public treeSource: Observable<Array<TreeNode>>;

  public selectTreeNodeCodes: Array<string>;

  public treeNodeItem: any;

  public searchItem: TreeNode;

  public code: string;

  constructor(
    userInfoService: UserInfoService,
    orgNodeService: OrgNodeService
  ) {
    this.userInfoService = userInfoService;
    this.orgNodeService = orgNodeService;
  }

  ngOnInit() {
    this.selectCode = this.dsModel;
    console.log('dsModel', this.dsModel);
    console.log('dsModelText', this.dsModelText);
    console.log('dsOrgRole', this.dsOrgRole);

    console.log('dsRootOrgId', this.dsRootOrgId);
    console.log('dsAutoInit', this.dsAutoInit);
    console.log('dsValuePrimitive', this.dsValuePrimitive);
    // console.log('dsDataValueField', this.dsDataValueField);
    console.log('dsAutoClose', this.dsAutoClose);
    if (!this.code) {
      this.code = '310000000000';
    }
    this.treeSource = this.orgNodeService.getChildrenOrgsAsyn(
      this.code,
      null,
      null
    );

    // 是否自动加载
    if (this.dsAutoInit) {
      this.userInfoService.getCurrentUser(null).subscribe({
        next: data => {
          console.log('当前登录用户：', data);
          if (data) {
            if (data.orgNodeId || data.orgNodeCd) {
              this.dsRootOrgCd = data.orgNodeCd;
              this.dsRootOrgId = data.orgNodeId;

              this.orgNode.id = data.orgNodeId;
              this.orgNode.code = data.orgNodeCd;
              this.orgNode.text = data.orgNodeName;
              this.loadDataSource();
            }
          }
        }
      });
    }
  }

  public loadDataSource(): void {
    // 查询下级单位
    this.orgNodeService
      .getChildrenOrgsAsyn(this.dsRootOrgCd, this.dsOrgRole, this.dsRootOrgId)
      .subscribe({
        next: data => {
          console.log('data', data);
          data.forEach(item => {
            // 换名字是为了与kendo-treeview子控件对应
            item.text = item.name; // 不是，从后台返回的对象里多了这几个属性。
            item.parentId = item.pid;
          });
          this.dsDataSourceOrg = data as Array<OrgNode>;
          this.dsDataSourceOrg.push(this.orgNode);
          console.log(this.dsDataSourceOrg);
          // operation.success(data);
        },
        error: err => {
          // logService.error('loadDataSource got an error: ', err);
        }
      });
  }

  public dsOnSelectOrg(e: any): void {
    console.log('ds-org-node-combo-tree', e);
    this.dsModel = null;
    if (e.dataItem) {
      this.dsModel = e.dataItem.id;
      this.dsModelText = e.dataItem.text;
    }
    //  TODO 触发外界绑定方法
    this.dsOnSelect.emit(e);
  }

    /**
     * 当内部组件选择一个节点时触发
     *
     * @param {*} e
     * @memberof ComboTreeDemoComponent
     */
  public onSelected(e: any): any {
    console.log('selectItem', e.dataItem);
    this.selectItem = e.dataItem;
    return this.selectItem;
    // this.selectItemText = e.dataItem.text;
  }

  // 是否查询下级
  public dsHasChildren = (item: any): boolean => {
    return true;
  }

  public dsFetchChildren = (node: any): Observable<any[]> => {
    // return the parent node's items collection as children
    return this.orgNodeService.getChildrenOrgsAsyn(
      node.code,
      null,
      node.id
    );
  }

  // 初始化数据源
  public initTreeSource(): void {
    console.log('异步初始化数据源');
  }

  /**
   * 清空input
   *
   * @memberof ComboTreeDemoComponent
   */
  public clearNodeText(): void {
    return this.comboTreeComponent.clearText();
    console.log('清除节点');
  }

  /**
   * 调用内部组件方法通过searchText获取节点
   *
   * @param {string} searchText
   * @memberof ComboTreeDemoComponent
   */
  public searchItemByT(searchText: string): any {
    return this.comboTreeComponent.searchItemByText(searchText);
    console.log('searchItem', this.searchItem);
  }

  /**
   * 调用内部组件方法获取当前选中节点信息
   *
   * @memberof ComboTreeDemoComponent
   */
  public getSelectItem(): any {
    return this.comboTreeComponent.getSelectItems();
    console.log('选中的节点：', this.selectTreeNodeCodes);
  }

  /**
   * 根据code取节点信息
   *
   * @memberof ComboTreeDemoComponent
   */
  public getTreeNode(selectCode: string): any {
    return this.comboTreeComponent.getTreeNodeByCode(selectCode);
    console.log('code取节点信息', this.selectTreeNodeCodes);
  }

  /**
   * 失去焦点事件
   *
   * @memberof ComboTreeDemoComponent
   */
  public onBlurEvent($event): any {
    return this.comboTreeComponent.onBlur($event);
    console.log('code取节点信息', this.selectTreeNodeCodes);
  }

  public initValue(txt: string, val: any): any {
    this.comboTreeComponent.initValue(txt, val);
  }

  // 展示下拉树
  public opend(id: string): any {
    this.comboTreeComponent.opend(id);
  }

  // 关闭下拉树
  public closed(): any {
    this.comboTreeComponent.closed();
  }

  public getsSelectName(): any {
    return this.comboTreeComponent.getsSelectName();
  }
  // 设置默认选中项回显
  public selectValue(code: string): any {
    return this.comboTreeComponent.selectValue(code);
  }

}
