import { TestBed } from '@angular/core/testing';

import { OrgNodeService } from './org-node.service';

describe('OrgNodeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrgNodeService = TestBed.get(OrgNodeService);
    expect(service).toBeTruthy();
  });
});
