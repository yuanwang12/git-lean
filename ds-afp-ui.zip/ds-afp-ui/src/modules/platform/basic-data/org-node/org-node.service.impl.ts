import { Observable, Subject } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { DataStore } from '../../common/protocol/data-store';
import { DataStoreResponse } from '../../common/protocol/data-store-response';
import { QueryForm } from '../../common/protocol/query-form';
import { OrgNode } from './org-node';
import { OrgNodeService } from './org-node.service';

@Injectable()
export class OrgNodeServiceImpl implements OrgNodeService {
  constructor(private httpClient: HttpClient) {}

  private getAllOrgsUrl =
    '/platform-web/rest/inner/platform/orgNode/getAllOrgs';
  private getChildrenOrgsAsynUrl =
    '/platform-web/rest/inner/platform/orgNode/getChildrenOrgsAsyn';

  public getAllOrgs(): Observable<Array<OrgNode>> {
    const subject = new Subject<Array<OrgNode>>();
    this.httpClient.post(this.getAllOrgsUrl, null).subscribe({
      next: data => {
        const response = data as DataStoreResponse;
        if (response.ret === 'ok') {
          const orgNodeList = response.content as Array<OrgNode>;
          subject.next(orgNodeList);
        } else {
          subject.error(response.msg);
        }
      },
      error: err => {
        subject.error(err);
      },
      complete: () => {
        subject.complete();
      }
    });
    return subject;
  }

  public getChildrenOrgsAsyn(
    orgCode: string,
    orgRole: string,
    id: string
  ): Observable<Array<OrgNode>> {
    const subject = new Subject<Array<OrgNode>>();
    let getChildrenOrgAsynUrlAndData: string = this.getChildrenOrgsAsynUrl;
    if (orgCode || orgRole || id) {
      getChildrenOrgAsynUrlAndData = getChildrenOrgAsynUrlAndData + '?';
    }
    if (orgCode) {
      getChildrenOrgAsynUrlAndData =
        getChildrenOrgAsynUrlAndData + 'orgCode=' + orgCode + '&';
    }
    if (orgRole) {
      getChildrenOrgAsynUrlAndData =
        getChildrenOrgAsynUrlAndData + 'orgRole=' + orgRole + '&';
    }
    if (id) {
      getChildrenOrgAsynUrlAndData =
        getChildrenOrgAsynUrlAndData + 'id=' + id + '&';
    }
    this.httpClient.post(getChildrenOrgAsynUrlAndData, null).subscribe({
      next: data => {
        const response = data as DataStoreResponse;
        if (response.ret === 'ok') {
          const orgNodeList = response.content as Array<OrgNode>;
          subject.next(orgNodeList);
        } else {
          subject.error(response.msg);
        }
      },
      error: err => {
        subject.error(err);
      },
      complete: () => {
        subject.complete();
      }
    });
    return subject;
  }
}
