export class OrgNode {
  public id: string;
  public code: string;
  public name: string;
  public pid: string;
  public parentId: string;
  public searchCode: string;
  public selected: boolean;
  public text: string;
  public items: Array<any> = [];
}
