import { Observable } from 'rxjs';

import { Injectable } from '@angular/core';

import { OrgNode } from './org-node';

@Injectable()
export abstract class OrgNodeService {
  constructor() {}

  /**
   * 获取所有单位
   *
   * @abstract
   * @returns {Observable<OrgNode>}
   * @memberof OrgNodeService
   */
  abstract getAllOrgs(): Observable<Array<OrgNode>>;

  /**
   * 获取所有单位节点
   *
   * @abstract
   * @param {string} orgCode
   * @param {string} orgRole
   * @param {string} id
   * @returns {Observable<Array<OrgNode>>}
   * @memberof OrgNodeService
   */
  abstract getChildrenOrgsAsyn(
    orgCode: string,
    orgRole: string,
    id: string
  ): Observable<Array<OrgNode>>;
}
