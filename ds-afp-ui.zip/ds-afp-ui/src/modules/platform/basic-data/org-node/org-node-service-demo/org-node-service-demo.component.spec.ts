import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgNodeServiceDemoComponent } from './org-node-service-demo.component';

describe('OrgNodeServiceDemoComponent', () => {
  let component: OrgNodeServiceDemoComponent;
  let fixture: ComponentFixture<OrgNodeServiceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgNodeServiceDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrgNodeServiceDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
