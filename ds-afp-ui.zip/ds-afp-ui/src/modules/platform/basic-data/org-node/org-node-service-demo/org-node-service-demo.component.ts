import { Component, OnInit } from '@angular/core';

import { OrgNode } from '../org-node';
import { OrgNodeService } from '../org-node.service';

@Component({
  selector: 'ds-org-node-service-demo',
  templateUrl: './org-node-service-demo.component.html',
  styleUrls: ['./org-node-service-demo.component.css']
})
export class OrgNodeServiceDemoComponent implements OnInit {
  constructor(private orgNodeService: OrgNodeService) {}

  private orgNodes: Array<OrgNode>;

  private orgNodeTotalNum: number;

  // 根节点code
  private orgCode = '310000000000';

  // 根节点id(如果传递会有下级数据)
  private orgId = '8f849a8c63b3d0e70163b3d196590000';

  private childrenOrgNodes: Array<OrgNode>;

  ngOnInit() {}

  public getAllOrgs(): void {
    this.orgNodeService.getAllOrgs().subscribe({
      next: data => {
        console.log('getAllOrgs服务回值：', data);
        this.orgNodeTotalNum = data.length;
        this.orgNodes = data.slice(0, 7) as Array<OrgNode>;
      }
    });
  }

  public getChildrenOrgsAsyn(): void {
    this.orgNodeService
      .getChildrenOrgsAsyn(this.orgCode, null, this.orgId)
      .subscribe({
        next: data => {
          console.log('getChildrenOrgAsyn服务回值：', data);
          this.childrenOrgNodes = data as Array<OrgNode>;
        }
      });
  }
}
