import { Component, OnInit, ViewChild } from '@angular/core';
import { TestBed } from '@angular/core/testing';

import { OrgNodeComboTreeComponent } from '../org-node-combo-tree/org-node-combo-tree.component';

@Component({
  selector: 'ds-org-node-combo-tree-demo',
  templateUrl: './org-node-combo-tree-demo.component.html',
  styleUrls: ['./org-node-combo-tree-demo.component.css']
})
export class OrgNodeComboTreeDemoComponent implements OnInit {
  // 调用子组件得变量和方法
  @ViewChild(OrgNodeComboTreeComponent)
  private orgNodeComboTreeComponent: OrgNodeComboTreeComponent;

  private dsModel = '310000000000';
  private dsModelText = '上海市公安局';
  public selecedName: string;
  public searchItem: any;
  public selectedCode: any;
  public eleInformation: any;
  public keyArr: Array<string>;
  // private dsRootOrgId = '8f849a8c63b3d0e70163b3d196590000';

  // todo 父组件调用子组件方法
  // @ViewChild(OrgNodeComboTreeComponent)
  // private orgNodeComboTreeComponent: OrgNodeComboTreeComponent;

  constructor() {}

  ngOnInit() {}

  /**
   * 单位树选择事件
   */
  public selectUnit(event) {
    console.log('选择回掉函数：' + event);
    // this.node = event.node;
  }


 // 根据code取节点信息
  public onBlur($event): any {
    return this.orgNodeComboTreeComponent.onBlurEvent($event);
  }

  public dsOnSelectOrg(e: any): void {
    console.log('dsOnSelect', e.dataItem.code);
    if (e.dataItem) {
      this.dsModel = e.dataItem.id;
      this.dsModelText = e.dataItem.text;
    }
    this.onBlur(e);
    // 失焦事件
  }

  // 清除节点操作
  public clearText() {
    this.orgNodeComboTreeComponent.clearNodeText();
  }

  // 调用内部组件方法通过searchText获取节点
  public searchItemByText(searchText: string): any {
    this.searchItem =  JSON.stringify(this.orgNodeComboTreeComponent.searchItemByT(searchText));
  }

  // 根据code取节点信息
  public getTreeNode(): any {
    this.eleInformation = JSON.stringify(this.orgNodeComboTreeComponent.getTreeNode(this.dsModel));
  }

  // 通过指令获取选中节点code
  public getSelectItem() {
    this.selectedCode = this.orgNodeComboTreeComponent.getSelectItem();
  }

  // 设置选中文本
  public initValue() {
    this.orgNodeComboTreeComponent.initValue(this.dsModelText, this.dsModel);
  }

  // 打开下拉树
  public opend() {
    this.orgNodeComboTreeComponent.opend('8f849a8c63b3d0e70163b3d196590000');
  }
  // 关闭下拉树
  public closed() {
    this.orgNodeComboTreeComponent.closed();
  }

  // 获取选中节点名称
  public getsSelectName() {
    this.selecedName = this.orgNodeComboTreeComponent.getsSelectName();
  }

  // 通过code设置默认选中项
  public selectValue() {
    this.orgNodeComboTreeComponent.selectValue('310000320000');
  }

}
