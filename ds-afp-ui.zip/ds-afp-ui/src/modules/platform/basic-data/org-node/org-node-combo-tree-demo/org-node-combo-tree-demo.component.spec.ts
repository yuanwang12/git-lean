import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgNodeComboTreeDemoComponent } from './org-node-combo-tree-demo.component';

describe('OrgNodeComboTreeDemoComponent', () => {
  let component: OrgNodeComboTreeDemoComponent;
  let fixture: ComponentFixture<OrgNodeComboTreeDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgNodeComboTreeDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrgNodeComboTreeDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
