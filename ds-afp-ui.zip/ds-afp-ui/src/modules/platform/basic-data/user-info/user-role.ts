import { UserPrivilege } from './user-privilege';

export class UserRole {
  public id: string;
  public code: string;
  public name: string;
  public type: string;
  public memo: string;
  public createTime: Date;
  public updateTime: Date;
  public valid: boolean;
  public privileges: Array<UserPrivilege>;
}
