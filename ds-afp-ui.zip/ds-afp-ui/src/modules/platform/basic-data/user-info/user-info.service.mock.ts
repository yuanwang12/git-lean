import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import { Injectable } from '@angular/core';

import { LoginUser } from './login-user';
import { UserInfoService } from './user-info.service';

@Injectable()
export class UserInfoServiceMock implements UserInfoService {
  constructor() {}

  getCurrentUser(): Observable<LoginUser> {
    return null;
  }

  hasPrivileges(privilegeCode: string): boolean {
    return null;
  }
}
