import { OrgRole } from './org-role';
import { UserPrivilege } from './user-privilege';
import { UserRole } from './user-role';

export class LoginUser {
  public id: string;
  public code: string;
  public name: string;
  public regionId: string;
  public orgNodeId: string;
  public orgNodeCd: string;
  public orgNodeName: string;
  public orgSearchCode: string;
  public personId: string;
  public personName: string;
  public roles: Array<UserRole>;
  public orgRoles: Array<OrgRole>;
  public privileges: Array<UserPrivilege> = [];
  public lang: string;
}
