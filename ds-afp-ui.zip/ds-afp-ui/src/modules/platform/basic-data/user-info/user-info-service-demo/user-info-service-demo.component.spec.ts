import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserInfoServiceDemoComponent } from './user-info-service-demo.component';

describe('UserInfoServiceDemoComponent', () => {
  let component: UserInfoServiceDemoComponent;
  let fixture: ComponentFixture<UserInfoServiceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserInfoServiceDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserInfoServiceDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
