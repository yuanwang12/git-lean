import { UserInfoService } from 'src/modules/platform/basic-data/user-info/user-info.service';

import { AfterViewInit, Component, OnInit } from '@angular/core';

import { LoginUser } from '../login-user';

@Component({
  selector: 'ds-user-info-service-demo',
  templateUrl: './user-info-service-demo.component.html',
  styleUrls: ['./user-info-service-demo.component.css']
})
export class UserInfoServiceDemoComponent implements OnInit, AfterViewInit {
  constructor(private userInfoService: UserInfoService) {}
  public user: LoginUser = new LoginUser();
  public hasCheckedPrivilege: boolean = null;
  public privilegeToBeCheck: string = null;

  checkPrivilege(): void {
    if (this.privilegeToBeCheck) {
      this.hasCheckedPrivilege = this.userInfoService.hasPrivileges(
        this.privilegeToBeCheck
      );
    } else {
      this.hasCheckedPrivilege = false;
    }
  }

  ngOnInit(): void {
    // this.requestCurrentUser();
  }

  requestCurrentUser(forceReload: boolean): void {
    this.userInfoService.getCurrentUser(forceReload).subscribe(data => {
      this.user = data as LoginUser;
    });
  }

  ngAfterViewInit(): void {
    // this.userInfoService.getCurrentUser().subscribe(data => {
    //   this.user = data as LoginUser;
    // });
  }
}
