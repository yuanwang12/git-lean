import { Observable, of } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { DataStoreResponse } from '../../common/protocol/data-store-response';
import { LoginUser } from './login-user';
import { UserInfoService } from './user-info.service';

@Injectable()
export class UserInfoServiceImpl implements UserInfoService {
  // 获取当前用户信息
  constructor(private httpClient: HttpClient) {}

  private getCurrentUserUrl =
    '/platform-web/rest/inner/userInfo/getCurrentUser';
  private loginUser: LoginUser = null;

  public getCurrentUser(forceReload?: boolean): Observable<LoginUser> {
    if (this.loginUser && !forceReload) {
      return of(this.loginUser);
    } else {
      const subject = new Subject<LoginUser>();
      this.httpClient.post(this.getCurrentUserUrl, null).subscribe({
        next: data => {
          const response = data as DataStoreResponse;
          if (response.ret === 'ok') {
            this.loginUser = response.content as LoginUser;
            if (this.loginUser.code) {
              this.loginUser.privileges = [];
              if (
                Object.prototype.toString.call(this.loginUser.roles) ===
                '[object Array]'
              ) {
                for (const userRole of this.loginUser.roles) {
                  const privileges = userRole.privileges;
                  if (
                    Object.prototype.toString.call(privileges) ===
                    '[object Array]'
                  ) {
                    for (const privilege of privileges) {
                      this.loginUser.privileges.push(privilege);
                    }
                  }
                }
              }
            } else {
              this.loginUser = null;
            }
            subject.next(this.loginUser);
          } else {
            subject.error(response.msg);
          }
        },
        error: err => {
          this.loginUser = null;
          subject.error(err);
        },
        complete: () => {
          subject.complete();
        }
      });
      return subject;
    }
  }

  /**
   * 判断是否具有特权
   */
  public hasPrivileges(privilegeCode: string): boolean {
    if (this.loginUser) {
      const privileges = this.loginUser.privileges;
      if (Object.prototype.toString.call(privileges) === '[object Array]') {
        for (const item of privileges) {
          if (privilegeCode === item.code) {
            return true;
          }
        }
      }
      return false;
    } else {
      return false;
    }
  }
}
