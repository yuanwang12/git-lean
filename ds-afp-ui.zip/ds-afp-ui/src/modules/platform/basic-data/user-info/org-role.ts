export class OrgRole {
}
