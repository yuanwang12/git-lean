import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import { Injectable } from '@angular/core';

import { LoginUser } from './login-user';

@Injectable()
export abstract class UserInfoService {
  constructor() {}

  /**
   * 获取当前登录用户
   *
   * @abstract
   * @param {boolean} [forceReload] 是否强制加载，不传则为false
   * @returns {Observable<LoginUser>} 当前登录用户
   * @memberof UserInfoService
   */
  abstract getCurrentUser(forceReload?: boolean): Observable<LoginUser>;

  /**
   * 当前登录用户是否含有某特权，需要先加载完用户后才能进行使用
   *
   * @abstract
   * @param {string} privilegeCode 特权编码
   * @returns {boolean}
   * @memberof UserInfoService
   */
  abstract hasPrivileges(privilegeCode: string): boolean;
}
