import { EnumItem } from './enum-item';

export class Enum {
  key: string;
  enumItems: EnumItem[];
}
