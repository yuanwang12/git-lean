import { Enum } from './enum';
import { Query } from './query';

export class DataStore {
  data: any;
  query: Query;
  enums: { [key: string]: Enum };

  constructor() {
    this.query = {
      queryForm: {
        queryData: {}
      },
      pageForm: {
        currentPage: 1,
        pageSize: 20,
        totalSize: 0,
        totalPage: 0
      }
    };
  }
}
