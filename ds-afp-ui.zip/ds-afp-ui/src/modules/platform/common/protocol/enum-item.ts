export class EnumItem {
  text: string;
  value: string;
}
