export class QueryForm {
  queryData: any;
}
