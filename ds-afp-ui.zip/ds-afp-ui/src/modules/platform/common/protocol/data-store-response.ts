import { DataStore } from './data-store';

export class DataStoreResponse {
  public ret: string;
  public msg: string;
  public content: DataStore | object;
  constructor() {
    this.ret = null;
    this.msg = null;
    this.content = null;
  }
}
