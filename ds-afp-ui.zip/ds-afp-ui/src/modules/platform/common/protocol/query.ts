import { PageForm } from './page-form';
import { QueryForm } from './query-form';

export class Query {
  queryForm: QueryForm;
  pageForm: PageForm;
}
