export class PageForm {
  currentPage: number;
  pageSize: number;
  totalSize: number;
  totalPage: number;
}
