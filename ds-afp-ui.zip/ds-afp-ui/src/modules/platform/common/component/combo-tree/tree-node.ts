export class TreeNode {
  public id: string;
  public code: string;
  public text: string;
  public parentId: string;
  constructor(id: string, code: string, text: string, parentId: string) {
    this.id = id;
    this.code = code;
    this.text = text;
    this.parentId = parentId;
  }
}
