import { Observable, of } from 'rxjs';

import { Component, EventEmitter, forwardRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { TreeNode } from './tree-node';
// import { TreeViewComponent } from '@progress/kendo-angular-treeview';
import { TreeViewModule } from '@progress/kendo-angular-treeview';

/**
 * 组合下拉树
 * 方法执行的顺序是 ngOnInit-> writeValue-> registerOnChange -> registerOnTouched -> ngAfterContentInit -> ngAfterViewInit
 * @author Mark
 * @export
 * @class ComboTreeComponent
 * @implements {OnInit}
 * @implements {ControlValueAccessor}
 */
@Component({
  selector: 'ds-combo-tree',
  templateUrl: './combo-tree.component.html',
  styleUrls: ['./combo-tree.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ComboTreeComponent),
      multi: true
    }
  ]
})
export class ComboTreeComponent implements OnInit, ControlValueAccessor {
  constructor() {}
  @Input() data: any;
  @Input() dsHasChildren: any;
  @Input() dsFetchChildren: any;

  @ViewChild(TreeViewModule)
  public treeViewModule: TreeViewModule;

  @Output() selected = new EventEmitter();


  public isblock: boolean;

  public treeNodesAsync: Observable<Array<TreeNode>>;
  public treeNodes: Array<TreeNode>;

  /**
   * 选中的项
   */
  public selectedKeys: Array<string> = [];
  // public selectedKeys: any[] = ['0_1'];

  /**
   * 展开的的项
   */
  public expandedKeys: Array<string> = [];

  public arr: Array<string> = [];

  public selectedText = '';

  public selectItems: any;

  public result: any;

  public status: boolean;


  onModelChange: (newValue: any) => void;

  ngOnInit() {
    this.treeNodesAsync = this.data as Observable<Array<TreeNode>>;
  }

  // public hasChildren = (item: any) => item.items && item.items.length > 0;
  // public fetchChildren = (item: any) => of(item.items);

  /**
   * from ControlValueAccessor
   * 当外部数据修改时被调用来更新内部的。
   * @param {string} value
   * @memberof ComboTreeComponent
   */
  public writeValue(value: string): void {
    this.selectedKeys = [];
    this.expandedKeys = [];
    if (this.data) {
      if (value && value !== '' && (this.data as Observable<Array<TreeNode>>)) {
        this.treeNodesAsync.subscribe({
          next: ret => {
            this.treeNodes = ret as Array<TreeNode>;
            // this.forEachHierarchicalData(this.treeNodes, value);
            this.selectedKeys.push(value);
            if (this.selectedKeys.length === 0) {
              // 无匹配值，同步将父子组件通过ngModel绑定的变量置空
              this.onModelChange(null);
            }
          },
          error: err => {
            console.log(err);
          }
        });
      }
    } else {
      // 同步将父子组件通过ngModel绑定的变量置空
      this.onModelChange(null);
    }
  }

  public forEachHierarchicalData(
    treeNodes: Array<TreeNode>,
    value: string
  ): void {
    if (
      this.selectedKeys.length === 0 &&
      !this.treeNodeCodeInTreeNodeArray(treeNodes, value)
    ) {
      treeNodes.forEach(treeNode => {
        this.dsFetchChildren(treeNode).subscribe({
          next: ret => {
            if (ret as Array<TreeNode>) {
              this.treeNodes = this.treeNodes.concat(ret);
              // this.treeNodesAsync = of(this.treeNodes);
              this.forEachHierarchicalData(ret, value);
            }
          }
        });
      });
    } else {
      return;
    }
  }

  /**
   * 判断code是否包含在数组中
   *
   * @param {Array<TreeNode>} treeNodes
   * @param {string} value
   * @returns
   * @memberof ComboTreeComponent
   */
  public treeNodeCodeInTreeNodeArray(
    treeNodes: Array<TreeNode>,
    value: string
  ) {
    for (let i = 0; i < treeNodes.length; i++) {
      if (treeNodes[i].code === value) {
        this.selectedKeys.push(value);
        return true;
      }
    }
    return false;
  }

  /**
   * from ControlValueAccessor
   * 把这个 fn 注册到内部方法上, 当内部值更新时调用它 this.publishValue(newValue);
   * @param {*} fn
   * @memberof ComboTreeComponent
   */
  registerOnChange(fn: (newValue: any) => void): void {
    this.onModelChange = fn;
  }

  /**
   *  from ControlValueAccessor
   * 也是一样注册然后调用当 touched，暂时无用
   * ?touched是什么状态？
   *
   * @param {*} fn
   * @memberof ComboTreeComponent
   */
  registerOnTouched(fn: any): void {
    console.log('registerOnTouched');
  }

  /**
   * 拿到每一层节点,用于展开
   * @param {string} id
   * @memberof ComboTreeComponent
   */
  public GetAncestorNode(id: string): void {
    // console.log(id);
    if (id || id !== '') {
      this.expandedKeys.push(id);
      (this.treeNodes as Array<TreeNode>).some(item => {
        if (item.id === id && item.parentId !== '') {
          this.expandedKeys.push(item.parentId);
          this.GetAncestorNode(item.parentId);
          return true;
        }
        return false;
      });
    }
  }







  // 用在组件上
  /**
   * 当前节点是否查询下级
   *
   * @param {*} node
   * @returns {boolean}
   * @memberof ComboTreeComponent
   */
  public hasChildren = (item: any) => {
    return this.dsHasChildren(item);
  }

  /**
   * 查询下级节点
   *
   * @param {*} node
   * @returns {Observable<any[]>}
   * @memberof ComboTreeComponent
   */
  public fetchChildren = (node: any): Observable<any[]> => {
    // return the parent node's items collection as children
    return this.dsFetchChildren(node);
  }

  public selectedKeysChange(event: any): void {
    console.log(event);
    // this.isblock=false;
  }

  /**
   * 当选择一项会触发此方法
   * @param {*} e
   * @memberof ComboTreeComponent
   */
  public handleSelection(e: any): void {
    // 更新input
    this.selectedText = e.dataItem.text;
    // 同步将父子组件通过ngModel绑定的变量更新（update）
    this.onModelChange(e.dataItem.code);
    // 向外部提交事件
    this.selected.emit(e);
    this.isblock = false;
    // 清除展开的层级
    this.expandedKeys = [];
    // 重新拿到每一层节点,用于展开
    this.GetAncestorNode(e.dataItem.pid);
    console.log(this.expandedKeys);
  }







  // 需暴露出去的API
  /**
   * 当失去焦点
   *
   * @param {*} event
   * @memberof ComboTreeComponent
   */
  public onBlur(event: any): void {
    if (event.relatedTarget == null) {
      this.isblock = false;
    }
  }
  /**
   * 清空input
   *
   * @memberof ComboTreeComponent
   */
  public clearText(): void {
    this.selectedText = '';
    // 清除展开的节点
    this.expandedKeys = [];
    // 清除选中的节点
    this.selectedKeys = [];
    // 同步将父子组件通过ngModel绑定的变量重置（update）
    this.onModelChange(null);
  }

  /**
   * 根据text文本获取节点信息
   * @param {string} searchText
   * @returns {TreeNode}
   * @memberof ComboTreeComponent
   */
  public searchItemByText(searchText: string): TreeNode {
    console.log(searchText);
    let searchItem: TreeNode;
    (this.treeNodes as Array<TreeNode>).forEach(item => {
      if (searchText && item.text === searchText) {
        searchItem = item;
      }
    });
    return searchItem;
  }

  /**
   * 获取当前选中节点code
   *
   * @returns {TreeNode}
   * @memberof ComboTreeComponent
   */
  public getSelectItems(): Array<string> {
    return this.selectedKeys;
  }

  /**
   * 根据code取节点信息
   *
   * @param {string} code
   * @returns {TreeNode}
   * @memberof ComboTreeComponent
   */
  public getTreeNodeByCode(code: string): TreeNode {
    let treeNodeItem: TreeNode;
    this.treeNodes.forEach(element => {
      if (element.code === code) {
        treeNodeItem = element;
      }
    });
    return treeNodeItem;
  }

  /**
   * name
   */
  // 输入框输入指定内容
  public initText(text: string) {
    this.selectedText = text;
  }

   // 设置选中植
   public initValue(txt: string, node: any) {
    let vals = [];
    if (node instanceof Array) {
        vals = node;
    } else {
        vals.push(node);
    }
    this.selectedText = txt;
    // this.selectItems = vals;
    this.selectedKeys = [node]; // 设置选中项为当前展示值
}

 // 获取显示的名称
 public getsSelectName() {
  return this.selectedText;
 }

// 将node转换为dataItem;
 public dataItem(node) {
  // return this.treeViewModule.dataItem(node);
}

// 查询txt的节点(node)
 public findByText(text) {
    // return this.treeViewModule.findByText(text);
}

// 展开指定值的数组
public expandPath(valArray) {
  // $scope.treeViewModule.dataSource.fetch({
  //     schema: {
  //         model: {
  //             id: $scope.options.dataValueField
  //         }
  //     }
  // });
  // return $scope.treeViewModule.expandPath(valArray);
}

  /**
   * 通过值来选择项
   */
  public selectValue(code: string): void {
    this.treeNodes.forEach(element => {
      if (element.code === code) {
        this.selectedText = element.text;
      } else {
        this.result = this.fetchChildren(element);
        this.result.subscribe({
          next: res => {
            this.fetchArray(res, code);
          }
        });
      }
    });
  }

  /**
   * 循环遍历出与所设置code相等得项，然后取到当前项text复值给input
   */
  public fetchArray(resArr, code) {
    this.status = resArr.forEach(element => {
      if (element.code === code) {
        this.selectedText = element.text;
        this.selectedKeys = [element.code]; // 设置选中项为当前展示值
        return true;
      } else if (element.items.length > 0) {
        this.fetchArray(element.items, code);
      }
    });
  }

// 显示下拉树
public opend(id: string) {
  this.expandedKeys = [id];
}

// 关闭下拉树
public closed() {
  this.expandedKeys = [];
}

}
