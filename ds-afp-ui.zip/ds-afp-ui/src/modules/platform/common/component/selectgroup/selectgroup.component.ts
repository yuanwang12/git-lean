import { element } from 'protractor';

import {
    Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2
} from '@angular/core';

import { DictionaryItem } from '../../../dictionary/dictionary-item';
import { DictionaryValue } from '../../../dictionary/dictionary-value';
import { DictionaryService } from '../../../dictionary/dictionary.service';

@Component({
  selector: 'ds-selectgroup',
  templateUrl: './selectgroup.component.html',
  styleUrls: ['./selectgroup.component.css']
})
export class SelectgroupComponent implements OnInit {
  constructor(
    private render: Renderer2,
    private dictionaryService: DictionaryService,
    private ele: ElementRef
  ) {}

  public dataItemValues: Array<any>;
  public initialItemValuesArray: Array<string>;
  @Input()
  public dataSource: Array<any>;
  @Input() isMultiSelect: string;
  @Input()
  public dsModel: Array<any>;
  @Output()
  public dsModelChange: EventEmitter<
    Array<DictionaryItem>
  > = new EventEmitter();
  @Output()
  public valueChange: EventEmitter<object> = new EventEmitter();
  public isSelected: boolean;
  public selectedMap: Map<string, any> = new Map<string, any>();
  ngOnInit() {
    // 加载数据源
    if (!this.dataSource) {
      return;
    }
    this.loadDataSource(this.dataSource);

    // 获取初始化数据的code数组
    this.initialItemValuesArray = [];
    for (const i of this.dsModel) {
      this.initialItemValuesArray.push(i.code || i.value);
    }
  }

  // 加载数据源
  public loadDataSource(data: Array<any>): void {
    this.dataItemValues = data;
    for (const i of data) {
      this.selectedMap.set(i.code, i);
    }
  }

  // 点击事件方法
  public dataClick(
    dataItemValue: any,
    event:any,
    dataItemValueCode: string
  ): void {
    if (!this.isMultiSelect) {
      // 单选
      this.render.removeClass(
        this.ele.nativeElement.querySelector('.selectedStyle'),
        'selectedStyle'
      );
      // 当前选项为选中状态
      this.render.addClass(event.currentTarget, 'selectedStyle');
      this.dsModel[0] = dataItemValue;
    } else {
      // 多选
      let isSelected = false;
      for (const style of event.currentTarget.classList) {
        if (style === 'selectedStyle') {
          isSelected = true;
          this.render.removeClass(event.currentTarget, 'selectedStyle');
        }
      }
      if (!isSelected) {
        this.render.addClass(event.currentTarget, 'selectedStyle');
      }
      // 没有选择的按钮
      if (!isSelected) {
        if (this.initialItemValuesArray.indexOf(dataItemValueCode) === -1) {
          this.initialItemValuesArray.push(dataItemValueCode);
        }
      } else {
        // 已经选择的按钮
        this.initialItemValuesArray.splice(
          this.initialItemValuesArray.indexOf(dataItemValueCode),
          1
        );
      }
      this.dsModel = [];
      for (const i of this.initialItemValuesArray) {
        this.dsModel.push(this.selectedMap.get(i));
      }
    }
    this.dsModelChange.emit(this.dsModel);
    this.valueChange.emit(this.dsModel);
  }
}
