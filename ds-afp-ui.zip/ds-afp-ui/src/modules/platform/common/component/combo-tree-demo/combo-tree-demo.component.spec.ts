import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComboTreeDemoComponent } from './combo-tree-demo.component';

describe('ComboTreeDemoComponent', () => {
  let component: ComboTreeDemoComponent;
  let fixture: ComponentFixture<ComboTreeDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComboTreeDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComboTreeDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
