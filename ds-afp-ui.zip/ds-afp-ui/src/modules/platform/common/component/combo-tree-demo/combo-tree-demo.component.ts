import { Observable } from 'rxjs';

import { Component, Input, OnInit, ViewChild } from '@angular/core';

import { OrgNodeService } from '../../../basic-data/org-node/org-node.service';
import { ComboTreeComponent } from '../combo-tree/combo-tree.component';
import { TreeNode } from '../combo-tree/tree-node';

@Component({
  selector: 'ds-combo-tree-demo',
  templateUrl: './combo-tree-demo.component.html',
  styleUrls: ['./combo-tree-demo.component.css']
})
export class ComboTreeDemoComponent implements OnInit {
  // public treeSource: Array<TreeNode> = [
  //   new TreeNode('313', '313', '北京', null),
  //   new TreeNode('317', '317', '昌平', '313'),
  //   new TreeNode('318', '318', '海淀', '313'),
  //   new TreeNode('213', '213', '上海', null),
  //   new TreeNode('217', '217', '浦东', '213'),
  //   new TreeNode('218', '218', '黄埔', '213'),
  //   new TreeNode('2171', '2171', '南汇新城', '217')
  // ];
  public treeSource: Observable<Array<TreeNode>>;

  @ViewChild(ComboTreeComponent)
  private comboTreeComponent: ComboTreeComponent;

  public selectCode: string;

  // public selectItemText: string;

  public selectItem: TreeNode;

  public searchItem: TreeNode;

  public selectTreeNodeCodes: Array<string>;

  public treeData: Array<TreeNode>;

  constructor(private orgNodeService: OrgNodeService) {}

  ngOnInit() {
    this.selectCode = '121002';
    // this.treeSource = this.data;
    // this.searchItemByCode();
    this.treeSource = this.orgNodeService.getChildrenOrgsAsyn(
      '310000000000',
      null,
      null
    );
  }

  /**
   * 当内部组件选择一个节点时触发
   *
   * @param {*} e
   * @memberof ComboTreeDemoComponent
   */
  public onSelected(e: any): void {
    console.log('selectItem', e.dataItem);
    this.selectItem = e.dataItem;
    // this.selectItemText = e.dataItem.text;
  }

  /**
   * 初始化选择节点
   *
   * @param {string} initCode
   * @memberof ComboTreeDemoComponent
   */
  public initValue(initCode: string): void {
    this.selectCode = initCode;
    // this.searchItemByCode();
  }

  // public searchItemByCode(): void {
  //   if (this.treeSource) {
  //     (this.treeSource as Array<TreeNode>).forEach(item => {
  //       if (item.code === this.selectCode) {
  //         this.selectItem = item;
  //       }
  //     });
  //   }
  // }

  /**
   * 调用内部组件方法通过searchText获取节点
   *
   * @param {string} searchText
   * @memberof ComboTreeDemoComponent
   */
  public searchItemByText(searchText: string): void {
    this.searchItem = this.comboTreeComponent.searchItemByText(searchText);
    console.log('searchItem', this.searchItem);
  }

  /**
   * 调用内部组件方法获取当前选中节点信息
   *
   * @memberof ComboTreeDemoComponent
   */
  public getSelectItem(): void {
    this.selectTreeNodeCodes = this.comboTreeComponent.getSelectItems();
    console.log('选中的节点：', this.selectTreeNodeCodes);
  }

  public initTreeSource(): void {}

  /**
   * 当前节点是否查询下级
   *
   * @param {*} node
   * @returns {boolean}
   * @memberof ComboTreeComponent
   */
  public dsHasChildren = (item: any): boolean => {
    return true;
  }

  /**
   * 查询下级节点
   *
   * @param {*} node
   * @returns {Observable<any[]>}
   * @memberof ComboTreeComponent
   */
  public dsFetchChildren = (node: any): Observable<any[]> => {
    // return the parent node's items collection as children
    return this.orgNodeService.getChildrenOrgsAsyn(
      '310000000000',
      null,
      node.id
    );
  }
}
