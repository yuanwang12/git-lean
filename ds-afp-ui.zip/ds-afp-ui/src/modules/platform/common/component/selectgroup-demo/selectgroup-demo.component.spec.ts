import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectgroupDemoComponent } from './selectgroup-demo.component';

describe('SelectgroupDemoComponent', () => {
  let component: SelectgroupDemoComponent;
  let fixture: ComponentFixture<SelectgroupDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectgroupDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectgroupDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
