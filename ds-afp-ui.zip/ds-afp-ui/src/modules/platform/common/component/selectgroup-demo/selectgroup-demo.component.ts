import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ds-selectgroup-demo',
  templateUrl: './selectgroup-demo.component.html',
  styleUrls: ['./selectgroup-demo.component.css']
})
export class SelectgroupDemoComponent implements OnInit {
  constructor() {}
  public dataSource = [
    { code: 'ZB', name: '值班' },
    { code: 'XB', name: '下班' },
    { code: 'LY', name: '旅游' }
  ];

  public dataSource1 = [
    { code: 'ZB', name: '值班' },
    { code: 'XB', name: '下班' },
    { code: 'LY', name: '旅游' }
  ];

  public dsModel = [{ code: 'LY', name: '旅游' }];
  public dsModel1 = [{ code: 'LY', name: '旅游' }];
  public currentValues: string;
  public currentValues1: string;
  ngOnInit() {
    this.currentValues = JSON.stringify(this.dsModel);
    this.currentValues1 = JSON.stringify(this.dsModel1);
  }

  public valueChange(selectedValues: Array<any>) {
    this.currentValues = JSON.stringify(this.dsModel);
  }

  public valueChange1(selectedValues: Array<any>) {
    this.currentValues1 = JSON.stringify(this.dsModel1);
  }
}
