/*通过截取后缀名和正则表达式判断文件的格式*/
export function checkFileTypebylastIndexOf(fileName: any): any {
  let fileFormat: any = null;
  // 图像格式
  const tpRegExp: RegExp = /\.(gif|jpg|jpeg|png|GIF|JPG|PNG)$/i;
  // 音频格式
  const ypRegExp: RegExp = /\.(MP3|AAC|WAV|WMA|CDA|FLAC|M4A|MKA|MP2|MPA|MPC|APE|OFR|OGG|RA|WV|TTA|AC3|DTS)$/i;
  // 视频格式
  const spRegExp: RegExp = /\.(AVI|ASF|WMV|AVS|FLV|MKV|MOV|3GP|MP4|MPG|MPEG|DAT|OGM|VOB|RM|RMVB|TS|TP|IFO|NSV|M2TS)$/i;
  // 其他格式
  const qtRegExp: RegExp = /\.(DVR-MS|DIVX|M4V|M2V|PART|VP6|RAM|RMM|SWF|TRP|FLC|FLI)$/i;
  const suffix = '.' + fileName.slice(fileName.lastIndexOf('.') + 1);
  if (tpRegExp.test(suffix)) {
    // 图像
    fileFormat = 'Image';
  } else if (ypRegExp.test(suffix)) {
    // 音频
    fileFormat = 'Audio';
  } else if (spRegExp.test(suffix)) {
    // 视频
    fileFormat = 'Video';
  } else if (qtRegExp.test(suffix)) {
    // 其他
    fileFormat = 'Other';
  }
  return fileFormat;
}
