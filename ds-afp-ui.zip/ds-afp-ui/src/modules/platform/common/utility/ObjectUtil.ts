// 模拟数组的Indexof方法（用于只有一层的对像数组属性遍历）；
// 参数：对像数组,对象，判断条件（属性），从第几的个元素开始；
// 返回值：元素角标
export function checkExistIndexof(
  list: Array<object>,
  obj: object,
  key: string,
  start: number
): any {
  let i: number;
  let length: number;
  (i = 0), (length = list.length);
  if (list == null || list === undefined) {
    return -1;
  }
  if (start != null && start !== undefined) {
    // 添加对start为负值时的处理
    if (typeof start === 'number') {
      i = start < 0 ? Math.max(0, length + start) : start;
    }
  }
  //     // 如果浏览器支持ES5 indexOf，则直接使用它
  //    if(list.prototype.indexOf && list.indexOf === list.prototype.indexOf){
  //      return list.indexOf(obj,start);
  //    }
  // for (var key in obj) {
  //     if (obj.hasOwnProperty(key)) {
  //         var element = obj[key];
  //         alert(obj.key);
  //   }
  // && list[i].hasOwnProperty(key) }
  for (; i < list.length; i++) {
    if (obj.hasOwnProperty(key)) {
      if (obj[key] === list[i][key]) {
        // alert(obj[key]);
        // alert(list[i][key]);
        return i;
      }
    } else {
      return -1;
    }
  }
  return -1;
}

/**
 * 对象深拷贝
 * @param obj
 */
export function deepCopy(obj) {
  if (!obj || typeof obj !== 'object') {
    return null;
  } else {
    const objStr = JSON.stringify(obj);
    return JSON.parse(objStr);
  }
}

export function copyProperties(distObj, srcObj) {
  if (typeof distObj !== 'object' || typeof srcObj !== 'object') {
    console.error('copy properties ERROR!');
  }
  for (const key in distObj) {
    if (
      srcObj.hasOwnProperty(key) &&
      ['string', 'number', 'boolean'].indexOf(typeof srcObj[key]) >= 0
    ) {
      distObj[key] = srcObj[key];
    }
  }
}

/**
 * 匿名处理
 */
export function anonymous(item) {
  if (item.BJR) {
    item.BJR = '匿名';
  }
  if (item.BJRXB) {
    item.BJRXB = '';
  }
  if (item.LXDH) {
    item.LXDH = '******';
  }
  if (item.ZJHM) {
    item.ZJHM = '******';
  }
  if (item.LXDZ) {
    item.LXDZ = '******';
  }
  return item;
}
