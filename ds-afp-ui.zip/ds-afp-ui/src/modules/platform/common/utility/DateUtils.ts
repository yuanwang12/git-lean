// 将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// dateFormat(new Date(), 'yyyy-MM-dd hh:mm:ss.S') ==> 2006-07-02 08:09:04.423
// dateFormat(new Date(), 'yyyy-M-d h:m:s.S')      ==> 2006-7-2 8:9:4.18
export function dateFormat(date, fmt) {
  // author: meizz
  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds() // 毫秒
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(
      RegExp.$1,
      (date.getFullYear() + '').substr(4 - RegExp.$1.length)
    );
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      );
    }
  }
  return fmt;
}

/**
 * 校验字符串是否为特定的日期时间格式
 * @param dateTimeStr yyyy-MM-dd hh:mm:ss
 */
export function datePattern(dateTimeStr: string) {
  const regExp = new RegExp(
    /^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)) ([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/
  );
  return regExp.test(dateTimeStr);
}

/**
 * 获取传入日期的最小时间,传入为空时取当前日期
 * @export
 * @param {string} value
 * @returns {Date}
 */
export function getMinTime(value: string): Date {
  let date = null;
  if (value) {
    date = new Date(value);
  }
  if (date) {
    date = new Date();
    const dateStr =
      date.getFullYear() +
      '-' +
      (date.getMonth() + 1) +
      '-' +
      date.getDate() +
      ' 0:0:0';
    return new Date(dateStr);
  }
}

/**
 * 获取传入日期的最大时间,传入为空时取当前日期
 * @export
 * @param {*} value
 * @returns {Date}
 */
export function getMaxTime(value): Date {
  let date = null;
  if (value) {
    date = new Date(value);
  }
  if (date) {
    date = new Date();
    const dateStr =
      date.getFullYear() +
      '-' +
      (date.getMonth() + 1) +
      '-' +
      date.getDate() +
      ' 23:23:59';
    return new Date(dateStr);
  }
}

/**
 * 格式化时间
 * 对Date的扩展，将 Date 转化为指定格式的String
 * 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
 * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 * 例子：
 * (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
 * (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
 * @export
 * @param {Date} date
 * @param {string} pattern
 * @returns {string}
 */
export function FormatDate(date: Date, pattern: string): string {
  if (!date) {
    date = new Date();
  }
  if (!pattern) {
    pattern = 'yyyy-MM-dd hh:mm:ss';
  }
  // author: meizz
  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds() // 毫秒
  };
  if (/(y+)/.test(pattern)) {
    pattern = pattern.replace(
      RegExp.$1,
      (this.getFullYear() + '').substr(4 - RegExp.$1.length)
    );
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(pattern)) {
      pattern = pattern.replace(
        RegExp.$1,
        RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      );
    }
  }
  return pattern;
}

/**
 * 将时间字符串格式化
 *
 * @export
 * @param {*} dateStr
 * @param {*} pattern
 * @returns {string}
 */
export function formatDateStr(dateStr, pattern): string {
  return FormatDate(new Date(dateStr), pattern);
}

/**
 * 获取包含传入年月的所有天数
 * @export
 * @param {*} year
 * @param {*} month
 * @returns {Array<Date>}
 */
export function getAllDate(year, month): Array<Date> {
  // 获取年、月
  const today = new Date();
  year = year ? year : today.getFullYear();
  month = month ? month : today.getMonth();

  const currentYear = today.getFullYear();
  const currentMonth = month + 1 < 10 ? '0' + (month + 1) : month + 1;
  const currentDate = today.getDate();
  let totalDay; // 当月的总天数

  const lastMonthDays = []; // 剩余的上个月的日期
  const monthDays = []; // 本月的日期
  const nextMonthDays = []; // 下月的日期

  const calendarArray = [];

  totalDay = new Date(year, month + 1, 0).getDate(); // 计算当月的天数

  let firstDay = new Date(year, month, 1).getDay(); // 当前显示的月份的1号是星期几

  firstDay = firstDay === 0 ? 7 : firstDay; // 让7代表星期日

  const lastMonthDay = new Date(year, month, 0).getDate(); // 上个月的天数

  let lastDayCal = lastMonthDay - firstDay + 2; // 计算上个月在第一行显示的开始的天数
  // 一旦超出上月总天数则在第一行不显示  如上个月总天数为31，若lastDayCal为32 则不显示上月天数

  let num = 1; // 本月1号
  let nextNum = 1; // 下月1号
  // 获取li元素 填充
  for (let r = 1; r < 43; r++) {
    for (let line = 1; line < 8; line++) {
      if (r === 1) {
        // 在第一行 与第一天进行判断 大于等于第一天时载入日期
        // 1周一    7是星期日   3月1号是周四   firstDay本月1号
        if (line >= firstDay) {
          const days = num++;

          monthDays.push(days); // 本月的日期
        } else {
          const lastDays = lastDayCal++;

          lastMonthDays.push(lastDays); // 上个月的日期
        }
      } else {
        // 判断是否超出天数 ,不超出则继续加，超出则显示下个月日期   //超出7天换行
        if (num <= totalDay) {
          // 如果日期 小于总天数 继续显示本月的日期   否则显示下月的

          const days1 = num++;

          monthDays.push(days1);
        } else {
          // 剩余天数多于7天，说明下月开始日期在第五行，显示5行	否则显示6行
          if (42 - lastMonthDays.length - monthDays.length >= 7) {
            if (nextNum <= 42 - 7 - lastMonthDays.length - monthDays.length) {
              const nextDays = nextNum++;
              if (nextDays <= 7) {
                nextMonthDays.push(nextDays);
              }
            }
          } else {
            if (nextNum <= 42 - lastMonthDays.length - monthDays.length) {
              const nextDays = nextNum++;
              if (nextDays <= 7) {
                nextMonthDays.push(nextDays);
              }
            }
          }
        }
      }
    }
  }

  const arrays = [lastMonthDays, monthDays, nextMonthDays];

  for (let i = 0; i < arrays.length; i++) {
    for (let j = 0; j < arrays[i].length; j++) {
      // 上一个月的日期
      if (i === 0) {
        const obj1 = {
          text: 'lastMonth',
          day: arrays[i][j],
          isSmallThanToday: null
        };
        let lastY = null;
        let lastM = null;
        if (currentMonth - 0 === 1) {
          lastY = currentYear - 0 - 1;
          lastM = 12;
        } else {
          lastY = currentYear - 0;
          lastM = currentMonth - 0 - 1;
        }
        if (lastY > currentYear - 0) {
          obj1.isSmallThanToday = false;
        } else if (lastY === currentYear - 0) {
          if (lastM > currentMonth - 0) {
            obj1.isSmallThanToday = false;
          } else if (lastM === currentMonth - 0) {
            if (arrays[i][j] >= currentDate - 0) {
              obj1.isSmallThanToday = false;
            } else {
              obj1.isSmallThanToday = true;
            }
          } else {
            obj1.isSmallThanToday = true;
          }
        } else {
          obj1.isSmallThanToday = true;
        }
        calendarArray.push(obj1);
      } else if (i === 1) {
        let obj2;
        // 本月的日期
        if (j === 0) {
          obj2 = {
            month: month + 1,
            text: 'currentMonth',
            day: arrays[i][j],
            isSmallThanToday: null
          };
          if (currentYear - 0 > currentYear - 0) {
            obj2.isSmallThanToday = false;
          } else if (currentYear - 0 === currentYear - 0) {
            if (currentMonth - 0 > currentMonth - 0) {
              obj2.isSmallThanToday = false;
            } else if (currentMonth - 0 === currentMonth - 0) {
              if (arrays[i][j] >= currentDate - 0) {
                obj2.isSmallThanToday = false;
              } else {
                obj2.isSmallThanToday = true;
              }
            } else {
              obj2.isSmallThanToday = true;
            }
          } else {
            obj2.isSmallThanToday = true;
          }
        } else {
          obj2 = {
            text: 'currentMonth',
            day: arrays[i][j],
            isSmallThanToday: null
          };

          if (currentYear - 0 > currentYear - 0) {
            obj2.isSmallThanToday = false;
          } else if (currentYear - 0 === currentYear - 0) {
            if (currentMonth - 0 > currentMonth - 0) {
              obj2.isSmallThanToday = false;
            } else if (currentMonth - 0 === currentMonth - 0) {
              if (arrays[i][j] >= currentDate - 0) {
                obj2.isSmallThanToday = false;
              } else {
                obj2.isSmallThanToday = true;
              }
            } else {
              obj2.isSmallThanToday = true;
            }
          } else {
            obj2.isSmallThanToday = true;
          }
        }
        calendarArray.push(obj2);
      } else {
        // 下月的日期
        const obj3 = {
          text: 'nextMonth',
          day: arrays[i][j],
          isSmallThanToday: null
        };
        let nextY = null;
        let nextM = null;
        if (currentMonth - 0 === 12) {
          nextY = currentYear - 0 + 1;
          nextM = 1;
        } else {
          nextY = currentYear - 0;
          nextM = currentMonth - 0 + 1;
        }
        if (nextY > currentYear - 0) {
          obj3.isSmallThanToday = false;
        } else if (nextY === currentYear - 0) {
          if (nextM > currentMonth - 0) {
            obj3.isSmallThanToday = false;
          } else if (nextM === currentMonth - 0) {
            if (arrays[i][j] >= currentDate - 0) {
              obj3.isSmallThanToday = false;
            } else {
              obj3.isSmallThanToday = true;
            }
          } else {
            obj3.isSmallThanToday = true;
          }
        } else {
          obj3.isSmallThanToday = true;
        }
        calendarArray.push(obj3);
      }
    }
  }
  return calendarArray;
}
