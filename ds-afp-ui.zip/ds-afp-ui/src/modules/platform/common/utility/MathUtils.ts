// 获得指定范围的随机数
export function GetRandomNum(min: number, max: number) {
  const range = max - min;
  const rand = Math.random();
  return min + Math.round(rand * range);
}

/**
 * 状态值比较
 * @param val1
 * @param val2
 */
export function compareStatusValue(val1, val2) {
  try {
    if (typeof val1 === 'string') {
      val1 = parseInt(val1, 10);
    }
    if (typeof val2 === 'string') {
      val2 = parseInt(val2, 10);
    }
    return val1 > val2;
  } catch (err) {
    console.log('unclassified statue value');
    return false;
  }
}
