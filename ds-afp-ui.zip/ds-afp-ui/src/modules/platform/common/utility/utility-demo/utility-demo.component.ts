import { Component, OnInit } from '@angular/core';
import { getMinTime, getMaxTime } from '../DateUtils';
import { checkFileTypebylastIndexOf } from '../FileUtils';
import { GetRandomNum, compareStatusValue } from '../MathUtils';
import { anonymous } from '../ObjectUtil';
import { checkIDCardByReg } from '../StringUtils';

@Component({
  selector: 'ds-utility-demo',
  templateUrl: './utility-demo.component.html',
  styleUrls: ['./utility-demo.component.css']
})
export class UtilityDemoComponent implements OnInit {
  public time: any;
  public minTime: any;
  public maxTime: any;
  public mintime: any;
  public maxtime: any;
  public fileName: any;
  public checkName: any;
  public randomNum: any;
  public minNum: any;
  public maxNum: any;
  public compareText: any;
  public firstNum: any;
  public nextNum: any;
  public params: object;
  public paramsStr: string;
  public anonyText: string;
  public ID: string;
  public isSafe: string;
  constructor() { }

  ngOnInit() {
    document.getElementById('utilty').style.display = 'none';
    this.params = {
      BJR: '河北石家庄',
      BJRXB: '测试',
      LXDH: '123',
      ZJHM: '456',
      LXDZ: '789'
    };
    this.paramsStr =  JSON.stringify(this.params);
  }
  // 返回
  public goBack() {
    document.getElementById('flag').style.display = 'block';
    document.getElementById('utilty').style.display = 'none';
  }

  // 获得最小时间
  public getMinTime() {
    this.minTime = getMinTime(this.mintime);
  }

  // 获得最大时间
  public getMaxTime() {
    this.maxTime = getMaxTime(this.maxtime);
  }
  // 检验文件后缀
  public checkFileName() {
    this.checkName = checkFileTypebylastIndexOf(this.fileName);
  }
  // 获得制定范围得随机数
  public getRandom() {
    this.randomNum = GetRandomNum(this.minNum, this.maxNum);
  }
  // 比较大小
  public compare() {
    this.compareText = compareStatusValue(this.firstNum, this.nextNum);
  }
  // 匿名处理
  public anony() {
    this.anonyText = JSON.stringify(anonymous(this.params));
  }
  // 身份证验证
  public chekID() {
    this.isSafe = checkIDCardByReg(this.ID);
  }

}
