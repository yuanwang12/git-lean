// 字符补足
export function padString(str: string, num: number, char: string) {}

// 通过正则表达式检验身份证
export function checkIDCardByReg(IDCard: any): any {
  let result: any = null;
  // 15位身份证
  const IDCardRegExpX15: RegExp = /^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$/;
  // 18位身份证
  const IDCardRegExp18: RegExp = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
  if (IDCardRegExpX15.test(IDCard) || IDCardRegExp18.test(IDCard)) {
    result = 'ok';
  } else {
    result = 'error';
  }
  return result;
}

/**
 * 生成GUID
 */
export function newGuid() {
  let guid = '';
  for (let i = 1; i <= 32; i++) {
    const n = Math.floor(Math.random() * 16.0).toString(16);
    guid += n;
  }
  return guid;
}

/**
 * 公共方法-拼音排序
 * array:排序数组 erg: array = ['武汉', '北京', '上海', '天津']
 */
export function pySorting(array): any {
  array.sort(function compareFunction(param1, param2) {
    return param1.localeCompare(param2, 'zh');
  });
}
