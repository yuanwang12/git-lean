import { Observable } from 'rxjs';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export abstract class ConfigService {
  constructor() {}

  /**
   * 初始化配置
   */
  abstract initData(): Observable<string>;

  /**
   * 获取字符串value
   */
  abstract getConfigString(key: string, defaultStr: string): string;

  /**
   * 获取数字类型value
   */
  abstract getConfigNumber(key: string, defaultNum: number): number;

  /**
   * 获取布尔value
   */
  abstract getConfigBoolean(key: string, defaultValue: boolean): boolean;

  abstract getConfigObj(key: string, defaultObject: any): any;
}
