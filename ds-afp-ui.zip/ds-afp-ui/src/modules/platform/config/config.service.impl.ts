import { from, Observable, of, Subject } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { DataStoreResponse } from '../common/protocol/data-store-response';
import { ConfigService } from './config.service';
import { DsConfig } from './ds-config';

@Injectable()
export class ConfigServiceImpl implements ConfigService {
  private configDataSource: any;
  // 2、定义一个配置类，key:value

  private getInitUrl = 'src/modules/platform/config/ds-config.json';

  constructor(private httpClient: HttpClient) {
    this.initData();
  }

  /**
   * 初始化配置
   */
  public initData(): Observable<string> {
    // const subject = new Subject<string>();
    const dsConfig = new DsConfig();
    this.configDataSource = dsConfig.getContent();
    // subject.next('ok');
    // return subject;
    return of('ok');
  }

  /**
   * 获取字符串value
   */
  public getConfigString(key: string, defaultStr: string): string {
    if (this.configDataSource && this.configDataSource[key]) {
      return this.configDataSource[key];
    }
    return defaultStr;
  }

  /**
   * 获取数字类型value
   */
  public getConfigNumber(key: string, defaultNum: number): number {
    if (this.configDataSource && this.configDataSource[key]) {
      return Number(this.configDataSource[key]);
    }
    return defaultNum;
  }

  /**
   * 获取布尔value
   */
  public getConfigBoolean(key: string, defaultValue: boolean): boolean {
    if (this.configDataSource && this.configDataSource[key]) {
      return Boolean(this.configDataSource[key]);
    }
    return defaultValue;
  }

  /**
   * 获取Object
   */
  public getConfigObj(key: string, defaultObject: any): any {
    return defaultObject;
  }
}
