import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { ConfigService } from './config.service';

@Injectable()
export class ConfigServiceMock implements ConfigService {
  private configDataSource: any;

  constructor(private httpClient: HttpClient) {
    this.configDataSource = {
      'map.common.layers.type': 'Tile',
      'map.common.map.view.minZoom': '2',
      'map.common.map.view.maxZoom': '23',
      'map.sprinkle.styleTypes.2.text.fill.color': '#aa3300'
    };
  }

  /**
   * 初始化配置
   */
  public initData(): Observable<string> {
    return null;
  }

  /**
   * 获取字符串value
   */
  public getConfigString(key: string, defaultStr: string): string {
    console.log('进入服务');
    if (this.configDataSource && this.configDataSource[key]) {
      return this.configDataSource[key];
    }
    return defaultStr;
  }

  /**
   * 获取数字类型value
   */
  public getConfigNumber(key: string, defaultNum: number): number {
    console.log('进入服务');
    if (this.configDataSource && this.configDataSource[key]) {
      return Number(this.configDataSource[key]);
    }
    return defaultNum;
  }

  /**
   * 获取布尔value
   */
  public getConfigBoolean(key: string, defaultValue: boolean): boolean {
    console.log('进入服务');
    if (this.configDataSource && this.configDataSource[key]) {
      return Boolean(this.configDataSource[key]);
    }
    return defaultValue;
  }

  /**
   * 获取Object
   */
  public getConfigObj(key: string, defaultObject: any): any {
    console.log('进入服务');
    return defaultObject;
  }
}
