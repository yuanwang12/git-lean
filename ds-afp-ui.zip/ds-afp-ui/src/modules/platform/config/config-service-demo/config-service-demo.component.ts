import { Component, OnInit } from '@angular/core';

import { ConfigService } from '../config.service';

@Component({
  selector: 'ds-config-service-demo',
  templateUrl: './config-service-demo.component.html',
  styleUrls: ['./config-service-demo.component.css']
})
export class ConfigServiceDemoComponent implements OnInit {
  private configKey = '';
  private configValue: any;
  public allowCustom = true;
  public listItems: Array<string> = [
    'Baseball',
    'Basketball',
    'Cricket',
    'Field Hockey',
    'Football',
    'Table Tennis',
    'Tennis',
    'Volleyball'
  ];

  constructor(private configService: ConfigService) {}

  ngOnInit() {}

  public getConfigValue(flag: string): void {
    if ('bool' === flag) {
      this.configValue = this.configService.getConfigBoolean(
        this.configKey,
        false
      );
    } else if ('num' === flag) {
      this.configValue = this.configService.getConfigNumber(this.configKey, -1);
    } else {
      this.configValue = this.configService.getConfigString(
        this.configKey,
        '无字符串配置'
      );
    }
  }
}
