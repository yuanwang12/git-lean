export class DsConfig {
  constructor() {
    this.ret = 'ok';
    this.msg = '';
    this.content = {
      'map.common.layers.type': 'Tile',
      'map.common.layers.tile.source.type': 'OSM',
      'map.common.centerAddr.x': '121.53',
      'map.common.centerAddr.y': '31.22',
      'map.common.map.view.zoom': '5',
      'map.common.map.view.minZoom': '2',
      'map.common.map.view.maxZoom': '23',

      'map.sprinkle.styleTypes.defaultStyle.icon.anchor.x': '0.5',
      'map.sprinkle.styleTypes.defaultStyle.icon.anchor.y': '0',
      'map.sprinkle.styleTypes.defaultStyle.icon.anchorOrigin': 'top-right',
      'map.sprinkle.styleTypes.defaultStyle.icon.anchorXUnits': 'fraction',
      'map.sprinkle.styleTypes.defaultStyle.icon.anchorYUnits': 'pixels',
      'map.sprinkle.styleTypes.defaultStyle.icon.offsetOrigin': 'top-right',
      'map.sprinkle.styleTypes.defaultStyle.icon.opacity': '0.75',
      'map.sprinkle.styleTypes.defaultStyle.icon.scale': '1',
      'map.sprinkle.styleTypes.defaultStyle.icon.src': './image/spot.png',
      'map.sprinkle.styleTypes.defaultStyle.text.textAlign': 'center',
      'map.sprinkle.styleTypes.defaultStyle.text.textBaseline': 'middle',
      'map.sprinkle.styleTypes.defaultStyle.text.font': 'normal 14px 微软雅黑',
      'map.sprinkle.styleTypes.defaultStyle.text.fill.color': '#aa3300',

      'map.area.iconStyle.image.anchor.x': '15',
      'map.area.iconStyle.image.anchor.y': '30',
      'map.area.iconStyle.image.anchorXUnits': 'pixels',
      'map.area.iconStyle.image.anchorYUnits': 'pixels',
      'map.area.iconStyle.image.src':
        '../../../../onduty-web/resources/comp/ds-area-map/images/110green.png',
      'map.area.createStyle.iconStylePolygon.fill.color':
        'rgba(255, 255, 0, 0.2)',
      'map.area.createStyle.iconStylePolygon.stroke.color': '#ff0000',
      'map.area.createStyle.iconStylePolygon.stroke.width': '2',
      'map.area.createStyle.iconStylePolygon.image.radius': '7',
      'map.area.createStyle.iconStylePolygon.image.fill.color': '#ffcc33',
      'map.area.createStyle.iconStylePolygon.text.font':
        '12px Calibri,sans-serif',
      'map.area.createStyle.iconStylePolygon.text.stroke.color': '#fff',
      'map.area.createStyle.iconStylePolygon.text.stroke.width': '3',
      'map.area.createStyle.iconStylePolygon.text.offsetY': '15',

      'map.sprinkle.styleTypes.num': '3',
      'map.sprinkle.styleTypes.0.name': 'styleOne',
      'map.sprinkle.styleTypes.0.icon.anchor.x': '0.5',
      'map.sprinkle.styleTypes.0.icon.anchor.y': '0',
      'map.sprinkle.styleTypes.0.icon.anchorOrigin': 'top-right',
      'map.sprinkle.styleTypes.0.icon.anchorXUnits': 'fraction',
      'map.sprinkle.styleTypes.0.icon.anchorYUnits': 'pixels',
      'map.sprinkle.styleTypes.0.icon.offsetOrigin': 'top-right',
      'map.sprinkle.styleTypes.0.icon.opacity': '0.75',
      'map.sprinkle.styleTypes.0.icon.scale': '1',
      'map.sprinkle.styleTypes.0.icon.src': './image/spot.png',
      'map.sprinkle.styleTypes.0.text.textAlign': 'center',
      'map.sprinkle.styleTypes.0.text.textBaseline': 'middle',
      'map.sprinkle.styleTypes.0.text.font': 'normal 14px 微软雅黑',
      'map.sprinkle.styleTypes.0.text.fill.color': '#aa3300',

      'map.sprinkle.styleTypes.1.icon.anchor.x': '1.5',
      'map.sprinkle.styleTypes.1.name': 'styleTwo',
      'map.sprinkle.styleTypes.1.icon.anchor.y': '1',
      'map.sprinkle.styleTypes.1.icon.anchorOrigin': 'top-right',
      'map.sprinkle.styleTypes.1.icon.anchorXUnits': 'fraction',
      'map.sprinkle.styleTypes.1.icon.anchorYUnits': 'pixels',
      'map.sprinkle.styleTypes.1.icon.offsetOrigin': 'top-right',
      'map.sprinkle.styleTypes.1.icon.opacity': '1.75',
      'map.sprinkle.styleTypes.1.icon.scale': '1',
      'map.sprinkle.styleTypes.1.icon.src': './image/spot.png',
      'map.sprinkle.styleTypes.1.text.textAlign': 'center',
      'map.sprinkle.styleTypes.1.text.textBaseline': 'middle',
      'map.sprinkle.styleTypes.1.text.font': 'normal 14px 微软雅黑',
      'map.sprinkle.styleTypes.1.text.fill.color': '#aa3300',
      'map.sprinkle.styleTypes.2.icon.anchor.x': '1.5',
      'map.sprinkle.styleTypes.2.name': 'styleThree',
      'map.sprinkle.styleTypes.2.icon.anchor.y': '1',
      'map.sprinkle.styleTypes.2.icon.anchorOrigin': 'top-right',
      'map.sprinkle.styleTypes.2.icon.anchorXUnits': 'fraction',
      'map.sprinkle.styleTypes.2.icon.anchorYUnits': 'pixels',
      'map.sprinkle.styleTypes.2.icon.offsetOrigin': 'top-right',
      'map.sprinkle.styleTypes.2.icon.opacity': '1.75',
      'map.sprinkle.styleTypes.2.icon.scale': '1',
      'map.sprinkle.styleTypes.2.icon.src': './image/spot.png',
      'map.sprinkle.styleTypes.2.text.textAlign': 'center',
      'map.sprinkle.styleTypes.2.text.textBaseline': 'middle',
      'map.sprinkle.styleTypes.2.text.font': 'normal 14px 微软雅黑',
      'map.sprinkle.styleTypes.2.text.fill.color': '#aa3300'
    };
  }
  private ret: string;
  private msg: string;
  private content: any;

  public getContent(): any {
    return this.content;
  }
}
