export const registerClass = {
  account: '',
  password: '',
  phone: '',
  birthday: '',
  sex: '',
  referrer: ''
}

export const rules = [{
  name: 'account',
  required: true,
  emptyTip: '请输入用户名',
  pattern: /^[a-z\d_]{3,12}$/,
  tip: '用户名由3-12位字母数字和下划线组成'
}, {
  name: 'password',
  required: true,
  emptyTip: '请输入密码'
}, {
  name: 'phone',
  required: true,
  emptyTip: '请填写联系方式',
  pattern: /^1(3|4|5|6|7|8|9)\d\s\d{4}\s\d{4}$/,
  tip: '手机号码格式错误'
}, {
  name: 'birthday',
  required: true,
  emptyTip: '请填写出生年月'
}]
