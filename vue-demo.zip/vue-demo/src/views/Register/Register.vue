<template>
  <div class="page page-register">
    <group title="用户信息">
      <x-input title="用户名:" 
        text-align="right" 
        v-model="params.account"
      ></x-input>
      <x-input title="密码:"
        text-align="right"
        type="password"
        v-model="params.password"
      ></x-input>
      <x-input title="手机号码:" 
        text-align="right"
        mask="999 9999 9999" 
        type="tel"
        :max="13"
        v-model="params.phone"
      ></x-input>
      <datetime 
        title="出生日期:" 
        text-align="right"
        :minYear="1990"
        :maxYear="2010"
        v-model="params.birthday"
      ></datetime>
      <popup-radio title="性别:" :options="sexDS" v-model="params.sex"></popup-radio>
      <cell title="推荐人:" is-link @click.native="showSearch" :value="params.referrer"></cell>
    </group>
    <box gap="10px 10px">
      <x-button type="primary" @click.native="submit">提交</x-button>
    </box>
    <div v-transfer-dom>
      <popup v-model="isShowSearch" height="100%">
        <search
          v-show="isShowSearch"
          @on-change="getResult"
          @result-click="resultClick"
          @on-cancel="onCancel"
          :results="referrerList"
          ref="search"
        ></search>
      </popup>
    </div>
  </div>
</template>

<script>
import { TransferDom, Group, Cell, XInput, Datetime, Box, XButton, PopupRadio, Search, Popup } from 'vux'
import { registerClass, rules } from './Register.js'

export default {
  name: 'PageRegister',
  directives: {
    TransferDom
  },
  components: {
    Group,
    Cell,
    XInput,
    Datetime,
    Box,
    XButton,
    PopupRadio,
    Search,
    Popup
  },
  data () {
    return {
      params: Object.assign({}, registerClass),
      sexDS: [{ key: 0, value: '女' }, { key: 1, value: '男' }],
      referrerList: [],
      isShowSearch: false
    }
  },
  methods: {
    submit () {
      let params = JSON.parse(JSON.stringify(this.params))
      if (this.$validate(params, rules)) {
        alert(JSON.stringify(params))
      }
    },
    getResult (val) {
      let list = []
      for (let i = 0; i < 20; i++) {
        list.push({
          title: `${val} result：${i + 1}`,
          key: i
        })
      }
      this.referrerList = list
    },
    resultClick (item) {
      this.params.referrer = item.title
      this.$refs.search.clear()
      this.isShowSearch = false
    },
    showSearch () {
      this.isShowSearch = true
      this.$nextTick(() => {
        this.$refs.search.setFocus()
      })
    },
    onCancel () {
      this.$refs.search.setBlur()
      this.isShowSearch = false
    }
  }
}
</script>

<style lang="less">
@import url("./Register.less");
</style>
