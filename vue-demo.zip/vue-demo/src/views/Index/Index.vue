<template>
  <div class="page page-home">
    <div class="banner">
      <img src="../../assets/logo.png" alt="logo">
    </div>
    <group>
      <cell title="新建" link="/order"></cell>
      <cell title="详情" link="/order/IFLYTEK20180509000001"></cell>
      <cell title="注册" link="/register"></cell>
      <cell title="无限滚动" link="/scroller"></cell>
    </group>
  </div>
</template>

<script>
import { Group, Cell } from 'vux'
export default {
  name: 'Index',
  components: {
    Group,
    Cell
  }
}
</script>

<style lang="less">
@import url("./Index.less");
</style>
