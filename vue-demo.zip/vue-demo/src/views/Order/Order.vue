<template>
  <div class="page page-order">
    <!-- 模块 -->
    <group title="客户信息">
      <x-input title="客户名称:" v-model="params.name"></x-input>
      <x-input title="客户单位:" v-model="params.unit"></x-input>
      <x-input title="手机号码:" v-model="params.phone" :max="11"></x-input>
      <x-input title="地址:" v-model="params.address"></x-input>
    </group>

    <group title="问题描述">
      <x-textarea 
        :max="200" 
        v-model="params.content" 
        :show-counter="false"
        autosize
      ></x-textarea>
    </group>
    <group class="btn-wrap">
      <x-button type="primary" @click.native="submit">提交</x-button>
    </group>
  </div>
</template>

<script>
import { XTextarea, XInput, Group, XButton } from 'vux'
import { orderClass, rules } from './Order.js'

export default {
  name: 'PageOrder',
  components: {
    Group,
    XTextarea,
    XInput,
    XButton
  },
  data () {
    return {
      params: Object.assign({}, orderClass)
    }
  },
  beforeMount () {
    let id = this.$route.params.id
    if (id) {
      this.getInfo()
    }
  },
  methods: {
    // 提交
    submit () {
      let params = JSON.parse(JSON.stringify(this.params))
      if (this.ABILITY.validate.exec(params, rules)) {
        console.log(params)
      }
    },
    // 获取信息
    getInfo () {
      this.ABILITY.request.mock('/app/orderInfo').then(res => {
        this.params = res
      })
    }
  }
}
</script>

<style lang="less">
@import url("./Order.less");
</style>




