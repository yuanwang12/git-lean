export const orderClass = {
  name: '',
  unit: '',
  phone: '',
  address: ''
}

export const rules = [{
  name: 'name',
  required: true,
  emptyTip: '客户名称不能为空'
}, {
  name: 'unit',
  required: true,
  emptyTip: '客户单位不能为空'
}]
