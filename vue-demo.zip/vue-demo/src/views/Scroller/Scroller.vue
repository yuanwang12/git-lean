<template>
  <div class="page page-scroller">
     <scroller
      class="scroller"
      style="padding-top: 46px"
      :on-refresh="refresh"
      :on-infinite="infinite"
    >
      <div v-for="(item, index) in items" class="row" :class="{'grey-bg': index % 2 == 0}" :key="index">
        {{ item }}
      </div>
    </scroller>
  </div>
</template>

<script>
import Vue from 'vue'
import VueScroller from 'vue-scroller'
Vue.use(VueScroller)
export default {
  name: 'PageScroller',
  data () {
    return {
      items: []
    }
  },
  mounted () {
    for (let i = 1; i <= 20; i++) {
      this.items.push(i + ' - keep walking, be 2 with you.')
    }
    this.top = 1
    this.bottom = 20
  },
  methods: {
    refresh (done) {
      debugger
      setTimeout(() => {
        let start = this.top - 1
        for (let i = start; i > start - 10; i--) {
          this.items.splice(0, 0, i + ' - keep walking, be 2 with you.')
        }
        this.top = this.top - 10
        done()
      }, 1500)
    },
    // 初始化
    infinite (done) {
      console.log('infinite called..')

      setTimeout(() => {
        let start = this.bottom + 1
        for (let i = start; i < start + 10; i++) {
          this.items.push(i + ' - keep walking, be 2 with you.')
        }
        this.bottom = this.bottom + 10
        if (this.bottom >= 40) {
          done(true)
        } else {
          done()
        }
      }, 1500)
    }
  }
}
</script>

<style lang="less">
@import url("./Scroller.less");
</style>
