import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/views/Index/Index'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    name: 'Index',
    component: Index,
    meta: { title: 'Vux' }
  }, {
    path: '/order',
    name: 'Order',
    component: () => import('@/views/Order/Order.vue'),
    meta: { title: '新建' }
  }, {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/Register/Register.vue'),
    meta: { title: '注册' }
  }, {
    path: '/order/:id',
    name: 'OrderDetail',
    component: () => import('@/views/Order/Order.vue'),
    meta: { title: '详情' }
  }, {
    path: '/scroller',
    name: 'Scroller',
    component: () => import('@/views/Scroller/Scroller.vue'),
    meta: { title: '滚动加载' }
  }]
})
