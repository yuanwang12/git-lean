<template>
  <div id="app">
    <view-box ref="viewBox" body-padding-top="46px" body-padding-bottom="0">
      <x-header 
        :title="title"
        :left-options="{backText: ''}">
        <x-icon v-if="path =='/'" slot="overwrite-left" type="android-home" size="28" style="fill:#fff;position:relative;top:-5px;left:-6px;"></x-icon>
      </x-header>
      <transition>
        <router-view class="router-view"></router-view>
      </transition>
    </view-box>
  </div>
</template>

<script>
import { ViewBox, XHeader } from 'vux'
export default {
  name: 'app',
  components: {
    ViewBox,
    XHeader
  },
  computed: {
    title () {
      let title = this.$route.meta.title
      if (this.$route.name === 'OrderDetail') {
        title = '工单编号：' + this.$route.params.id
      }
      return title
    },
    path () {
      return this.$route.path
    }
  }
}
</script>

<style lang="less">
@import "~vux/src/styles/reset.less";
@import url("./common/style/common.less");
</style>
