import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    userInfo: {} // 用户信息
  },
  getters: {
    getUserInfo: state => state.userInfo
  },
  mutations: {
    // 设置用户信息
    SET_USER: (state, userInfo) => {
      state.userInfo = userInfo
    }
  },
  actions: {
    // 设置用户信息
    setUser ({ commit }, userInfo) {
      commit('SET_USER', userInfo)
    }
  }
})
