import Vue from 'vue'
import { AjaxPlugin, LoadingPlugin, ToastPlugin } from 'vux'
import qs from 'qs'

Vue.use(LoadingPlugin)
Vue.use(ToastPlugin)

const axios = AjaxPlugin.$http
const $vux = Vue.$vux

var Request = {
  // 通过POST请求获取数据
  post: function (url, params, notShowLoading) {
    if (!notShowLoading) {
      $vux.loading.show({
        text: 'Loading'
      })
    }
    return new Promise((resolve, reject) => {
      if (!params) {
        params = {}
      }
      axios.post(url, qs.stringify(params)).then(response => {
        if (!notShowLoading) {
          $vux.loading.hide()
        }
        const res = response.data
        if (res.flag) {
          resolve(res)
        } else {
          $vux.toast.show({
            type: 'warn',
            text: res.msg
          })
          reject(res)
        }
      })
      .catch((error) => {
        const code = error.response.status
        let msg = ''
        if (code === 504) {
          msg = '请求超时'
        } else if (code === 404) {
          msg = '地址错误'
        } else if (code === 200) {
          msg = error.msg
        } else {
          msg = code
        }
        $vux.loading.hide()
        $vux.toast.show({
          type: 'warn',
          text: msg
        })
        reject(error)
      })
    })
  },

  // 获取MOCK数据
  mock: function (url, params, notShowLoading) {



    return new Promise((resolve, reject) => {
      var response = require('../../mock/' + url.substring(1).split('/').join('_') + '.json')
      if (response && response.flag) {
        resolve(response.data)
      } else {
        $vux.toast.show({
          type: 'warn',
          text: '请求MOCK数据发生异常,请确认路径'
        })
        reject(response)
      }
    }).catch(v => console.log(v.message))
  }
}

export default Request
