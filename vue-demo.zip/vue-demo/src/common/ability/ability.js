import Request from './request.js'
import Validate from './validate.js'

const Ability = {
  // 数据请求
  request: Request,
  // 表单数据校验
  validate: Validate
}

export default Ability
