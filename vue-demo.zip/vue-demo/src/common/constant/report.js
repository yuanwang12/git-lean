export default {
    type: [{
      name: '全部',
      type: 'type',
      value: 'all',
      checked: 'false'
    }],
    state: [{
      name: '全部',
      type: 'status',
      value: '',
      checked: 'true'
    },
    {
      name: '未处理',
      type: 'status',
      value: '1',
      checked: 'false'
    }, {
      name: '已受理',
      type: 'status',
      value: '2',
      checked: 'false'
    }, {
      name: '处理中',
      type: 'status',
      value: '3',
      checked: 'false'
    }, {
      name: '已完成',
      type: 'status',
      value: '4',
      checked: 'false'
    }],
    posttime: [{
      name: '全部',
      type: 'time',
      value: '',
      checked: 'false'
    }, {
      name: '一天内',
      type: 'time',
      value: 'day',
      checked: 'false'
    }, {
      name: '一周内',
      type: 'time',
      value: 'week',
      checked: 'false'
    }, {
      name: '一月内',
      type: 'time',
      value: 'month',
      checked: 'false'
    }],
    defaulttime: [{
      name: '按时间',
      type: 'sort',
      value: 'create_time',
      checked: 'false'
    }]
  }
  