export const list3 = () => {
  return {
    flag: true,
    msg: '保存成功',
    content: {
      guid: 'list3'
    }
  }
}
