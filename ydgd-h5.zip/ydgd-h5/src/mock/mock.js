import Mock from 'mockjs'
import qs from 'qs'

import {
    list3
} from './index'

// 下送
const delegate = () => {
    return {
        flag: true,
        msg: '下送成功',
        content: {
            guid: '201807020905'
        }
    }
}

// 问题分类
const data = () => {
    return {
        flag: true,
        msg: '数据获取成功',
        content: {
            list: [{
                'value': '1',
                'text': 'K开放平台'
            }, {
                'value': '2',
                'text': 'X讯飞商城'
            }, {
                'value': '3',
                'text': 'Z智慧商城'
            }]
        }
    }
}

// 客户查询
const queryList = () => {
    return {
        flag: true,
        msg: '数据获取成功',
        content: {
            pageNum: 1,
            pages: 1,
            list: [{
                id: 1,
                unit: '合肥科大讯飞',
                customerName: '张三',
                mobile: '15755329580',
                address: '合肥市蜀山区望江路88'
            }, {
                id: 2,
                unit: '芜湖科大讯飞',
                customerName: '李四',
                mobile: '1575556585',
                address: '芜湖市弋江区文津西路8号'
            }, {
                id: 3,
                unit: '上海市大顺科技有限公司',
                customerName: '王五',
                mobile: '15745678912',
                address: '徐汇区祁连山路69号'
            }, {
                id: 4,
                unit: '富士康',
                customerName: '赵六',
                mobile: '15778745445',
                address: '广东深圳'
            }, {
                id: 5,
                unit: '山东省哈尔滨市',
                customerName: '卢布',
                mobile: '1575558555',
                address: '哈尔滨第二工业大学新校区'
            }, {
                id: 6,
                unit: '山东省哈尔滨市',
                customerName: '张三',
                mobile: '1575558555',
                address: '滁州第二工业大学新校区'
            }, {
                id: 7,
                unit: '山东省哈尔滨市',
                customerName: '汪渊',
                mobile: '1575558555',
                address: '马鞍山第二工业大学新校区'
            }, {
                id: 8,
                unit: '山东省哈尔滨市',
                customerName: '王汝阳',
                mobile: '1575558555',
                address: '芜湖第二工业大学新校区'
            }, {
                id: 9,
                unit: '山东省哈尔滨市',
                customerName: '李军',
                mobile: '1575558555',
                address: '安徽省第二工业大学新校区'
            }, {
                id: 10,
                unit: '山东省哈尔滨市',
                customerName: '刘国杰',
                mobile: '1575558555',
                address: '哈尔滨第二工业大学新校区'
            }, {
                id: 11,
                unit: '山东省哈尔滨市',
                customerName: '高山',
                mobile: '1575558555',
                address: '哈尔滨第二工业大学新校区'
            }]
        }
    }
}

// 客户新增
const addCustom = () => {
    return {
        flag: true,
        msg: '新增成功',
        content: {
            guid: '124891749814798194'
        }
    }
}

// 客户类型
const customertypeId = () => {
    return {
        flag: true,
        msg: '数据获取成功',
        data: {
            list: [{
                'value': '1',
                'text': 'G个人'
            }, {
                'value': '2',
                'text': 'G公司内部'
            }, {
                'value': '3',
                'text': 'N内部用户'
            }, {
                'value': '4',
                'text': 'Q企业'
            }, {
                'value': '5',
                'text': 'Q其他'
            }, {
                'value': '6',
                'text': 'J经销营'
            }, {
                'value': '7',
                'text': 'Y运营商'
            }]
        }
    }
}

// 我的订单
const orderDetail = (req, res) => {
    let params = qs.parse(req.body)
    if (params.statusId === '0') {
        return {
            flag: true,
            msg: '我的订单列表数据加载成功',
            content: {
                pageNum: 1,
                pages: 1,
                total: 5,
                list: [{
                    'id': '1',
                    'code': 'IFLYTEK001',
                    'customerName': '客户001状态0',
                    'unit': '合肥百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': 't投诉-j教育-c畅言网',
                    'item2': '客户001',
                    'item3': '2018-07-12',
                    'orderTitle': 't投诉-j教育-c畅言网',
                    'workorderType1': '1',
                    'workorderType2': '1',
                    'workorderType3': '1',
                    'workorderType4': '1',
                    'productName': '产品名称',
                    'orderClassify': '1',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '2',
                    'code': 'IFLYTEK002',
                    'customerName': '客户002',
                    'unit': '芜湖百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '车载管理系统',
                    'item2': '客户002',
                    'item3': '2018-07-12',
                    'orderTitle': '车载管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '2',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '3',
                    'code': 'IFLYTEK003',
                    'customerName': '客户003',
                    'unit': '科大讯飞',
                    'mobile': '15755332575',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '滨江区',
                    'title': '讯飞工单',
                    'item1': '院系网站',
                    'item2': '客户003',
                    'item3': '2018-07-12',
                    'orderTitle': '院系网站',
                    'workorderType1': '3',
                    'workorderType2': '3',
                    'workorderType3': '3',
                    'workorderType4': '3',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '4',
                    'code': 'IFLYTEK004',
                    'customerName': '客户004',
                    'unit': '中科大',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '国际刑警系统',
                    'item2': '客户004',
                    'item3': '2018-07-12',
                    'orderTitle': '国际刑警系统',
                    'workorderType1': '4',
                    'workorderType2': '4',
                    'workorderType3': '4',
                    'workorderType4': '4',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '5',
                    'code': 'IFLYTEK005',
                    'customerName': '客户005',
                    'unit': '安徽信息工程学院',
                    'mobile': '15755329580',
                    'address': '芜湖市弋江区',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '实习管理系统',
                    'item2': '客户005',
                    'item3': '2018-07-12',
                    'orderTitle': '实习管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }]
            }
        }
    } else if (params.statusId === '1') {
        return {
            flag: true,
            msg: '我的订单列表数据加载成功',
            content: {
                pageNum: 1,
                pages: 1,
                total: 6,
                list: [{
                    'id': '1',
                    'code': 'IFLYTEK001',
                    'customerName': '客户001状态1',
                    'unit': '合肥百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': 't投诉-j教育-c畅言网',
                    'item2': '客户001',
                    'item3': '2018-07-12',
                    'orderTitle': 't投诉-j教育-c畅言网',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '1',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '2',
                    'code': 'IFLYTEK002',
                    'customerName': '客户002',
                    'unit': '芜湖百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '车载管理系统',
                    'item2': '客户002',
                    'item3': '2018-07-12',
                    'orderTitle': '车载管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '2',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '3',
                    'code': 'IFLYTEK003',
                    'customerName': '客户003',
                    'unit': '科大讯飞',
                    'mobile': '15755332575',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '滨江区',
                    'title': '讯飞工单',
                    'item1': '院系网站',
                    'item2': '客户003',
                    'item3': '2018-07-12',
                    'orderTitle': '院系网站',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '3',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '4',
                    'code': 'IFLYTEK004',
                    'customerName': '客户004',
                    'unit': '中科大',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '国际刑警系统',
                    'item2': '客户004',
                    'item3': '2018-07-12',
                    'orderTitle': '国际刑警系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '4',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '5',
                    'code': 'IFLYTEK005',
                    'customerName': '客户005',
                    'unit': '安徽信息工程学院',
                    'mobile': '15755329580',
                    'address': '芜湖市弋江区',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '实习管理系统',
                    'item2': '客户005',
                    'item3': '2018-07-12',
                    'orderTitle': '实习管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '5',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }]
            }
        }
    } else if (params.statusId === '2') {
        return {
            pageNum: 1,
            pages: 1,
            flag: true,
            msg: '我的订单列表数据加载成功',
            content: {
                total: 7,
                list: [{
                    'id': '1',
                    'code': 'IFLYTEK001',
                    'customerName': '客户001状态2',
                    'unit': '合肥百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': 't投诉-j教育-c畅言网',
                    'item2': '客户001',
                    'item3': '2018-07-12',
                    'orderTitle': 't投诉-j教育-c畅言网',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '1',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '2',
                    'code': 'IFLYTEK002',
                    'customerName': '客户002',
                    'unit': '芜湖百得',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '车载管理系统',
                    'item2': '客户002',
                    'item3': '2018-07-12',
                    'orderTitle': '车载管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '2',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '3',
                    'code': 'IFLYTEK003',
                    'customerName': '客户003',
                    'unit': '科大讯飞',
                    'mobile': '15755332575',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '合肥市',
                    'c_area': '滨江区',
                    'title': '讯飞工单',
                    'item1': '院系网站',
                    'item2': '客户003',
                    'item3': '2018-07-12',
                    'orderTitle': '院系网站',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '3',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '4',
                    'code': 'IFLYTEK004',
                    'customerName': '客户004',
                    'unit': '中科大',
                    'mobile': '15755329580',
                    'address': '合肥市望西路888号',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '国际刑警系统',
                    'item2': '客户004',
                    'item3': '2018-07-12',
                    'orderTitle': '国际刑警系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '4',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }, {
                    'id': '5',
                    'code': 'IFLYTEK005',
                    'customerName': '客户005',
                    'unit': '安徽信息工程学院',
                    'mobile': '15755329580',
                    'address': '芜湖市弋江区',
                    'c_province': '安徽省',
                    'c_city': '芜湖市',
                    'c_area': '弋江区',
                    'title': '讯飞工单',
                    'item1': '实习管理系统',
                    'item2': '客户005',
                    'item3': '2018-07-12',
                    'orderTitle': '实习管理系统',
                    'workorderType1': '2',
                    'workorderType2': '2',
                    'workorderType3': '2',
                    'workorderType4': '2',
                    'orderClassify': '5',
                    'productName': '产品名称',
                    'takecare': '这里是注意事项 这里是注意事项 这里是注意事项'
                }]
            }
        }
    }
}

// 事件分类
const eventClassificate = () => {
    return {
        flag: true,
        msg: '数据事情分类成功',
        data: {
            list: [{
                'value': '1',
                'text': '重大事件'
            }, {
                'value': '2',
                'text': '政府'
            }, {
                'value': '3',
                'text': '紧急'
            }, {
                'value': '4',
                'text': '是否多次'
            }, {
                'value': '5',
                'text': '对外'
            }, {
                'value': '6',
                'text': '升级'
            }, {
                'value': '7',
                'text': '高额赔偿'
            }, {
                'value': '8',
                'text': '媒体'
            }]
        }
    }
}

Mock.mock('/news/index3', 'post', list3)
Mock.mock('/newOrder/delegate', 'post', delegate)
Mock.mock('/newOrder/selectList', 'post', data)
Mock.mock('/addCustom/queryList', 'post', queryList)
Mock.mock('/addCustom/addCustom', 'post', addCustom)
Mock.mock('/addCustom/customertypeId', 'post', customertypeId)
Mock.mock('/orderDetail/addList', 'post', orderDetail)
Mock.mock('/myOrder/eventClassificate', 'post', eventClassificate)