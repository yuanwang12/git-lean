// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import VueAMap from 'vue-amap'
import VueScroller from 'vue-scroller'
import App from './App'
import router from './router/index'
import {
  ConfirmPlugin,
  LoadingPlugin,
  ToastPlugin
} from 'vux'
Vue.use(VueScroller)
Vue.use(ConfirmPlugin)
Vue.use(LoadingPlugin)
Vue.use(ToastPlugin)
Vue.use(VueAMap)
// process.env.NODE_ENV === 'development' && require('./mock/mock')
require('./css/common.css')

FastClick.attach(document.body)

Vue.config.productionTip = false

// 初始化vue-amap
VueAMap.initAMapApiLoader({
  // 高德的key
  key: 'a5634fd3bd857355693410cde3618e04',
  // 插件集合
  plugin: ['AMap.Geolocation', 'AMap.Geocoder'],
  // 高德 sdk 版本，默认为 1.4.4
  v: '1.4.4'
})

/* eslint-disable no-new */
new Vue({
  router,
  render: h => h(App)
}).$mount('#app-box')
