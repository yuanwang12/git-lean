export const orderDetailClass = {
  'G00001': {
    dealType: '',
    comments: '',
    methodpath: '',
    methodrule: '',
    nextStepType: '',
    toRoleGroup: '',
    toStaffId: ''
  },
  'J00001': {
    dealType: '',
    comments: '',
    stringfield28: '',
    stringfield29: '',
    nextStepType: ''
  }
}

export const rules = {
  'G00001': [{
    name: 'dealType',
    required: true,
    emptyTip: '解决方式不能为空'
  }, {
    name: 'comments',
    required: true,
    emptyTip: '本步意见不能为空'
  }, {
    name: 'methodpath',
    required: true,
    emptyTip: '问题原因及处理结果不能为空'
  }, {
    name: 'methodrule',
    required: true,
    emptyTip: '规范，必要性不能为空'
  }, {
    name: 'nextStepType',
    required: true,
    emptyTip: '下一步操作不能为空'
  }, {
    name: 'toRoleGroup',
    required: true,
    emptyTip: '技术支持组不能为空'
  }],
  'J00001': [{
    name: 'dealType',
    required: true,
    emptyTip: '解决方式不能为空'
  }, {
    name: 'comments',
    required: true,
    emptyTip: '本步意见不能为空'
  }, {
    name: 'stringfield28',
    required: true,
    emptyTip: '问题原因不能为空'
  }, {
    name: 'stringfield29',
    required: true,
    emptyTip: '处理结果不能为空'
  }, {
    name: 'nextStepType',
    required: true,
    emptyTip: '下一步操作不能为空'
  }]
}
