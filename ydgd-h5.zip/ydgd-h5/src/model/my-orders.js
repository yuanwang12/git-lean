export const myOrdersClass = {
  objectiveGuid: '',
  staffId: '',
  toStaffId: '',
  toRoleGroup: ''
}

export const rules = [{
  name: 'objectiveGuid',
  required: true,
  emptyTip: '工单总表Guid不能为空'
}, {
  name: 'staffId',
  required: true,
  emptyTip: '当前操作人ID不能为空'
}, {
  name: 'toStaffId',
  required: true,
  emptyTip: '处理人ID不能为空'
}, {
  name: 'toRoleGroup',
  required: true,
  emptyTip: '去向组ID人不能为空'
}]
