export const orderClass = {
  customername: '',
  sq21: '',
  mobile: '',
  address: '',
  title: '',
  inboundtype: '',
  flowdetail: '',
  method: ''
}

export const rules = [{
  name: 'customername',
  required: true,
  emptyTip: '客户名称不能为空'
}, {
  name: 'title',
  required: true,
  emptyTip: '工单标题不能为空'
}, {
  name: 'inboundtype',
  required: true,
  emptyTip: '问题分类不能为空'
}, {
  name: 'flowdetail',
  required: true,
  emptyTip: '问题描述不能为空'
}, {
  name: 'method',
  required: true,
  emptyTip: '预处理信息不能为空'
}, {
  name: 'mobile',
  required: false,
  emptyTip: '手机号码不能为空',
  pattern: /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/,
  tip: '手机号码不符合规则'
}]
