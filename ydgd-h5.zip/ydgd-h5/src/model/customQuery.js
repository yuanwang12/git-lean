export const customClass = {
  statu: ''
}
