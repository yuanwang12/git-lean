export const addCustomClass = {
  customertype2Id: '',
  customername: '',
  sq21: '',
  mobile: '',
  address: ''
}

export const rules = [{
  name: 'customertype2Id',
  required: true,
  emptyTip: '客户类型不能为空'
}, {
  name: 'customername',
  required: true,
  emptyTip: '客户名称不能为空'
}, {
  name: 'sq21',
  required: false
}, {
  name: 'mobile',
  required: true,
  emptyTip: '手机号码不能为空',
  pattern: /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/,
  // pattern: /^1[0-9]\d{1}\s\d{4}\s\d{4}$/,  // 验证xxx xxxx xxxx
  tip: '手机号码不符合规则'
}, {
  name: 'address',
  required: false
}]
