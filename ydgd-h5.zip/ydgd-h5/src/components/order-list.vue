<template>
  <div>
    OrderList
    {{$route.params.status}}
  </div>
</template>

<script>
  export default {
    name: 'OrderList',
    // props: {
    //   propName: {
    //     type: Number,
    //     default: 1
    //   }
    // },
    // data() {
    //   return {
    //     key: value
    //   }
    // },
    mounted () {
      console.log(this.$route)
      setTimeout(() => {
        console.log('run')
      }, 4000)
    },
    updated () {
      console.log('updated')
    },
    destroyed () {
      console.log('des')
    }
  }
</script>

<style lang="less" scoped>

</style>
