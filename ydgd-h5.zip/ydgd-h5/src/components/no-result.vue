<template>
  <div class="no-result">
    <img class="img" src="../assets/search.png" alt="" srcset="">
    <p class="text">{{text}}</p>
  </div>
</template>

<script>
  export default {
    name: 'NoResult',
    props: {
      text: {
        type: String,
        default: '无结果'
      }
    }
  }
</script>

<style lang="less" scoped>
.no-result {
  padding-top: 126px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
  .img {
    width: 62px;
  }
  .text {
    margin-top: 10px;
    font-size: 16px;
    color: #999;
    font-family: PingFang-SC-Medium;
  }
}
</style>
