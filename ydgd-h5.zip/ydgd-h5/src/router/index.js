import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/views/index'
const NewOrder = () => import('@/views/new-order')
const CustomQuery = () => import('@/views/custom-query')
const AddCustom = () => import('@/views/add-custom')
const MyOrders = () => import('@/views/my-orders')
const OrderDetail = () => import('@/views/order-detail')
const OrderFinished = () => import('@/views/order-finished')
const NewConnectOrder = () => import('@/views/new-connectOrder')
// const OrderList = () => import('@/components/order-list')

Vue.use(Router)

export default new Router({
  routes: [{
    path: '*',
    redirect: { // 路由重定向
      name: 'Index'
    }
  }, {
    path: '/',
    name: 'Index',
    component: Index,
    meta: {
      title: '客服工单系统'
    }
  }, {
    path: '/newOrder',
    name: 'NewOrder',
    component: NewOrder,
    meta: {
      title: '新建工单'
    }
  }, {
    path: '/customQuery',
    name: 'CustomQuery',
    component: CustomQuery,
    meta: {
      title: '客户查询'
    }
  }, {
    path: '/addCustom',
    name: 'AddCustom',
    component: AddCustom,
    meta: {
      title: '新增客户'
    }
  }, {
    path: '/myOrders',
    name: 'MyOrders',
    component: MyOrders,
    meta: {
      title: '我的工单'
    }
    // children: [{
    //   path: '',
    //   // path: '/myOrders', 以 / 开头的嵌套路径会被当作根路径 同上
    //   redirect: {
    //     name: 'OrderList',
    //     params: {
    //       status: 'all'
    //     }
    //   }
    // }, {
    //   path: ':status',
    //   name: 'OrderList',
    //   component: OrderList,
    //   meta: {
    //     title: '我的工单'
    //   }
    // }]
  }, {
    path: '/order/:id',
    name: 'OrderDetail',
    component: OrderDetail,
    meta: {
      title: '讯飞工单'
    }
  }, {
    path: '/orderFinished/:id',
    name: 'OrderFinished',
    component: OrderFinished,
    meta: {
      title: '讯飞工单'
    }
  }, {
    path: '/newConnectOrder',
    name: 'NewConnectOrder',
    component: NewConnectOrder,
    meta: {
      title: '新建关联工单'
    }
  }]
})
