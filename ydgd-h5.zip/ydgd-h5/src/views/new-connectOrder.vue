<template>
 <div class="page">
   <!-- 客户模块信息 -->
    <group title="客户信息" class="test" label-width="70px">
     <x-input title="客户名称" v-model="params.customername" @click.native="customQuery" disabled></x-input>
     <x-input title="客户单位" v-model="params.sq21" disabled></x-input>
     <x-input title="手机  " mask="99999999999" v-model="params.mobile" :max="13" disabled></x-input>
     <x-input title="地址  " v-model="params.address" disabled></x-input>
    </group>

    <Group class="group-wrapper" title="基本信息" label-width="56px" label-margin-right="30px" label-align="left">
      <cell title="工单标题" :value="tabciflytek.title" value-align="left"></cell>
      <cell title="工单一级" :value="tabciflytek.sysWorkordertype1?tabciflytek.sysWorkordertype1.workordertype1desc:''" value-align="left"></cell>
      <cell title="工单二级" :value="tabciflytek.sysWorkordertype2?tabciflytek.sysWorkordertype2.workordertype2desc:''" value-align="left"></cell>
      <cell title="工单三级" :value="tabciflytek.sysWorkordertype3?tabciflytek.sysWorkordertype3.workordertype3desc:''" value-align="left"></cell>
      <cell title="工单四级" :value="tabciflytek.sysWorkordertype4?tabciflytek.sysWorkordertype4.workordertype4desc:''" value-align="left"></cell>
      <cell title="产品名称" :value="tabciflytek.stringfield18Obj?tabciflytek.stringfield18Obj.description:''" value-align="left"></cell>
      <cell class="more-rows" title="注意事项" :value="tabciflytek.attioncomments" value-align="left"></cell>
      <div class="checks vux-1px-t">
        <checker
          class="classify"
          v-model="selectedChecker"
          type="checkbox"
          default-item-class="classify-item"
          selected-item-class="classify-item-selected"
        >
          <!-- stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 -->
          <checker-item
            v-for="i of checks"
            :key="i.key"
            :value="i.key"
            :disabled="true">{{i.value}}</checker-item>
        </checker>
      </div>
    </Group>

    <!-- 模块问题描述 -->
    <group title="问题描述">
      <x-textarea :max="200" name="detail" :show-counter="false" v-model="params.flowdetail"></x-textarea>
    </group>
    <group title="预处理信息">
      <x-textarea :max="200" name="detail" :show-counter="false" v-model="params.method"></x-textarea>
    </group>

    <!-- 拍照 -->
    <!-- <div class="imgList">
      <div
        class="img-item"
        v-for="(url, index) of imgList"
        :key="url.id"
        :style="{'backgroundImage': `url(${url.url})`}">
        <div class="icon-remove" @click="removeImgItem(index)"></div>
      </div>
      <div class="img-item upload" @click="takePhoto" v-if="imgList.length<imgCount"></div>
    </div> -->

    <!-- 按钮组 -->
    <box gap="15px 15px">
      <flexbox>
        <flexbox-item>
          <x-button @click.native="submit" class="save">保存</x-button>
        </flexbox-item>
        <flexbox-item style="margin-left: 15px;">
          <x-button  class="delegate" @click.native="delegate">下送</x-button>
        </flexbox-item>
        <flexbox-item style="margin-left: 15px;">
          <x-button class="closeCase" @click.native="closeCase">结案</x-button>
        </flexbox-item>
      </flexbox>
    </box>
  </div>

</template>

<script>
import getStaffInfo from '@/utils/getStaffInfo.js'
import { majorevents } from '@/utils/dictionary.js'
import { post } from '@/utils/service.js'
import API from '@/utils/api.js'
import { XTextarea, XInput, Group, PopupRadio, Box, Cell, XButton, Flexbox, FlexboxItem, Checker, CheckerItem } from 'vux'
import { newConnectOrdersClass, rules } from '@/model/newConnectOrder.js'
import valid from '@/utils/valid.js'
const newConnectOrderVm = {
  name: 'NewOrder',
  components: {
    XTextarea,
    XInput,
    Group,
    PopupRadio,
    XButton,
    Flexbox,
    FlexboxItem,
    Checker,
    CheckerItem,
    Box,
    Cell
  },
  data () {
    return {
      staffInfo: getStaffInfo(),
      params: Object.assign({}, newConnectOrdersClass),
      orderleve: ['1', '2', '3', '4'],
      selectChecked: ['重大事件', '升级'],
      checks: majorevents,
      tabciflytek: {},
      selectedChecker: [],
      imgCount: 4,
      imgList: []
      // imgList: [
      //   {id: 1, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3044191397,2911599132&fm=27&gp=0.jpg'},
      //   {id: 2, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=302701032,2300144492&fm=27&gp=0.jpg'},
      //   {id: 3, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3498018351,3670820427&fm=27&gp=0.jpg'},
      //   {id: 4, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3536314877,3587590266&fm=27&gp=0.jpg'}
      // ]
    }
  },
  mounted () {
    // 本地存储数据
    this.loadData()
    this.openWorkerOrder()
    // 事件分类
    // this.eventClassificate()
  },
  methods: {
    loadData () {
      const storage = window.localStorage
      let newConnectOrderInfo = JSON.parse(storage.getItem('newConnectOrderInfo'))
      let customerInfo = JSON.parse(storage.getItem('customerInfo'))
      let imgList = JSON.parse(storage.getItem('imgList'))
      storage.removeItem('imgList')
      storage.removeItem('newConnectOrderInfo')
      storage.removeItem('customerInfo')
      this.params = {
        ...this.params,
        ...newConnectOrderInfo,
        ...customerInfo
      }
      if (imgList) this.imgList = imgList
    },
    // 拍照
    takePhoto () {
      console.log('进入拍照功能')
      let userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'))
      // null处理
      if (!userInfo) userInfo = {}
      let params = {
        'url': 'https://xfkfapi.iflytek.com/exchange-file-service/fileModify/uploadImage',
        'canUploadCount': this.imgCount - this.imgList.length,
        'sourceType': '',
        'createAccount': userInfo.userAccount,
        'token': userInfo.token,
        'createUser': userInfo.userName,
        'userAccount': userInfo.userAccount,
        'callBack': 'newConnectOrderVmAddAttachmentCallBack'
      }
      console.log(params)
      const isIOS = window.localStorage.getItem('isIOS')
      /* eslint-disable no-undef */
      isIOS === 'true' ? takePhoto(params) : iflyapp.takePhoto(JSON.stringify(params))
    },
    addAttachmentCallBack: (data) => {
      // window.alert(JSON.stringify(data))
      console.log(data)
      if (!data[0].result) {
        this.$vux.toast.show({
          type: 'warn',
          text: data[0].message
        })
        return
      }
      let urls = data.map(item => ({
        id: item.content.id,
        url: item.content.uploadUrl
      }))
      this.imgList = [
        ...this.imgList,
        ...urls
      ]
    },
    removeImgItem (i) {
      this.imgList = this.imgList.filter((url, index) => index !== i)
      console.log('移除')
    },
    customQuery () {
      window.localStorage.setItem('newConnectOrderInfo', JSON.stringify(this.params))
      window.localStorage.setItem('imgList', JSON.stringify(this.imgList))
      this.$router.push({ path: '/customQuery' })
    },
    openWorkerOrder () {
      post(API['workerOrderQuery/openWorkerOrder'], {
        objectiveGuid: this.$route.query.objectiveGuid,
        handlebyId: this.staffInfo.staffId
      }).then(res => {
        console.log(res)
        this.tabciflytek = res.content.tabciflytek
        this.selectedChecker = majorevents.map(item => item.key).filter(key => this.tabciflytek[key])
      }).catch(err => console.log(err))
    },
    // 注意事项
    eventClassificate () {
      post('/myOrder/eventClassificate', {})
        .then(res => {
          console.log(res)
          let arr = []
          for (let i = 0; i < res.data.list.length; i++) {
            arr.push(res.data.list[i].text)
          }
          this.list = arr
        }).catch(error => {
          console.log(error)
        })
    },
    // 保存
    submit () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定保存?',
          onConfirm: () => {
            this.insertWorkerOrder()
          }
        })
      }
    },
    insertWorkerOrder () {
      let staffInfo = getStaffInfo()
      let { customerGuid, flowdetail, method } = this.params
      let params = {
        customerGuid,
        flowdetail,
        method,
        agentId: staffInfo.agentId,
        createdby: staffInfo.staffId
      }
      this.handleWorkerOrder(params, 'workerOrderOperation/insertWorkerOrder')
    },
    // 下送
    delegate () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定下送?',
          onConfirm: () => {
            console.log(this)
            this.sendWorkerOrder()
          }
        })
      }
    },
    sendWorkerOrder () {
      let staffInfo = getStaffInfo()
      let { customerGuid, flowdetail, method } = this.params
      let params = {
        customerGuid,
        flowdetail,
        method,
        agentId: staffInfo.agentId,
        createdby: staffInfo.staffId,
        staffId: staffInfo.staffId
      }
      this.handleWorkerOrder(params, 'workerOrderOperation/sendWorkerOrder')
    },
    // 结案
    closeCase () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定结案?',
          onConfirm: () => {
            this.closeWorkerOrder()
          }
        })
      }
    },
    closeWorkerOrder () {
      let staffInfo = getStaffInfo()
      let { customerGuid, flowdetail, method } = this.params
      let params = {
        customerGuid,
        flowdetail,
        method,
        agentId: staffInfo.agentId,
        createdby: staffInfo.staffId,
        staffId: staffInfo.staffId
      }
      this.handleWorkerOrder(params, 'workerOrderOperation/closeWorkerOrder')
    },
    handleWorkerOrder (params, api) {
      if (this.imgList.length) {
        params.filePath = this.imgList.map(item => item.url).join('*')
      } else {
        params.filePath = ''
      }
      post(API[api], {
        ...params,
        isRelationWorkorder: '1',
        objectiveRelationidOld: this.tabciflytek.objectiveRelationid,
        objectiveGuidOld: this.$route.query.objectiveGuid
      }).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            this.$vux.loading.hide()
            let routeDepth = window.localStorage.getItem('routeDepth')
            this.$router.go(-Number(routeDepth))
          }
        })
      }).catch(err => console.log(err))
    }
  }
}

window.newConnectOrderVmAddAttachmentCallBack = function (data) {
  newConnectOrderVm.methods.addAttachmentCallBack(data)
}

export default newConnectOrderVm
</script>

<style scoped>
@import url("../css/newConnectOrder/newConnectOrder.css");
.test >>> .vux-cell-primary {
  flex: 0 1 auto;
}
</style>
<style lang="less" scoped>
@color: #3783f6;
.group-wrapper {
  &.no-border-gap {
    .weui-cell {
      &::before {
        right: 0;
      }
    }
  }
  .weui-cell {
    &.more-rows {
      & /deep/ .vux-cell-bd {
        align-self: flex-start;
      }
      // & /deep/ .weui-cell__ft.vux-cell-primary.vux-cell-align-left {
      //   line-height: 22px;
      // }
    }
    &.weui-cell_access.vux-tap-active {
      padding: 10px 15px;
      height: auto;
    }
    &::before {
      right: 15px;
    }
    & /deep/ .vux-cell-primary {
      overflow: hidden;
      font-size: 14px;
      color: #333;
      & > p {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    & /deep/ .vux-label {
      font-size: 14px;
      color: #666;
    }
  }
}
.checks {
  &.vux-1px-t {
    &::before {
      left: 15px;
      right: 15px;
    }
  }
  .classify {
    padding: 5px 15px;
    display: flex;
    flex-wrap: wrap;
    // justify-content: space-between;
    align-items: center;
    background-color: #fff;
  }
  .classify-item {
    margin: 10px 0 10px 0;
    // stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 ~避免calc内的值在编译时被计算
    margin-right: calc(~"(100vw - 350px) / 3");
    flex-shrink: 1;
    width: 80px;
    height: 25px;
    font-size: 14px;
    line-height: 25px;
    text-align: center;
    border-radius: 3px;
    background-color: #e5e3e3;
    &:nth-of-type(4n) {
      margin-right: 0;
    }
  }
  .classify-item-selected {
    color: @color;
    font-size: 14px;
    background: #e6f0fe url("../assets/active.png") no-repeat right
      bottom/auto 50%;
  }
}
</style>
