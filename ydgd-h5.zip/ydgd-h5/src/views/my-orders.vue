<template>
  <div class="page">
    <div class="sticky-wrapper">
      <sticky
        scroll-box="vux_view_box_body"
        ref="sticky"
        :offset="46"
        :check-sticky-support="false"
        :disabled="disabled">
        <tab :line-width="2" custom-bar-width="80px" active-color="#3783f6">
          <tab-item
            v-for="(tab, index) in tabs"
            :key="index"
            :selected="index === 0"
            @on-item-click="onItemClick">{{tabTitle(tab)}}</tab-item>
        </tab>
        <div class="filter-wrapper">
          <div class="filter-item vux-1px-r" @click="toggleSelectMenu('emergency')">
            <span class="dropdown">工单紧急程度</span>
          </div>
          <div class="filter-item" @click="toggleSelectMenu('dateTime')">
            <span class="dropdown">建单时间</span>
          </div>
        </div>
        <search
          placeholder="请输入客户名称查询"
          @result-click="resultClick"
          @on-change="getResult"
          :results="results"
          v-model="value"
          position="absolute"
          :auto-fixed="false"
          auto-scroll-to-top
          top="46px"
          @on-focus="onFocus"
          @on-cancel="onCancel"
          @on-submit="onSubmit"
          ref="search"
        />
      </sticky>
    </div>
    <div v-if="tabIndex === 0" class="scroller-wrapper">
      <scroller
        v-if="list1.length"
        :on-infinite="infinite1"
        :on-refresh="refresh1"
        ref="myscroller"
      >
        <div class="order-list">
          <div v-for="i in list1" :key="i.objectiveGuid" @click="toOrderDetail(i)">
            <div class="order-item vux-1px-tb">
              <div class="order-header vux-1px-b">
                <span class="title">{{i.wo3FrameMap.description}}</span>
                <span class="code">{{i.tabciflytek.workorderid}}</span>
              </div>
              <div class="order-body">
                <ul class="order-body-list">
                  <li class="item1">{{i.tabciflytek.title}}</li>
                  <li class="item2">{{i.tabciflytek.customername}}</li>
                  <li class="item3">{{i.createddate | dateFormat}}</li>
                </ul>
                <x-button mini plain class="btn" v-if="tabIndex !== 2 && i.isinterim !== '1'" @click.native.stop="adjust(i)">调剂</x-button>
              </div>
            </div>
          </div>
        </div>
      </scroller>
      <no-result v-else />
    </div>
    <div v-if="tabIndex === 1" class="scroller-wrapper">
      <scroller
        v-if="list2.length"
        class="scroller-wrapper vux-1px-tb"
        :on-infinite="infinite2"
        :on-refresh="refresh2"
        ref="myscroller"
      >
        <div class="order-list">
          <div v-for="i in list2" :key="i.objectiveGuid" @click="toOrderDetail(i)">
            <div class="order-item vux-1px-tb">
              <div class="order-header vux-1px-b">
                <span class="title">{{i.wo3FrameMap.description}}</span>
                <span class="code">{{i.tabciflytek.workorderid}}</span>
              </div>
              <div class="order-body">
                <ul class="order-body-list">
                  <li class="item1">{{i.tabciflytek.title}}</li>
                  <li class="item2">{{i.tabciflytek.customername}}</li>
                  <li class="item3">{{i.createddate | dateFormat}}</li>
                </ul>
                <x-button mini plain class="btn" v-if="tabIndex !== 2 && i.isinterim !== '1'" @click.native.stop="adjust(i)">调剂</x-button>
              </div>
            </div>
          </div>
        </div>
      </scroller>
      <no-result v-else />
    </div>
    <div v-if="tabIndex === 2" class="scroller-wrapper">
      <scroller
        v-if="list3.length"
        class="scroller-wrapper vux-1px-tb"
        :on-infinite="infinite3"
        :on-refresh="refresh3"
        ref="myscroller"
      >
        <div class="order-list">
          <div v-for="i in list3" :key="i.objectiveGuid" @click="toOrderDetail(i)">
            <div class="order-item vux-1px-tb">
              <div class="order-header vux-1px-b">
                <span class="title">{{i.wo3FrameMap.description}}</span>
                <span class="code">{{i.tabciflytek.workorderid}}</span>
              </div>
              <div class="order-body">
                <ul class="order-body-list">
                  <li class="item1">{{i.tabciflytek.title}}</li>
                  <li class="item2">{{i.tabciflytek.customername}}</li>
                  <li class="item3">{{i.createddate | dateFormat}}</li>
                </ul>
                <x-button mini plain class="btn" v-if="tabIndex !== 2 && i.isinterim !== '1'" @click.native.stop="adjust(i)">调剂</x-button>
              </div>
            </div>
          </div>
        </div>
      </scroller>
      <no-result v-else />
    </div>
    <div v-transfer-dom>
      <popup v-model="adjustShow">
        <!-- group already has a top border, so we need to hide header's bottom border-->
        <popup-header
          right-text="取消"
          title="调剂工单"
          :show-bottom-border="false"
          @on-click-right="adjustShow = false"></popup-header>
        <group class="group-wrapper" gutter="0">
          <cell title="处理组" :value="staffInfo.rolegroupdescription"></cell>
          <popup-radio title="处理人" :options="people" v-model="person" placeholder="请选择" @on-show="adjustShow=false" @on-hide="adjustShow=true"></popup-radio>
          <x-button class="btn" @click.native="adjustConfirm">确定</x-button>
        </group>
      </popup>
    </div>
    <transition name="fade">
      <div class="mask" v-if="emergencyShow || dateTimeShow" @click="clickMask">
        <div class="menu">
          <div class="checks vux-1px-t" v-if="emergencyShow">
            <checker
              class="classify"
              v-model="selectedChecker"
              type="checkbox"
              default-item-class="classify-item"
              selected-item-class="classify-item-selected"
            >
              <!-- stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 -->
              <checker-item
                :style="{marginRight: index % 4 === 3 ? '0' : 'calc((100vw - 350px) / 3)'}"
                v-for="(i, index) of checks"
                :key="i.key"
                :value="i.key"
                :disabled="false">{{i.value}}</checker-item>
            </checker>
          </div>
          <group v-if="dateTimeShow" :gutter="0">
            <datetime
              class="date-time"
              placeholder="请选择"
              v-model="startTime"
              :end-date="endTime"
              title="建单时间"></datetime>
            <datetime
              class="date-time"
              placeholder="请选择"
              v-model="endTime"
              :start-date="startTime"
              title="至"></datetime>
          </group>
          <flexbox class="btns" :gutter="0">
            <flexbox-item>
              <x-button class="btn btn1" @click.native.stop="cancel">取消</x-button>
            </flexbox-item>
            <flexbox-item>
              <x-button class="btn btn2" @click.native.stop="confirm">确定</x-button>
            </flexbox-item>
          </flexbox>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import { myOrdersClass, rules } from '@/model/my-orders.js'
import valid from '@/utils/valid.js'
import { majorevents } from '@/utils/dictionary.js'
import getStaffInfo from '@/utils/getStaffInfo.js'
import API from '@/utils/api.js'
import { post } from '@/utils/service.js'
import NoResult from '@/components/no-result'
import { Tab, TabItem, Search, XButton, Sticky, Popup, TransferDom, Group, PopupHeader, PopupRadio, Cell, Checker, CheckerItem, Flexbox, FlexboxItem, Datetime, dateFormat } from 'vux'
// 待受理 处理中 已完成
const statusArr = [
  {
    curstepstatus: 'OPEN',
    isaccept: 'UNACCEPT'
  },
  {
    curstepstatus: 'OPEN',
    isaccept: 'ACCEPTED'
  },
  {
    curstepstatus: 'CLOSE',
    isaccept: 'ACCEPTED'
  }
]
export default {
  name: 'MyOrders',
  directives: {
    TransferDom
  },
  filters: {
    dateFormat
  },
  components: {
    Cell,
    Tab,
    TabItem,
    Search,
    XButton,
    Sticky,
    Popup,
    Group,
    PopupHeader,
    PopupRadio,
    Checker,
    CheckerItem,
    Flexbox,
    FlexboxItem,
    Datetime,
    NoResult
  },
  data () {
    // 用于搜索框取消后，判断是否需要重置列表数据
    this.isSearch = false
    this.nextSeqId = 0
    this.tabsPageInfo = [{
      pageNum: 1,
      pages: 1,
      pageSize: 15
    }, {
      pageNum: 1,
      pages: 1,
      pageSize: 15
    }, {
      pageNum: 1,
      pages: 1,
      pageSize: 15
    }]
    return {
      staffInfo: getStaffInfo(),
      disabled: typeof navigator !== 'undefined' && /iphone/i.test(navigator.userAgent) && /ucbrowser/i.test(navigator.userAgent),
      value: '',
      results: [],
      tabs: [{ title: '待受理', num: -1 }, { title: '处理中', num: -1 }, { title: '已完成', num: -1 }],
      list1: [],
      list2: [],
      list3: [],
      tabIndex: 0,
      objectiveGuid: '',
      adjustShow: false,
      people: [],
      person: '',
      emergencyShow: false,
      dateTimeShow: false,
      startTime: '',
      endTime: '',
      checks: majorevents,
      selectedChecker: []
    }
  },
  mounted () {
    // 重置路由深度，重新计数
    window.localStorage.setItem('routeDepth', 0)
    console.log('mounted')
    // 获取工单调剂的处理人
    this.getStaffList()
    this.refresh1()
    this.getOrdersTotalNum(1)
    // 请求三次获得num值
    // this.tabs.forEach((tab, index) => {
    //   this.orderNum({
    //     statusId: this.tabs[index].statusId
    //   }, index)
    // })
    // // 请求第一条数据
    // this.orderDetail({
    //   statusId: this.tabs[0].statusId
    // })
    // // 事件分类
    // this.eventClassificate()
  },
  methods: {
    resetFilterValue () {
      this.selectedChecker = []
      // 已完成状态默认开始时间为一周前
      if (this.tabIndex === 2) {
        this.startTime = dateFormat(+new Date() - 7 * 24 * 60 * 60 * 1000, 'YYYY-MM-DD')
      } else {
        this.startTime = ''
      }
      this.endTime = ''
    },
    tabTitle (tab) {
      if (tab.num > 0 && tab.title !== '已完成') {
        return `${tab.title}(${tab.num})`
      } else {
        return `${tab.title}`
      }
    },
    // 注意事项
    eventClassificate () {
      post('/myOrder/eventClassificate', {})
        .then(res => {
          console.log(res)
          let arr = []
          for (let i = 0; i < res.data.list.length; i++) {
            arr.push(res.data.list[i].text)
          }
          this.checks = arr
        }).catch(error => {
          console.log(error)
        })
    },
    onItemClick (index) {
      // let statusId = this.tabs[index].statusId
      // this.orderDetail({
      //   statusId
      // }, index)
      this.tabIndex = index
      // 切换tab重置搜索过滤条件
      this.resetFilterValue()
      // 重置搜索值
      this.value = ''
      this[`refresh${index + 1}`]()
      this.closeSelectMenu()
    },
    resultClick (item) {
      window.alert('you click the result item: ' + JSON.stringify(item))
    },
    getResult (val) {
      console.log('on-change', val)
      this.results = val ? getResult(this.value) : []
    },
    onSubmit () {
      this.value = this.value.trim()
      if (!this.value) {
        return
      }
      this.isSearch = true
      this[`refresh${this.tabIndex + 1}`]()
      // console.log('搜索的值是' + this.value.trim())
      // this.value = ''
      // this.$refs.search.setBlur()
      // this.$vux.toast.show({
      //   type: 'text',
      //   position: 'top',
      //   text: 'on submit'
      // })
    },
    onFocus () {
      console.log('on focus')
    },
    onCancel () {
      console.log('on cancel')
      // 取消时，如果之前搜索过，列表数据需要重置
      if (this.isSearch) {
        this.isSearch = false
        this.value = ''
        this[`refresh${this.tabIndex + 1}`]()
      }
    },
    adjust ({ objectiveGuid }) {
      this.objectiveGuid = objectiveGuid
      this.adjustShow = true
    },
    adjustConfirm () {
      this.adjustShow = false
      let data = this.people.filter(item => item.key === this.person)
      let params = { ...myOrdersClass }
      params.staffId = this.staffInfo.staffId
      params.objectiveGuid = this.objectiveGuid
      params.toStaffId = data.length ? data[0].toStaffId : ''
      params.toRoleGroup = data.length ? data[0].toRoleGroup : ''
      console.log(params)
      console.log(data)
      if (valid(params, rules)) {
        this.adjustWorkerOrder(params)
      }
    },
    toggleSelectMenu (name) {
      const key = `${name}Show`
      const flag = this[key]
      this.closeSelectMenu()
      flag || this.openSelectMenu(key)
    },
    openSelectMenu (key) {
      this[key] = true
    },
    closeSelectMenu () {
      this.emergencyShow = false
      this.dateTimeShow = false
    },
    clickMask (e) {
      if (e.target.className !== 'mask') {
        return
      }
      this.closeSelectMenu()
    },
    cancel () {
      this.resetFilterValue()
      this.closeSelectMenu()
      console.log('取消')
    },
    confirm () {
      // if (this.selectedChecker.length || this.startTime || this.endTime) {
      this[`refresh${this.tabIndex + 1}`]()
      // }
      this.closeSelectMenu()
      console.log('确认')
    },
    toOrderDetail (data) {
      if (this.tabIndex === 2) {
        // localStorage.setItem('new_order', JSON.stringify(data))
        this.$router.push({
          name: 'OrderFinished',
          params: {
            id: data.tabciflytek.workorderid
          },
          query: {
            objectiveGuid: data.objectiveGuid
          }
        })
      } else {
        if (data.isinterim === '1') {
          if (data.isnewrelation === '1') {
            this.$router.push({
              name: 'NewOrder',
              query: {
                objectiveGuid: data.objectiveGuid,
                operation: 'update',
                isnewrelation: '1'
              }
            })
          } else {
            this.$router.push({
              name: 'NewOrder',
              query: {
                objectiveGuid: data.objectiveGuid,
                operation: 'update'
              }
            })
          }
        } else {
          this.$router.push({
            name: 'OrderDetail',
            params: {
              id: data.tabciflytek.workorderid
            },
            query: {
              objectiveGuid: data.objectiveGuid
            }
          })
        }
      }
    },
    // 订单列表
    orderDetail (data, index = 0) {
      // 请求列表数据
      post('/orderDetail/addList', { ...data })
        .then(res => {
          console.log(res.content.list[0])
          this.list = res.content.list
          this.tabs[index].num = res.content.total
        }).catch(error => {
          console.log(error)
        })
    },
    orderNum (data, index = 0) {
      // 请求列表num值（待受理 处理中 已完成）
      post('/orderDetail/addList', { ...data })
        .then(res => {
          // console.log(res.content.list[0])
          // this.list = res.content.list
          this.tabs[index].num = res.content.total
        }).catch(error => {
          console.log(error)
        })
    },
    infinite1 (done) {
      console.log('infinite1')
      let [ pageInfo ] = this.tabsPageInfo
      if (pageInfo.pages < pageInfo.pageNum) {
        done(true)
        return
      }
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 0, done)
      // this.getWorkerOrderList(this.pageNum)
    },
    refresh1 (done) {
      console.log('refresh1')
      let [ pageInfo ] = this.tabsPageInfo
      pageInfo.pageNum = 1
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 0, done)
      // this.getWorkerOrderList(1)
      // setTimeout(() => {
      //   done()
      // }, 2000)
    },
    infinite2 (done) {
      console.log('infinite2')
      let [ , pageInfo ] = this.tabsPageInfo
      if (pageInfo.pages < pageInfo.pageNum) {
        done(true)
        return
      }
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 1, done)
      // this.getWorkerOrderList(this.pageNum)
    },
    refresh2 (done) {
      console.log('refresh2')
      let [ , pageInfo ] = this.tabsPageInfo
      pageInfo.pageNum = 1
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 1, done)
      // this.getWorkerOrderList(1)
      // setTimeout(() => {
      //   done()
      // }, 2000)
    },
    infinite3 (done) {
      console.log('infinite3')
      let [ , , pageInfo ] = this.tabsPageInfo
      if (pageInfo.pages < pageInfo.pageNum) {
        done(true)
        return
      }
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 2, done)
      // this.getWorkerOrderList(this.pageNum)
    },
    refresh3 (done) {
      console.log('refresh3')
      let [ , , pageInfo ] = this.tabsPageInfo
      pageInfo.pageNum = 1
      this.getWorkerOrderList({
        pageNum: pageInfo.pageNum++,
        pageSize: pageInfo.pageSize
      }, 2, done)
      // this.getWorkerOrderList(1)
      // setTimeout(() => {
      //   done()
      // }, 2000)
    },
    getWorkerOrderList (params, index, done = f => f) {
      const seqId = ++this.nextSeqId
      // 点击筛选菜单确定后，也需要对搜索框的值trim处理
      this.value = this.value.trim()
      // 带上除了工单状态以外的搜索过滤条件
      if (this.value) {
        params.customername = this.value
      }
      this.selectedChecker.forEach(key => {
        params[key] = '1'
      })
      if (this.startTime) {
        params.startdate = this.startTime
      }
      if (this.endTime) {
        params.enddate = this.endTime
      }
      post(API['workerOrderQuery/getWorkerOrderList'], {
        ...params,
        ...statusArr[index],
        handlebyId: this.staffInfo.staffId
      }, true).then(res => {
        // 确保异步请求的返回顺序
        if (seqId !== this.nextSeqId) return
        done()
        console.log(res)
        this.tabs[index].num = res.content.total
        this[`list${index + 1}`] = params.pageNum === 1 ? res.content.list : [...this[`list${index + 1}`], ...res.content.list]
        this.tabsPageInfo[index].pages = res.content.pages
      }).catch(error => {
        done()
        console.log(error)
      })
      // post('/orderDetail/addList', { pageNum, statusId: statusArr[this.tabIndex] })
      //   .then(res => {
      //     console.log(res)
      //     this.list = pageNum === 1 ? res.content.list : [...this.list, ...res.content.list]
      //     if (res.content.pages <= this.pageNum) {
      //     } else {
      //       this.pageNum += 1
      //     }
      //   }).catch(error => {
      //     console.log(error)
      //   })
    },
    getOrdersTotalNum (index) {
      post(API['workerOrderQuery/getWorkerOrderList'], {
        ...statusArr[index],
        handlebyId: this.staffInfo.staffId
      }, true).then(res => {
        console.log(res)
        this.tabs[index].num = res.content.total
      }).catch(error => {
        console.log(error)
      })
    },
    getStaffList () {
      let { rolegroupId } = this.staffInfo
      post(API['mobileStaffQuery/getStaffList'], {
        rolegroupId,
        pageSize: 9999
      }).then(res => {
        console.log(res)
        this.people = res.content.list.map(item => ({
          key: item.staffId,
          value: item.staffname,
          toStaffId: item.staffId,
          toRoleGroup: item.rolegroupId
        }))
      }).catch(err => console.log(err))
    },
    adjustWorkerOrder (params) {
      post(API['workerOrderOperation/adjustWorkerOrder'], params).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            this.$vux.loading.hide()
            this[`refresh${this.tabIndex + 1}`]()
          }
        })
      }).catch(err => console.log(err))
    }
  }
}

function getResult (val) {
  let rs = []
  for (let i = 0; i < 20; i++) {
    rs.push({
      title: `${val} result: ${i + 1} `,
      other: i
    })
  }
  return rs
}
</script>

<style lang="less" scoped>
@color: #3783f6;
.v-transfer-dom {
  .vux-popup-header {
    background-color: #fff;
    & /deep/ .vux-popup-header-right {
      color: @color;
      font-size: 14px;
    }
  }
  .group-wrapper {
    & /deep/ .weui-cells {
      &::after {
        display: none;
      }
      .weui-cell {
        & /deep/ .weui-cell__ft {
          font-size: 14px;
          flex: 0 1 auto;
        }
        &.weui-cell_access.vux-tap-active {
          padding: 10px 15px;
          height: auto;
        }
      }
      .btn {
        border-radius: 0;
        background-color: @color;
        height: 44px;
        color: #fff;
        font-size: 16px;
        &::after {
          display: none;
        }
      }
    }
  }
}
.page {
  .sticky-wrapper {
    height: 132px;
    .filter-wrapper {
      height: 44px;
      display: flex;
      background-color: #fff;
      .filter-item {
        flex: 1;
        line-height: 44px;
        text-align: center;
        color: #333;
        font-size: 14px;
        &.vux-1px-r {
          &::after {
            top: 6px;
            bottom: 6px;
          }
        }
        .dropdown {
          position: relative;
          &::after {
            content: "";
            position: absolute;
            width: 8px;
            height: 8px;
            top: 7px;
            right: -14px;
            background: url("../assets/dropdown.png") no-repeat center
              center/contain;
          }
        }
      }
    }
    & /deep/ .weui-search-bar {
      background-color: #fff;
      .weui-search-bar__box {
        background-color: #efeff4;
      }
      .weui-search-bar__cancel-btn {
        color: @color;
      }
      .weui-search-bar__label {
        background-color: #efeff4;
      }
    }
  }
  .scroller-wrapper {
    position: relative;
    height: calc(~"100% - 132px");
  }
  .order-list {
    // &::before {
    //   content: '';
    //   display: table;
    // }
    .order-item {
      margin-top: 10px;
      padding: 0 15px;
      background-color: #fff;
      .order-header {
        height: 48px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .title {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          font-size: 16px;
          color: #333;
        }
        .code {
          font-size: 11px;
          color: @color;
        }
      }
      .order-body {
        display: flex;
        align-items: center;
        padding: 3px 0;
        .order-body-list {
          flex: 1;
          font-size: 14px;
          color: #333;
          line-height: 28px;
          li {
            list-style: none;
            &::before {
              content: "";
              display: inline-block;
              width: 12px;
              height: 12px;
              margin-right: 12px;
              background: no-repeat center center/contain;
            }
            &.item1::before {
              background-image: url("../assets/ts.png");
            }
            &.item2::before {
              background-image: url("../assets/kh.png");
            }
            &.item3::before {
              background-image: url("../assets/tel.png");
            }
          }
        }
        .btn {
          color: @color;
          border-color: @color;
          width: 62px;
          height: 27px;
          font-size: 14px;
          padding: 0;
          line-height: 14px;
        }
      }
    }
  }
  .mask {
    &.fade-enter,
    &.fade-leave-to {
      opacity: 0;
      .menu {
        transform: translateY(-100%);
      }
    }
    &.fade-enter-active,
    &.fade-leave-active {
      transition: opacity 0.4s;
      .menu {
        transition: transform 0.4s;
      }
    }
    position: fixed;
    width: 100%;
    top: 134px;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 501;
    overflow: hidden;
    background: rgba(0, 0, 0, 0.5);
    .menu {
      background-color: #fff;
      .checks {
        .classify {
          padding: 15px;
          padding-bottom: 20px;
          display: flex;
          flex-wrap: wrap;
          // justify-content: space-between;
          align-items: center;
          background-color: #fff;
        }
        .classify-item {
          margin: 10px 0 10px 0;
          flex-shrink: 1;
          width: 80px;
          height: 25px;
          font-size: 14px;
          line-height: 25px;
          text-align: center;
          border-radius: 3px;
          background-color: #e5e3e3;
        }
        .classify-item-selected {
          color: @color;
          font-size: 14px;
          background: #e6f0fe url("../assets/active.png") no-repeat right
            bottom/auto 50%;
        }
      }
      .date-time {
        height: 24px;
        font-size: 14px;
        color: #333;
      }
      .btns {
        .btn {
          font-size: 16px;
          height: 44px;
          border-radius: 0;
          &.btn1 {
            color: @color;
            background-color: #e6f0fe;
          }
          &.btn2 {
            color: #fff;
            background-color: @color;
          }
          &::after {
            display: none;
          }
        }
      }
    }
  }
}
</style>
