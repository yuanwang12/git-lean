<template>
  <div class="page">
    <div class="sticky-wrapper">
      <sticky
        scroll-box="vux_view_box_body"
        ref="sticky"
        :offset="46"
        :check-sticky-support="false"
        :disabled="disabled">
        <tab :line-width="2" custom-bar-width="80px" active-color="#3783f6">
          <tab-item
            v-for="(tab, index) in tabs"
            :key="index"
            :selected="index === tabIndex"
            @on-item-click="onItemClick">{{tab}}</tab-item>
        </tab>
      </sticky>
    </div>
    <scroller
      lock-x
      style="height: calc(100vh - 90px)"
      ref="scrollerBottom"
    >
      <div>
        <div class="tab1" v-if="tabIndex === 0">
          <Group class="group-wrapper" label-width="56px" label-margin-right="30px" label-align="left">
            <group-title slot="title">
              <div class="group-title">
                <span>客户信息</span>
                <x-button mini plain class="btn" @click.native="toggleShow('custom')">{{toggleText('custom')}}</x-button>
              </div>
            </group-title>
            <cell title="客户名称" :value="tabciflytek.customername" value-align="left"></cell>
            <cell v-show="customShow" title="客户单位" :value="tabciflytek.sq21" value-align="left"></cell>
            <cell title="手机" :value="tabciflytek.mobile" value-align="left"></cell>
            <cell title="地址" :value="tabciflytek.address" value-align="left"></cell>
            <cell v-show="customShow" title="省" :value="tabciflytek.province?tabciflytek.province.provinceDesc:''" value-align="left"></cell>
            <cell v-show="customShow" title="市" :value="tabciflytek.city?tabciflytek.city.cityDesc:''" value-align="left"></cell>
            <cell v-show="customShow" title="区" :value="tabciflytek.area?tabciflytek.area.areaDesc:''" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" label-width="56px" label-margin-right="30px" label-align="left">
            <group-title slot="title">
              <div class="group-title">
                <span>基本信息</span>
                <x-button mini plain class="btn" @click.native="toggleShow('base')">{{toggleText('base')}}</x-button>
              </div>
            </group-title>
            <cell title="工单编号" :value="$route.params.id" value-align="left"></cell>
            <cell title="工单标题" :value="tabciflytek.title" value-align="left"></cell>
            <cell v-show="baseShow" title="工单一级" :value="tabciflytek.sysWorkordertype1?tabciflytek.sysWorkordertype1.workordertype1desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单二级" :value="tabciflytek.sysWorkordertype2?tabciflytek.sysWorkordertype2.workordertype2desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单三级" :value="tabciflytek.sysWorkordertype3?tabciflytek.sysWorkordertype3.workordertype3desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单四级" :value="tabciflytek.sysWorkordertype4?tabciflytek.sysWorkordertype4.workordertype4desc:''" value-align="left"></cell>
            <cell title="产品名称" :value="tabciflytek.stringfield18Obj?tabciflytek.stringfield18Obj.description:''" value-align="left"></cell>
            <cell class="more-rows" title="注意事项" :value="tabciflytek.attioncomments" value-align="left"></cell>
            <div class="checks vux-1px-t" v-show="baseShow">
              <checker
                class="classify"
                v-model="selectedChecker"
                type="checkbox"
                default-item-class="classify-item"
                selected-item-class="classify-item-selected"
              >
                <!-- stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 -->
                <checker-item
                  v-for="i of checks"
                  :key="i.key"
                  :value="i.key"
                  :disabled="true">{{i.value}}</checker-item>
              </checker>
            </div>
          </Group>
          <Group class="group-wrapper" title="问题描述" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.flowdetail" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" title="预处理信息" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.method" value-align="left"></cell>
          </Group>
          <Group v-if="staffInfo.grouptype === 'J00001'" class="group-wrapper" title="问题原因及处理结果" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.methodpath" value-align="left"></cell>
          </Group>
          <Group v-if="staffInfo.grouptype === 'J00001'" class="group-wrapper" title="规范、必要性" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.methodrule" value-align="left"></cell>
          </Group>
          <Group
            v-if="objectiveRelationList.length"
            class="group-wrapper connect-Order"
            title="关联工单"
          >
            <cell
              v-for="item in objectiveRelationList"
              :key="item.objectiveGuid"
              :title="item.workorderid"
              @click.native="toConnectOrder(item)"
            >
              <span class="color">{{item.workorderStatus}}</span>
            </cell>
          </Group>
        </div>
        <div class="tab2" v-if="tabIndex === 1">
          <Group class="group-wrapper no-border-gap" gutter="10px" label-width="56px" label-margin-right="30px" label-align="left">
            <popup-radio title="解决方式" :options="dealTypes" v-model="params.dealType" placeholder="请选择"></popup-radio>
            <cell v-if="params.dealType === dealTypes[0].key" @click.native="geolocation" class="address" :border-intent="false" title="位置" :value="address" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" gutter="10px" label-align="left">
            <cell title="本步意见" value-align="left"></cell>
            <x-textarea :show-counter="false" :max="200" :height="56" placeholder="请输入" v-model="params.comments"></x-textarea>
          </Group>
          <template  v-if="staffInfo.grouptype === 'J00001'">
            <Group class="group-wrapper" gutter="10px" label-align="left">
              <cell title="问题原因" value-align="left"></cell>
              <x-textarea :show-counter="false" :max="200" :height="56" placeholder="请输入" v-model="params.stringfield28"></x-textarea>
            </Group>
            <Group class="group-wrapper" gutter="10px" label-align="left">
              <cell title="处理结果" value-align="left"></cell>
              <x-textarea :show-counter="false" :max="200" :height="56" placeholder="请输入" v-model="params.stringfield29"></x-textarea>
            </Group>
          </template>
          <template v-else>
            <Group class="group-wrapper" gutter="10px" label-align="left">
              <cell title="问题原因及处理结果" value-align="left"></cell>
              <x-textarea :show-counter="false" :max="200" :height="56" placeholder="请输入" v-model="params.methodpath"></x-textarea>
            </Group>
            <Group class="group-wrapper" gutter="10px" label-align="left">
              <cell title="规范性、必要性" value-align="left"></cell>
              <x-textarea :show-counter="false" :max="200" :height="56" placeholder="请输入" v-model="params.methodrule"></x-textarea>
            </Group>
          </template>

          <Group class="group-wrapper no-border-gap" gutter="10px" label-width="70px" label-margin-right="16px" label-align="left">
            <popup-radio
              title="下一步操作"
              :options="nextStepTypes[staffInfo.grouptype]"
              v-model="params.nextStepType"
              placeholder="请选择"></popup-radio>
          </Group>

          <template v-if="staffInfo.grouptype === 'G00001' && params.nextStepType === '3'">
            <Group class="group-wrapper no-border-gap" gutter="10px" label-width="70px" label-margin-right="16px" label-align="left">
              <popup-radio
                title="技术支持组"
                :options="toRoleGroups"
                v-model="params.toRoleGroup"
                @on-hide="setCurrentRolegroupId"
                placeholder="请选择"></popup-radio>
            </Group>
            <Group class="group-wrapper no-border-gap" gutter="10px" label-width="70px" label-margin-right="16px" label-align="left">
              <popup-radio
                title="技术支持人"
                :options="toStaffIdsFilter"
                v-model="params.toStaffId"
                placeholder="请选择"></popup-radio>
            </Group>
          </template>

          <div class="imgList">
            <div
              class="img-item"
              v-for="(url, index) of imgList"
              :key="url.id"
              :style="{'backgroundImage': `url(${url.url})`}">
              <div class="icon-remove" @click="removeImgItem(index)"></div>
            </div>
            <div class="img-item upload" @click="takePhoto" v-if="imgList.length<imgCount"></div>
          </div>
          <div class="btns" style="margin: 0 15px 15px 15px">
            <x-button class="btn btn1" @click.native="handleOrder('SAVE')">保存</x-button>
            <x-button class="btn btn2" @click.native="handleOrder('SEND')">下送</x-button>
          </div>
        </div>
        <div class="tab3" v-if="tabIndex === 2">
          <Group
            v-for="i of workorderStepList"
            :key="i.workorderstepGuid"
            class="group-wrapper"
            gutter="10px"
            label-width="56px"
            label-margin-right="30px"
            label-align="left">
            <cell title="处理时间" :value="i.modifieddate | dateFormat" value-align="left"></cell>
            <cell title="操作" :value="i.syscWorkorderstepstatus?i.syscWorkorderstepstatus.workorderstepstatusdesc:''" value-align="left"></cell>
            <cell title="处理组" :value="i.oldhandleGroup?i.oldhandleGroup.description:''" value-align="left"></cell>
            <cell title="处理人" :value="i.oldHandlebyStaff?i.oldHandlebyStaff.staffName:''" value-align="left"></cell>
          </Group>
        </div>
      </div>
    </scroller>
  </div>
</template>

<script>
import { majorevents } from '@/utils/dictionary.js'
import getStaffInfo from '@/utils/getStaffInfo.js'
import API from '@/utils/api.js'
import { post } from '@/utils/service.js'
import { orderDetailClass, rules } from '@/model/orderDetail.js'
import valid from '@/utils/valid.js'
import { Scroller, dateFormat, Tab, TabItem, Group, GroupTitle, XButton, Cell, Sticky, PopupRadio, XTextarea, Checker, CheckerItem } from 'vux'
const orderDetailVm = {
  name: 'OrderDetail',
  components: {
    Tab,
    TabItem,
    Group,
    GroupTitle,
    Cell,
    Sticky,
    XButton,
    PopupRadio,
    XTextarea,
    Checker,
    CheckerItem,
    Scroller
  },
  filters: {
    dateFormat
  },
  data () {
    const staffInfo = getStaffInfo()
    return {
      staffInfo,
      tabciflytek: {},
      workorderStepList: [],
      objectiveRelationList: [],
      disabled: typeof navigator !== 'undefined' && /iphone/i.test(navigator.userAgent) && /ucbrowser/i.test(navigator.userAgent),
      tabs: ['工单描述', '问题处理', '工单历史'],
      tabIndex: 0,
      customShow: false,
      baseShow: false,
      params: Object.assign({}, orderDetailClass[staffInfo.grouptype]),
      checks: majorevents,
      selectedChecker: [],
      address: '点击获取位置',
      imgCount: 4,
      imgList: [],
      // imgList: [
      //   {id: 1, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3044191397,2911599132&fm=27&gp=0.jpg'},
      //   {id: 2, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=302701032,2300144492&fm=27&gp=0.jpg'},
      //   {id: 3, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3498018351,3670820427&fm=27&gp=0.jpg'},
      //   {id: 4, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3536314877,3587590266&fm=27&gp=0.jpg'}
      // ],
      dealTypes: [
        {key: '5003', value: '现场服务'},
        {key: '5001', value: '电话指导'},
        {key: '5002', value: '远程支持'}
      ],
      nextStepTypes: {
        'G00001': [
          {key: '1', value: '继续'},
          // {key: '2', value: '强制结单'},
          {key: '3', value: '技术支持'}
        ],
        'J00001': [
          {key: '4', value: '未完成'},
          {key: '5', value: '完成'}
        ]
      },
      toRoleGroups: [],
      toStaffIds: [],
      currentRolegroupId: ''
    }
  },
  mounted () {
    window.orderDetailVmAddAttachmentCallBack = this.addAttachmentCallBack
    // console.log(this.$route)
    this.getGroupAndStaff()
    this.openWorkerOrder()
    // let storage = window.localStorage
    // let item = storage.getItem('new_order')
    // let orderDetailValue = JSON.parse(item)
    // if (orderDetailValue) {
    //   this.params = {...this.params, ...orderDetailValue}
    // }
  },
  updated () {
    console.log('updated')
    // console.log(this.$route)
  },
  watch: {
    $route (to, from) {
      if (to.params.id !== from.params.id) {
        this.openWorkerOrder()
      }
    }
  },
  computed: {
    toStaffIdsFilter () {
      return this.toStaffIds.filter(item => item.rolegroupId === this.currentRolegroupId)
    }
  },
  methods: {
    setCurrentRolegroupId () {
      let currentRolegroupId = this.toRoleGroups.filter(item => item.key === this.params.toRoleGroup)[0].rolegroupId
      // 重置技术组id的同时也要重置技术人id
      if (currentRolegroupId !== this.currentRolegroupId) {
        this.currentRolegroupId = currentRolegroupId
        this.params.toStaffId = ''
      }
    },
    // 拍照
    takePhoto () {
      console.log('进入拍照功能')
      let userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'))
      // null处理
      if (!userInfo) userInfo = {}
      let params = {
        'url': 'https://xfkfapi.iflytek.com/exchange-file-service/fileModify/uploadImage',
        'canUploadCount': this.imgCount - this.imgList.length,
        'sourceType': '',
        'createAccount': userInfo.userAccount,
        'token': userInfo.token,
        'createUser': userInfo.userName,
        'userAccount': userInfo.userAccount,
        'callBack': 'orderDetailVmAddAttachmentCallBack'
      }
      console.log(params)
      const isIOS = window.localStorage.getItem('isIOS')
      /* eslint-disable no-undef */
      isIOS === 'true' ? takePhoto(params) : iflyapp.takePhoto(JSON.stringify(params))
    },
    addAttachmentCallBack (data) {
      // window.alert(JSON.stringify(data))
      console.log(data)
      if (!data[0].result) {
        this.$vux.toast.show({
          type: 'warn',
          text: data[0].message
        })
        return
      }
      let urls = data.map(item => ({
        id: item.content.id,
        url: item.content.uploadUrl
      }))
      this.imgList = [
        ...this.imgList,
        ...urls
      ]
      // window.alert(JSON.stringify(this.imgList))
    },
    removeImgItem (i) {
      this.imgList = this.imgList.filter((url, index) => index !== i)
      console.log('移除')
    },
    // 获取经纬度
    geolocation () {
      this.address = '定位中...'
      /* eslint-disable no-undef */
      const geolocation = new AMap.Geolocation({
        enableHighAccuracy: true, // 是否使用高精度定位，默认:true
        timeout: 10000            // 超过10秒后停止定位，默认：无穷大
      })
      geolocation.getCurrentPosition((status, result) => {
        // window.alert('获取经纬度')
        // console.log(status, result)
        if (result && result.position) {
          const lnglat = [result.position.lng, result.position.lat]
          this.geocoder(lnglat)
        } else {
          // this.$vux.toast.show({
          //   type: 'cancel',
          //   text: JSON.stringify(result),
          //   time: 5000
          // })
          // window.alert(JSON.stringify(result))
          this.address = '定位失败'
          if (result.status === 0) {
            window.alert('请开启定位权限')
          }
        }
      })
      // this.geocoder([116.396574, 39.992706])
    },
    // 逆地理位置编码
    geocoder (lnglat) {
      /* eslint-disable no-undef */
      const geocoder = new AMap.Geocoder({
        radius: 1000,
        extensions: 'all'
      })
      geocoder.getAddress(lnglat, (status, result) => {
        // window.alert('逆地理位置编码')
        console.log(status, result)
        if (status === 'complete' && result.info === 'OK') {
          if (result && result.regeocode) {
            this.address = result.regeocode.formattedAddress
            return
          }
        }
        // this.$vux.toast.show({
        //   type: 'cancel',
        //   text: JSON.stringify(result),
        //   time: 5000
        // })
        // window.alert(JSON.stringify(result))
        this.address = '定位失败'
      })
    },
    onItemClick (index) {
      this.tabIndex = index
      console.log('on item click:', index)
      this.$nextTick(() => {
        this.$refs.scrollerBottom.reset({top: 0})
      })
    },
    toggleShow (name) {
      const key = `${name}Show`
      this[key] = !this[key]
    },
    toggleText (name) {
      const key = `${name}Show`
      return this[key] ? '隐藏详细信息' : '查看详细信息'
    },
    handleOrder (operateType) {
      if (valid(this.params, rules[this.staffInfo.grouptype])) {
        this.$vux.confirm.show({
          title: '提示',
          content: `确定${operateType === 'SAVE' ? '保存' : '下送'}?`,
          onConfirm: () => {
            let params = this.params
            params.objectiveGuid = this.$route.query.objectiveGuid
            params.operateType = operateType
            params.staffId = this.staffInfo.staffId
            if (!['点击获取位置', '定位中...', '定位失败'].includes(this.address)) {
              params.position = this.address
            }
            if (this.imgList.length) {
              params.filePath = this.imgList.map(item => item.url).join('*')
            } else {
              params.filePath = ''
            }
            // 下一步操作位不是继续支持 清除支持组和技术人id
            if (this.params.nextStepType !== '3') {
              this.params.toRoleGroup = ''
              this.params.toStaffId = ''
            }
            this.handleWorkerOrder(params)
          }
        })
      }
    },
    toConnectOrder (data) {
      if (data.isinterim === '1') {
        this.$router.push({
          name: 'NewOrder',
          query: {
            objectiveGuid: data.objectiveGuid
          }
        })
      } else {
        if (data.workorderStatus === '已完成') {
          this.$router.push({
            name: 'OrderFinished',
            params: {
              id: data.workorderid
            },
            query: {
              objectiveGuid: data.objectiveGuid
            }
          })
        } else {
          this.$router.push({
            name: 'OrderDetail',
            params: {
              id: data.workorderid
            },
            query: {
              objectiveGuid: data.objectiveGuid
            }
          })
        }
      }
    },
    handleWorkerOrder (params) {
      post(API['workerOrderOperation/handleWorkerOrder'], params).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            this.$vux.loading.hide()
            let routeDepth = window.localStorage.getItem('routeDepth')
            this.$router.go(-Number(routeDepth))
          }
        })
      }).catch(err => console.log(err))
    },
    openWorkerOrder () {
      post(API['workerOrderQuery/openWorkerOrder'], {
        objectiveGuid: this.$route.query.objectiveGuid,
        handlebyId: this.staffInfo.staffId
      }).then(res => {
        console.log(res)
        this.tabciflytek = res.content.tabciflytek
        this.workorderStepList = res.content.workorderStepList
        this.objectiveRelationList = res.content.objectiveRelationList
        this.selectedChecker = majorevents.map(item => item.key).filter(key => this.tabciflytek[key])
        const { filePathList: urls = [] } = res.content
        if (urls.length) {
          this.imgList = urls.map((item, index) => ({
            id: index,
            url: item.path
          }))
        }
        let { comments } = res.content.objective
        let { stringfield28, stringfield29, methodpath, methodrule, stringfield26: dealType } = res.content.tabciflytek
        if (!comments) comments = ''
        if (!dealType) dealType = ''
        if (!stringfield28) stringfield28 = ''
        if (!stringfield29) stringfield29 = ''
        if (!methodpath) methodpath = ''
        if (!methodrule) methodrule = ''
        this.params = {
          ...this.params,
          // comments,
          stringfield28,
          stringfield29,
          methodpath,
          methodrule,
          dealType
        }
        this.$nextTick(() => {
          this.$refs.scrollerBottom.reset()
        })
      }).catch(err => console.log(err))
    },
    getGroupAndStaff () {
      const { grouptype } = this.staffInfo
      if (grouptype === 'J00001') return
      post(API['mobileGroupAndStaff/getGroupAndStaff'], {
        rolegrouptype: 'J00001'
      }).then(res => {
        console.log(res)
        this.toRoleGroups = res.content.filter(item => item.type === 'GROUP').map(item => ({
          key: item.id,
          value: item.text,
          rolegroupId: item.rolegroupId
        }))
        this.toStaffIds = res.content.filter(item => item.type === 'STAFF').map(item => ({
          key: item.id,
          value: item.text,
          rolegroupId: item.rolegroupId
        }))
        // 设置默认技术组
        this.params.toRoleGroup = this.toRoleGroups[0].key
        this.currentRolegroupId = this.toRoleGroups[0].rolegroupId
      }).catch(err => console.log(err))
    }
  }
}

// window.orderDetailVmAddAttachmentCallBack = function (data) {
//   window.alert(JSON.stringify(data))
//   window.alert(JSON.stringify(orderDetailVm.methods))
//   window.alert(JSON.stringify(orderDetailVm.methods.addAttachmentCallBack))
//   orderDetailVm.methods.addAttachmentCallBack(data)
// }

export default orderDetailVm
</script>

<style lang="less" scoped>
@color: #3783f6;
.page {
  // padding-bottom: 45px;
  // overflow: auto;
  .sticky-wrapper {
    height: 44px;
  }
  .group-title {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .btn {
      color: @color;
      border-color: @color;
      margin: 0;
      width: 82px;
      height: 23px;
      font-size: 11px;
      line-height: 23px;
      padding: 0;
    }
  }
  .group-wrapper {
    &.no-border-gap {
      .weui-cell {
        &::before {
          right: 0;
        }
      }
    }
    .weui-cell {
      &.more-rows {
        & /deep/ .vux-cell-bd {
          align-self: flex-start;
        }
        // & /deep/ .weui-cell__ft.vux-cell-primary.vux-cell-align-left {
        //   line-height: 22px;
        // }
      }
      &.weui-cell_access.vux-tap-active {
        padding: 10px 15px;
        height: auto;
      }
      &::before {
        right: 15px;
      }
      & /deep/ .vux-cell-primary {
        overflow: hidden;
        font-size: 14px;
        color: #333;
        & > p {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
      & /deep/ .vux-label {
        font-size: 14px;
        color: #666;
      }
    }
  }
  .tab1 {
    padding-bottom: 45px;
    .color {
      color: @color;
      font-size: 14px;
    }
    .checks {
      &.vux-1px-t {
        &::before {
          left: 15px;
          right: 15px;
        }
      }
      .classify {
        padding: 5px 15px;
        display: flex;
        flex-wrap: wrap;
        // justify-content: space-between;
        align-items: center;
        background-color: #fff;
      }
      .classify-item {
        margin: 10px 0 10px 0;
        // stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 ~避免calc内的值在编译时被计算
        margin-right: calc(~"(100vw - 350px) / 3");
        flex-shrink: 1;
        width: 80px;
        height: 25px;
        font-size: 14px;
        line-height: 25px;
        text-align: center;
        border-radius: 3px;
        background-color: #e5e3e3;
        &:nth-of-type(4n) {
          margin-right: 0;
        }
      }
      .classify-item-selected {
        color: @color;
        font-size: 14px;
        background: #e6f0fe url("../assets/active.png") no-repeat right
          bottom/auto 50%;
      }
    }
  }
  .tab2 {
    padding-bottom: 45px;
    .weui-cell {
      & /deep/ .vux-cell-primary {
        flex: 0 1 auto;
        color: #999;
      }
      & /deep/ .vux-label {
        color: #333;
      }
      & /deep/ .weui-cell__ft {
        margin-left: 0;
      }
      &.address {
        & /deep/ .weui-cell__ft.vux-cell-primary.vux-cell-align-left {
          flex: 1;
          margin-right: 13px;
          &::after {
            content: " ";
            display: inline-block;
            height: 18px;
            width: 14px;
            top: -2px;
            position: absolute;
            top: 50%;
            margin-top: -9px;
            right: 15px;
            background: url("../assets/address.png") no-repeat center
              center/contain;
          }
        }
      }
      &.vux-x-textarea {
        &::before {
          display: none;
        }
        padding: 0 15px 15px 15px;
      }
    }
  }
  .tab3 {
    padding-bottom: 45px;
  }
  .imgList {
    padding: 15px 0 0 15px;
    display: flex;
    flex-wrap: wrap;
    .img-item {
      position: relative;
      width: calc(~"(100vw - 75px) / 4");
      height: calc(~"(100vw - 75px) / 4");
      margin: 0 15px 15px 0;
      background: url("../assets/camera_icon.png") no-repeat center center/cover;
      &.upload {
        background-image: url("../assets/cameral.png");
        background-size: 25px;
        background-color: #fff;
      }
      .icon-remove {
        position: absolute;
        top: -5px;
        right: -5px;
        width: 20px;
        height: 20px;
        background: url("../assets/icon-remove.png") no-repeat center center/cover;
      }
    }
  }
  .btns {
    display: flex;
    justify-content: space-around;
    align-items: center;
    .btn {
      width: 165px;
      height: 45px;
      font-size: 16px;
      margin: 0;
      padding: 0;
      &::after {
        display: none;
      }
      &.btn1 {
        color: @color;
        background-color: #e6f0fe;
      }
      &.btn2 {
        color: #fff;
        background-color: @color;
      }
    }
  }
}
</style>
