<template>
  <div class="page">
    <!-- 搜索 -->
    <search
      placeholder="请输入客户手机号查询"
      :results="results"
      v-model="value"
      position="absolute"
      :auto-fixed="false"
      auto-scroll-to-top
      top="46px"
      @result-click="resultClick"
      @on-change="getResult"
      @on-focus="onFocus"
      @on-cancel="onCancel"
      @on-submit="onSubmit"
      ref="search"
    />
    <!-- 数据展示 -->
    <div class="scroller-wrapper" v-if="isSearch">
      <scroller
        v-if="list.length"
        class="vux-1px-tb scroller-wrapper"
        :on-infinite="infinite"
        :on-refresh="refresh"
        ref="myscroller"
      >
        <div v-for="i in list" :key="i.id" @click="goNewOrder(i)">
          <div class="custom-item vux-1px-b">
            <div class="custom-body-info">
              <ul class="custom-body-list">
                <li class="custom-name">{{i.customername}}</li>
                <li class="custom-phone">{{i.mobile}}</li>
              </ul>
            </div>
            <div class="custom-body-address">
              <div class="custom-address-wrap">
                  <span class="custom-address">{{i.address}}</span>
              </div>
            </div>
          </div>
        </div>
      </scroller>
      <no-result v-else />
    </div>
  </div>
</template>

<script>
import { post } from '@/utils/service.js'
import API from '@/utils/api.js'
import NoResult from '@/components/no-result'
import { Search, Card } from 'vux'
export default {
  name: 'CustomQuery',
  components: {
    Search,
    Card,
    NoResult
  },
  data () {
    // 用于搜索框取消后，判断是否需要重置列表数据
    // this.isSearch = false
    this.pageNum = 1
    this.pageSize = 15
    this.pages = 1
    return {
      isSearch: false,
      value: '',
      statu: '',
      results: [],
      list: []
    }
  },
  // 客户查询数据源
  mounted () {
    console.log('mounted')
    // this.getCustomerList({
    //   pageNum: this.pageNum++
    // })
    // this.refresh()
  },
  methods: {
    onItemClick (index) {
      console.log('on item click:', index)
    },
    resultClick (item) {
      window.alert('you click the result item: ' + JSON.stringify(item))
    },
    getResult (val) {
      console.log('on-change', val)
    },
    onSubmit () {
      this.value = this.value.trim()
      if (!this.value) {
        return
      }
      // 这里设置isSearch会在接口返回list数据前短暂闪现no-data组件
      // this.isSearch = true
      this.refresh()
      // this.pageNum = 1
      // this.getCustomerList({
      //   pageNum: this.pageNum++
      // })
      // this.$refs.search.setBlur()
    },
    onFocus () {
      console.log('on focus')
    },
    onCancel () {
      console.log('on cancel')
      this.isSearch = false
      this.list = []
      // 取消时，如果之前搜索过，列表数据需要重置
      // if (this.isSearch) {
      //   this.isSearch = false
      //   this.value = ''
      //   this.refresh()
      // }
    },
    goNewOrder (data) {
      window.localStorage.setItem('customerInfo', JSON.stringify(data))
      this.$router.back()
    },
    goPage (data) {
      var item = data
      let storage = localStorage
      let myOrder = storage.getItem('my_order')
      let order = JSON.parse(myOrder)
      order = { ...order, ...item }
      localStorage.setItem('my_order', JSON.stringify(order))
      this.$router.back()
    },
    infinite (done) {
      console.log('infinite')
      if (this.pages < this.pageNum) {
        done(true)
        return
      }
      this.getCustomerList({
        pageNum: this.pageNum++
      }, done)
    },
    refresh (done) {
      console.log('refresh')
      this.pageNum = 1
      this.getCustomerList({
        pageNum: this.pageNum++
      }, done)
    },
    getCustomerList (params, done = f => f) {
      if (this.value) {
        params = {...params, mobile: this.value}
      }
      post(API['mobileCustomerQuery/getCustomerList'], {
        ...params,
        pageSize: this.pageSize
      }, true).then(res => {
        done()
        console.log(res)
        this.list = params.pageNum === 1 ? res.content.list : [...this.list, ...res.content.list]
        this.pages = res.content.pages
        this.isSearch = true
      }).catch(error => {
        done()
        console.log(error)
        this.isSearch = true
      })
    }
  }
}
</script>

<style lang="less">
@import url("../css/custom-query/costom-query.css");
@import "~vux/src/styles/1px.less";
</style>
<style lang="less" scoped>
.scroller-wrapper {
  position: relative;
  height: calc(~"100% - 50px");
}
.custom-item {
  background-color: #fff;
}
</style>



