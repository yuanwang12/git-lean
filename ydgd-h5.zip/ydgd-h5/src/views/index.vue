<template>
  <div class="page">
    <div class="banner">
      <img src="../assets/home/banner.png"
           alt="">
    </div>
    <grid>
      <grid-item link="/newOrder"
                 class="op-wrapper">
        <img slot="icon"
             src="../assets/home/neworder.png">
        <span slot="label"
              class="lable-name">新建工单</span>
      </grid-item>
      <grid-item link="/myOrders">
        <img slot="icon"
             class="grid-icon"
             src="../assets/home/myorder.png">
        <span slot="label"
              class="lable-name">我的工单</span>
      </grid-item>
    </grid>
  </div>
</template>

<script>
import { Grid, GridItem, GroupTitle } from 'vux'
export default {
  name: 'Index',
  components: {
    Grid,
    GridItem,
    GroupTitle
  }
}
</script>

<style scoped>
@import url('../css/index.css');
</style>
