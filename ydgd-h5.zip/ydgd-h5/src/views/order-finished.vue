<template>
  <div class="page">
    <div class="sticky-wrapper">
      <sticky
        scroll-box="vux_view_box_body"
        ref="sticky"
        :offset="46"
        :check-sticky-support="false"
        :disabled="disabled">
        <tab :line-width="2" custom-bar-width="80px" active-color="#3783f6">
          <tab-item
            v-for="(tab, index) in tabs"
            :key="index"
            :selected="index === tabIndex"
            @on-item-click="onItemClick">{{tab}}</tab-item>
        </tab>
      </sticky>
    </div>
    <scroller
      lock-x
      style="height: calc(100vh - 90px)"
      ref="scrollerBottom"
    >
      <div>
        <div class="tab1" v-if="tabIndex === 0">
          <Group class="group-wrapper" label-width="56px" label-margin-right="30px" label-align="left">
            <group-title slot="title">
              <div class="group-title">
                <span>客户信息</span>
                <x-button mini plain class="btn" @click.native="toggleShow('custom')">{{toggleText('custom')}}</x-button>
              </div>
            </group-title>
            <cell title="客户名称" :value="tabciflytek.customername" value-align="left"></cell>
            <cell v-show="customShow" title="客户单位" :value="tabciflytek.sq21" value-align="left"></cell>
            <cell title="手机" :value="tabciflytek.mobile" value-align="left"></cell>
            <cell title="地址" :value="tabciflytek.address" value-align="left"></cell>
            <cell v-show="customShow" title="省" :value="tabciflytek.province?tabciflytek.province.provinceDesc:''" value-align="left"></cell>
            <cell v-show="customShow" title="市" :value="tabciflytek.city?tabciflytek.city.cityDesc:''" value-align="left"></cell>
            <cell v-show="customShow" title="区" :value="tabciflytek.area?tabciflytek.area.areaDesc:''" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" label-width="56px" label-margin-right="30px" label-align="left">
            <group-title slot="title">
              <div class="group-title">
                <span>基本信息</span>
                <x-button mini plain class="btn" @click.native="toggleShow('base')">{{toggleText('base')}}</x-button>
              </div>
            </group-title>
            <cell title="工单编号" :value="$route.params.id" value-align="left"></cell>
            <cell title="工单标题" :value="tabciflytek.title" value-align="left"></cell>
            <cell v-show="baseShow" title="工单一级" :value="tabciflytek.sysWorkordertype1?tabciflytek.sysWorkordertype1.workordertype1desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单二级" :value="tabciflytek.sysWorkordertype2?tabciflytek.sysWorkordertype2.workordertype2desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单三级" :value="tabciflytek.sysWorkordertype3?tabciflytek.sysWorkordertype3.workordertype3desc:''" value-align="left"></cell>
            <cell v-show="baseShow" title="工单四级" :value="tabciflytek.sysWorkordertype4?tabciflytek.sysWorkordertype4.workordertype4desc:''" value-align="left"></cell>
            <cell title="产品名称" :value="tabciflytek.stringfield18Obj?tabciflytek.stringfield18Obj.description:''" value-align="left"></cell>
            <cell class="more-rows" title="注意事项" :value="tabciflytek.attioncomments" value-align="left"></cell>
            <div class="checks vux-1px-t" v-show="baseShow">
              <checker
                class="classify"
                v-model="selectedChecker"
                type="checkbox"
                default-item-class="classify-item"
                selected-item-class="classify-item-selected"
              >
                <!-- stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 -->
                <checker-item
                  v-for="i of checks"
                  :key="i.key"
                  :value="i.key"
                  :disabled="true">{{i.value}}</checker-item>
              </checker>
            </div>
          </Group>
          <Group class="group-wrapper" title="问题描述" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.flowdetail" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" title="预处理信息" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.method" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" title="问题原因及处理结果" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.methodpath" value-align="left"></cell>
          </Group>
          <Group class="group-wrapper" title="规范、必要性" label-width="56px" label-margin-right="30px" label-align="left">
            <cell :value="tabciflytek.methodrule" value-align="left"></cell>
          </Group>
          <Group
            v-if="objectiveRelationList.length"
            class="group-wrapper connect-Order"
            title="关联工单"
          >
            <cell
              v-for="item in objectiveRelationList"
              :key="item.objectiveGuid"
              :title="item.workorderid"
              @click.native="toConnectOrder(item)"
            >
              <span class="color">{{item.workorderStatus}}</span>
            </cell>
          </Group>
        </div>
        <div class="tab3" v-if="tabIndex === 1">
          <Group
            v-for="i of workorderStepList"
            :key="i.workorderstepGuid"
            class="group-wrapper"
            gutter="10px"
            label-width="56px"
            label-margin-right="30px"
            label-align="left">
            <cell title="处理时间" :value="i.modifieddate | dateFormat" value-align="left"></cell>
            <cell title="操作" :value="i.syscWorkorderstepstatus?i.syscWorkorderstepstatus.workorderstepstatusdesc:''" value-align="left"></cell>
            <cell title="处理组" :value="i.oldhandleGroup?i.oldhandleGroup.description:''" value-align="left"></cell>
            <cell title="处理人" :value="i.oldHandlebyStaff?i.oldHandlebyStaff.staffName:''" value-align="left"></cell>
          </Group>
        </div>
      </div>
    </scroller>
  </div>
</template>

<script>
import { majorevents } from '@/utils/dictionary.js'
import getStaffInfo from '@/utils/getStaffInfo.js'
import API from '@/utils/api.js'
import { post } from '@/utils/service.js'
import { Scroller, dateFormat, Tab, TabItem, Group, GroupTitle, XButton, Cell, Sticky, PopupRadio, XTextarea, Checker, CheckerItem } from 'vux'
export default {
  name: 'OrderDetail',
  components: {
    Tab,
    TabItem,
    Group,
    GroupTitle,
    Cell,
    Sticky,
    XButton,
    PopupRadio,
    XTextarea,
    Checker,
    CheckerItem,
    Scroller
  },
  filters: {
    dateFormat
  },
  data () {
    return {
      staffInfo: getStaffInfo(),
      tabciflytek: {},
      workorderStepList: [],
      objectiveRelationList: [],
      disabled: typeof navigator !== 'undefined' && /iphone/i.test(navigator.userAgent) && /ucbrowser/i.test(navigator.userAgent),
      tabs: ['工单描述', '工单历史'],
      tabIndex: 0,
      customShow: false,
      baseShow: false,
      checks: majorevents,
      selectedChecker: []
    }
  },
  mounted () {
    this.openWorkerOrder()
    // let storage = window.localStorage
    // let item = storage.getItem('new_order')
    // let orderDetailValue = JSON.parse(item)
    // if (orderDetailValue) {
    //   this.params = {...this.params, ...orderDetailValue}
    // }
  },
  updated () {
    console.log('updated')
  },
  watch: {
    $route (to, from) {
      if (to.params.id !== from.params.id) {
        this.openWorkerOrder()
      }
    }
  },
  methods: {
    onItemClick (index) {
      this.tabIndex = index
      console.log('on item click:', index)
      this.$nextTick(() => {
        this.$refs.scrollerBottom.reset({top: 0})
      })
    },
    toggleShow (name) {
      const key = `${name}Show`
      this[key] = !this[key]
    },
    toggleText (name) {
      const key = `${name}Show`
      return this[key] ? '隐藏详细信息' : '查看详细信息'
    },
    toConnectOrder (data) {
      if (data.isinterim === '1') {
        this.$router.push({
          name: 'NewOrder',
          query: {
            objectiveGuid: data.objectiveGuid
          }
        })
      } else {
        if (data.workorderStatus === '已完成') {
          this.$router.push({
            name: 'OrderFinished',
            params: {
              id: data.workorderid
            },
            query: {
              objectiveGuid: data.objectiveGuid
            }
          })
        } else {
          this.$router.push({
            name: 'OrderDetail',
            params: {
              id: data.workorderid
            },
            query: {
              objectiveGuid: data.objectiveGuid
            }
          })
        }
      }
    },
    openWorkerOrder () {
      post(API['workerOrderQuery/openWorkerOrder'], {
        objectiveGuid: this.$route.query.objectiveGuid,
        handlebyId: this.staffInfo.staffId
      }).then(res => {
        console.log(res)
        this.tabciflytek = res.content.tabciflytek
        this.workorderStepList = res.content.workorderStepList
        this.objectiveRelationList = res.content.objectiveRelationList
        this.selectedChecker = majorevents.map(item => item.key).filter(key => this.tabciflytek[key])
        this.$nextTick(() => {
          this.$refs.scrollerBottom.reset()
        })
      }).catch(err => console.log(err))
    }
  }
}
</script>

<style lang="less" scoped>
@color: #3783f6;
.page {
  // padding-bottom: 45px;
  .sticky-wrapper {
    height: 44px;
  }
  .group-title {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .btn {
      color: @color;
      border-color: @color;
      margin: 0;
      width: 82px;
      height: 23px;
      font-size: 11px;
      line-height: 23px;
      padding: 0;
    }
  }
  .group-wrapper {
    &.no-border-gap {
      .weui-cell {
        &::before {
          right: 0;
        }
      }
    }
    .weui-cell {
      &.more-rows {
        & /deep/ .vux-cell-bd {
          align-self: flex-start;
        }
        // & /deep/ .weui-cell__ft.vux-cell-primary.vux-cell-align-left {
        //   line-height: 22px;
        // }
      }
      &.weui-cell_access.vux-tap-active {
        padding: 10px 15px;
        height: auto;
      }
      &::before {
        right: 15px;
      }
      & /deep/ .vux-cell-primary {
        overflow: hidden;
        font-size: 14px;
        color: #333;
         & > p {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
      & /deep/ .vux-label {
        font-size: 14px;
        color: #666;
      }
    }
  }
  .tab1 {
    padding-bottom: 45px;
    .color {
      color: @color;
      font-size: 14px;
    }
    .checks {
      &.vux-1px-t {
        &::before {
          left: 15px;
          right: 15px;
        }
      }
      .classify {
        padding: 5px 15px;
        display: flex;
        flex-wrap: wrap;
        // justify-content: space-between;
        align-items: center;
        background-color: #fff;
      }
      .classify-item {
        margin: 10px 0 10px 0;
        // stylus中 calc内的%和vw等单位和px做运算 后者的px会被替换为前者单位 ~避免calc内的值在编译时被计算
        margin-right: calc(~"(100vw - 350px) / 3");
        flex-shrink: 1;
        width: 80px;
        height: 25px;
        font-size: 14px;
        line-height: 25px;
        text-align: center;
        border-radius: 3px;
        background-color: #e5e3e3;
        &:nth-of-type(4n) {
          margin-right: 0;
        }
      }
      .classify-item-selected {
        color: @color;
        font-size: 14px;
        background: #e6f0fe url("../assets/active.png") no-repeat right
          bottom/auto 50%;
      }
    }
  }
  .tab2 {
    padding-bottom: 45px;
    .weui-cell {
      & /deep/ .vux-cell-primary {
        flex: 0 1 auto;
        color: #999;
      }
      & /deep/ .vux-label {
        color: #333;
      }
      & /deep/ .weui-cell__ft {
        margin-left: 0;
      }
      &.address {
        & /deep/ .weui-cell__ft.vux-cell-primary.vux-cell-align-left {
          flex: 1;
          margin-right: 13px;
          &::after {
            content: " ";
            display: inline-block;
            height: 18px;
            width: 14px;
            top: -2px;
            position: absolute;
            top: 50%;
            margin-top: -9px;
            right: 15px;
            background: url("../assets/address.png") no-repeat center
              center/contain;
          }
        }
      }
      &.vux-x-textarea {
        &::before {
          display: none;
        }
        padding: 0 15px 15px 15px;
      }
    }
  }
  .tab3 {
    padding-bottom: 45px;
  }
  .imgList {
    padding: 15px 0 0 15px;
    display: flex;
    flex-wrap: wrap;
    .img-item {
      position: relative;
      width: calc(~"(100vw - 75px) / 4");
      height: calc(~"(100vw - 75px) / 4");
      margin: 0 15px 15px 0;
      background: url("../assets/camera_icon.png") no-repeat center center/cover;
      &.upload {
        background-image: url("../assets/cameral.png");
        background-size: 25px;
        background-color: #fff;
      }
      .icon-remove {
        position: absolute;
        top: -5px;
        right: -5px;
        width: 20px;
        height: 20px;
        background: url("../assets/icon-remove.png") no-repeat center center/cover;
      }
    }
  }
  .btns {
    display: flex;
    justify-content: space-around;
    align-items: center;
    .btn {
      width: 165px;
      height: 45px;
      font-size: 16px;
      margin: 0;
      padding: 0;
      &::after {
        display: none;
      }
      &.btn1 {
        color: @color;
        background-color: #e6f0fe;
      }
      &.btn2 {
        color: #fff;
        background-color: @color;
      }
    }
  }
}
</style>
