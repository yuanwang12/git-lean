<template>
  <div class="page">
    <!-- 模块客户信息 -->
    <group title="客户信息" class="group" label-width="70px">
      <popup-radio title="客户类型" :options="options1" v-model="params.customertype2Id" placeholder="请选择"></popup-radio>
      <x-input title="客户名称" v-model="params.customername" @on-focus="changetop"></x-input>
      <x-input title="客户单位" v-model="params.sq21" @on-focus="changetop"></x-input>
      <x-input title="手机" mask="99999999999" v-model="params.mobile" :max="11" @on-focus="changetop"></x-input>
      <x-input title="地址" v-model="params.address" @on-focus="changetop"></x-input>
    </group>
    <box gap="15px 0">
      <x-button class="submit" @click.native="submit">提交</x-button>
    </box>
  </div>
</template>

<script>
import API from '@/utils/api.js'
import { post } from '@/utils/service.js'
import { Box, Cell, XTextarea, XInput, Group, PopupRadio, XButton, Flexbox, FlexboxItem } from 'vux'
import { addCustomClass, rules } from '@/model/addCustom.js'
import valid from '@/utils/valid.js'
export default {
  name: 'NewOrder',
  components: {
    Box,
    Cell,
    XTextarea,
    XInput,
    Group,
    PopupRadio,
    XButton,
    Flexbox,
    FlexboxItem
  },
  data () {
    return {
      params: Object.assign({}, addCustomClass),
      options1: [],
      show: false
    }
  },
  // 客户类型数据源
  mounted () {
    this.getCustomertype2()
  },
  methods: {
    getCustomertype2 (params = {brandId: 5}) {
      post(API['mobileCustomerDictionary/getCustomertype2'], params)
        .then(res => {
          // console.log(res)
          const { customertype2Obj } = res.content
          this.options1 = customertype2Obj.map(item => ({
            key: item.customertype2,
            value: item.customertype2description
          }))
        }).catch(err => console.log(err))
    },
    addCustomer () {
      post(API['mobileCustomerOperation/addCustomer'], {
        ...this.params,
        customertypeId: '5'
      }).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            window.localStorage.setItem('customerInfo', JSON.stringify({
              ...this.params,
              customerGuid: res.content
            }))
            this.$vux.loading.hide()
            this.$router.go(-2)
          }
        })
      }).catch(err => console.log(err))
    },
    changetop () {
      setTimeout(() => {
        document.getElementById('vux_view_box_body').scrollTop = 0
      }, 500)
    },
    submit () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定提交?',
          onConfirm: () => {
            this.addCustomer()
          }
        })
      }
    }
  }
}
</script>

<style scoped>
.group >>> .vux-cell-primary {
  flex: 0 1 auto;
}
.weui-cell:before {
  right: 15px;
}
.submit {
  background-color: #3783f6;
  color: #fff;
  border-radius: 0;
  height: 44px;
  line-height: 44px;
}

.submit:active {
  background: #9dbcff;
}
</style>



