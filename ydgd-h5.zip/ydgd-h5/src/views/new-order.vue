<template>
  <div class="page">
    <!-- 模块客户信息 -->
    <group title="客户信息" label-width="70px">
      <x-input title="客户名称" v-model="params.customername" disabled @click.native="customQuery"></x-input>
      <x-input title="客户单位" v-model="params.sq21" disabled></x-input>
      <x-input title="手机"  mask="99999999999" v-model="params.mobile"  disabled ></x-input>
      <x-input title="地址" v-model="params.address" disabled></x-input>
    </group>

    <!-- 模块基本信息 -->
    <group title="基本信息" label-width="70px" class="group">
      <x-input title="工单标题" v-model="params.title"></x-input>
      <popup-radio title="问题分类" :options="options1" v-model="params.inboundtype" placeholder="请选择"></popup-radio>
    </group>

    <!-- 模块问题描述 -->
    <group title="问题描述">
      <x-textarea :max="200" name="flowdetail" :show-counter="false" v-model="params.flowdetail"></x-textarea>
    </group>
    <group title="预处理信息">
      <x-textarea :max="200" name="method" :show-counter="false" v-model="params.method"></x-textarea>
    </group>

    <!-- 拍照 -->
    <div class="imgList">
      <div
        class="img-item"
        v-for="(url, index) of imgList"
        :key="url.id"
        :style="{'backgroundImage': `url(${url.url})`}">
        <div class="icon-remove" @click="removeImgItem(index)"></div>
      </div>
      <div class="img-item upload" @click="takePhoto" v-if="imgList.length<imgCount"></div>
    </div>

    <!-- 按钮 -->
    <box gap="15px 15px" style="margin-top: 0">
      <flexbox>
        <flexbox-item>
          <x-button class="save"  @click.native="submit">保存</x-button>
        </flexbox-item>
        <flexbox-item style="margin-left: 15px;">
          <x-button  class="delegate" @click.native="delegate">下送</x-button>
        </flexbox-item>
        <flexbox-item
          v-if="!($route.query.isRelationWorkorder === '1' || $route.query.isnewrelation === '1')"
          style="margin-left: 15px;">
          <x-button class="closeCase" @click.native="closeCase">结案</x-button>
        </flexbox-item>
      </flexbox>
    </box>
  </div>
</template>

<script>
import API from '@/utils/api.js'
// import obj2params from '@/utils/obj2params.js'
import { post } from '@/utils/service.js'
import getStaffInfo from '@/utils/getStaffInfo.js'
import { Cell, XTextarea, XInput, Group, Box, PopupRadio, XButton, Flexbox, FlexboxItem } from 'vux'
import { orderClass, rules } from '@/model/order.js'
import valid from '@/utils/valid.js'

const newOrderVm = {
  name: 'NewOrder',
  components: {
    Cell,
    XTextarea,
    XInput,
    Group,
    Box,
    PopupRadio,
    XButton,
    Flexbox,
    FlexboxItem
  },
  data () {
    return {
      staffInfo: getStaffInfo(),
      params: Object.assign({}, orderClass),
      options1: [],
      imgCount: 4,
      imgList: [],
      tabciflytek: {},
      objective: {}
      // imgList: [
      //   {id: 1, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3044191397,2911599132&fm=27&gp=0.jpg'},
      //   {id: 2, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=302701032,2300144492&fm=27&gp=0.jpg'},
      //   {id: 3, url: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3498018351,3670820427&fm=27&gp=0.jpg'},
      //   {id: 4, url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3536314877,3587590266&fm=27&gp=0.jpg'}
      // ]
    }
  },
  mounted () {
    window.newOrderVmAddAttachmentCallBack = this.addAttachmentCallBack
    console.log(this.$route.query.isRelationWorkorder !== '1')
    // 本地存储数据
    this.loadData()
    this.openWorkerOrder()
    // 问题分类
    this.queryData()
  },
  methods: {
    loadData () {
      const storage = window.localStorage
      let newOrderInfo = JSON.parse(storage.getItem('newOrderInfo'))
      let customerInfo = JSON.parse(storage.getItem('customerInfo'))
      let imgList = JSON.parse(storage.getItem('imgList'))
      storage.removeItem('imgList')
      storage.removeItem('newOrderInfo')
      storage.removeItem('customerInfo')
      this.params = {
        ...this.params,
        ...newOrderInfo,
        ...customerInfo
      }
      if (imgList) this.imgList = imgList
    },
    openWorkerOrder () {
      if (!this.$route.query.objectiveGuid) return
      post(API['workerOrderQuery/openWorkerOrder'], {
        objectiveGuid: this.$route.query.objectiveGuid,
        handlebyId: this.staffInfo.staffId
      }).then(res => {
        console.log(res)
        this.tabciflytek = res.content.tabciflytek
        this.objective = res.content.objective
        let { customername, sq21, mobile, address, customerGuid } = res.content.tabciflytek
        if (!customername) customername = ''
        if (!sq21) sq21 = ''
        if (!mobile) mobile = ''
        if (!address) address = ''
        this.params = {
          ...this.params,
          customername,
          sq21,
          mobile,
          address,
          customerGuid
        }
        if (this.$route.query.isRelationWorkorder !== '1') {
          let { title, inboundtype, flowdetail, method } = res.content.tabciflytek
          if (!title) title = ''
          if (!inboundtype) inboundtype = ''
          if (!flowdetail) flowdetail = ''
          if (!method) method = ''
          this.params = {
            ...this.params,
            title,
            inboundtype,
            flowdetail,
            method
          }
          const { filePathList: urls = [] } = res.content
          if (urls.length) {
            this.imgList = urls.map((item, index) => ({
              id: index,
              url: item.path
            }))
          }
        }
        // 清除url上的objectiveGuid 以便由客户查询页面返回是从localstorage里代入客户信息
        // const { objectiveGuid, ...others } = this.$route.query
        // window.history.replaceState(null, null, `/#/newOrder${obj2params(others)}`)
      }).catch(err => console.log(err))
    },
    // 问题分类
    queryData () {
      const res = [
        {
          key: '001',
          description: '售后'
        },
        {
          key: '002',
          description: '邮购'
        },
        {
          key: '003',
          description: '维修'
        },
        {
          key: '004',
          description: '建议'
        },
        {
          key: '005',
          description: '表扬'
        },
        {
          key: '006',
          description: '办理'
        },
        {
          key: '007',
          description: '咨询'
        },
        {
          key: '008',
          description: '投诉'
        }
      ]
      this.options1 = res.map(item => ({
        key: item.key,
        value: item.description
      }))
      // post('/newOrder/selectList', {})
      //   .then(res => {
      //     console.log(res)
      //     let arr = []
      //     for (let i = 0; i < res.content.list.length; i++) {
      //       arr.push(res.content.list[i].text)
      //     }
      //     this.options1 = arr
      //   }).catch(error => {
      //     console.log(error)
      //   })
    },
    // 客户查询
    customQuery () {
      if (this.$route.query.objectiveGuid) return
      window.localStorage.setItem('newOrderInfo', JSON.stringify(this.params))
      window.localStorage.setItem('imgList', JSON.stringify(this.imgList))
      this.$router.push('/customQuery')
    },
    // 拍照
    takePhoto () {
      console.log('进入拍照功能')
      let userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'))
      // null处理
      if (!userInfo) userInfo = {}
      let params = {
        'url': 'https://xfkfapi.iflytek.com/exchange-file-service/fileModify/uploadImage',
        'canUploadCount': this.imgCount - this.imgList.length,
        'sourceType': '',
        'createAccount': userInfo.userAccount,
        'token': userInfo.token,
        'createUser': userInfo.userName,
        'userAccount': userInfo.userAccount,
        'callBack': 'newOrderVmAddAttachmentCallBack'
      }
      console.log(params)
      // console.log(JSON.stringify(params))
      const isIOS = window.localStorage.getItem('isIOS')
      if (process.env.NODE_ENV === 'development') {
        const data = [
          {
            'result': true,
            'message': '上传图片成功',
            'content': {
              'id': 19447,
              'fileName': 'magazine-unlock-01-2.3.1071-_F7D7C25120DD5B866976886133B74550.jpg',
              'fileSize': '71511',
              'relationDataId': null,
              'relationType': null,
              'fileUploadName': 'group1/M00/0D/14/rB8AdVt1PQmAF12jAAEXV2y27vo604.jpg',
              'uploadUrl': 'http://qxbfile.iflytek.com:8000/group1/M00/0D/14/rB8AdVt1PQmAF12jAAEXV2y27vo604.jpg',
              'status': 101,
              'createTime': '2018-08-16 16:58:39',
              'createName': null,
              'createDomain': 'ymtang',
              'remark': null,
              'fileType': null,
              'relationSubtype': null,
              'ext1': null,
              'ext2': null,
              'uploadUrlNoToken': 'http://qxbfile.iflytek.com:8000/group1/M00/0D/14/rB8AdVt1PQmAF12jAAEXV2y27vo604.jpg',
              'relationDataIdList': null
            }
          },
          {
            'result': true,
            'message': '上传图片成功',
            'content': {
              'id': 19448,
              'fileName': 'magazine-unlock-01-2.3.1071-_D77553B06C132FEA53FCF12F3375A3CB.jpg',
              'fileSize': '91884',
              'relationDataId': null,
              'relationType': null,
              'fileUploadName': 'group1/M00/09/7F/rBBkIFt1PQmAB79xAAFm7Dnq6ig234.jpg',
              'uploadUrl': 'http://qxbfile.iflytek.com:8000/group1/M00/09/7F/rBBkIFt1PQmAB79xAAFm7Dnq6ig234.jpg',
              'status': 101,
              'createTime': '2018-08-16 16:58:39',
              'createName': null,
              'createDomain': 'ymtang',
              'remark': null,
              'fileType': null,
              'relationSubtype': null,
              'ext1': null,
              'ext2': null,
              'uploadUrlNoToken': 'http://qxbfile.iflytek.com:8000/group1/M00/09/7F/rBBkIFt1PQmAB79xAAFm7Dnq6ig234.jpg',
              'relationDataIdList': null
            }
          }
        ]
        this.addAttachmentCallBack(data)
      } else {
        /* eslint-disable no-undef */
        isIOS === 'true' ? takePhoto(params) : iflyapp.takePhoto(JSON.stringify(params))
      }
    },
    addAttachmentCallBack (data) {
      // window.alert(JSON.stringify(data))
      console.log(data)
      if (!data[0].result) {
        this.$vux.toast.show({
          type: 'warn',
          text: data[0].message
        })
        return
      }
      let urls = data.map(item => ({
        id: item.content.id,
        url: item.content.uploadUrl
      }))
      this.imgList = [
        ...this.imgList,
        ...urls
      ]
      // window.alert(JSON.stringify(this.imgList))
    },
    removeImgItem (i) {
      this.imgList = this.imgList.filter((url, index) => index !== i)
      console.log('移除')
    },
    // 保存
    submit () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定保存?',
          onConfirm: () => {
            this.insertWorkerOrder()
          }
        })
      }
    },
    insertWorkerOrder () {
      let { customerGuid, title, inboundtype, flowdetail, method } = this.params
      let params = {
        title,
        inboundtype,
        flowdetail,
        method
      }
      let api
      if (this.$route.query.operation === 'update') {
        api = 'workerOrderOperation/updateWorkerOrder'
        params.staffId = this.staffInfo.staffId
      } else {
        api = 'workerOrderOperation/insertWorkerOrder'
        params = {
          ...params,
          customerGuid,
          agentId: this.staffInfo.agentId,
          createdby: this.staffInfo.staffId
        }
      }
      this.handleWorkerOrder(params, api)
    },
    // 下送
    delegate () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定下送?',
          onConfirm: () => {
            console.log(this)
            this.sendWorkerOrder()
          }
        })
      }
    },
    sendWorkerOrder () {
      let { customerGuid, title, inboundtype, flowdetail, method } = this.params
      let params = {
        customerGuid,
        title,
        inboundtype,
        flowdetail,
        method,
        agentId: this.staffInfo.agentId,
        createdby: this.staffInfo.staffId,
        staffId: this.staffInfo.staffId
      }
      this.handleWorkerOrder(params, 'workerOrderOperation/sendWorkerOrder')
    },
    // 结案
    closeCase () {
      if (valid(this.params, rules)) {
        this.$vux.confirm.show({
          title: '提示',
          content: '确定结案?',
          onConfirm: () => {
            this.closeWorkerOrder()
          }
        })
      }
    },
    closeWorkerOrder () {
      let { customerGuid, title, inboundtype, flowdetail, method } = this.params
      let params = {
        customerGuid,
        title,
        inboundtype,
        flowdetail,
        method,
        agentId: this.staffInfo.agentId,
        createdby: this.staffInfo.staffId,
        staffId: this.staffInfo.staffId
      }
      this.handleWorkerOrder(params, 'workerOrderOperation/closeWorkerOrder')
    },
    handleWorkerOrder (params, api) {
      if (this.$route.query.isRelationWorkorder === '1') {
        params = {
          ...params,
          isRelationWorkorder: '1',
          objectiveRelationidOld: this.tabciflytek.objectiveRelationid,
          objectiveGuidOld: this.objective.objectiveGuid
        }
      } else if (this.$route.query.objectiveGuid) {
        params = {
          ...params,
          objectiveGuid: this.$route.query.objectiveGuid
        }
      }
      if (this.imgList.length) {
        params.filePath = this.imgList.map(item => item.url).join('*')
      } else {
        params.filePath = ''
      }
      post(API[api], params).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            this.$vux.loading.hide()
            let routeDepth = window.localStorage.getItem('routeDepth')
            if (Number(routeDepth)) {
              this.$router.go(-Number(routeDepth))
            } else {
              this.$router.back()
            }
          }
        })
      }).catch(err => console.log(err))
    }
  }
}

// window.newOrderVmAddAttachmentCallBack = function (data) {
//   window.alert(JSON.stringify(data))
//   window.alert(JSON.stringify(newOrderVm.methods))
//   window.alert(JSON.stringify(newOrderVm.methods.addAttachmentCallBack))
//   newOrderVm.methods.addAttachmentCallBack(data)
// }

export default newOrderVm
</script>

<style scoped>
@import url("../css/new-order/new-order.css");
.group >>> .vux-cell-primary {
  flex: 0 1 auto;
}
</style>



