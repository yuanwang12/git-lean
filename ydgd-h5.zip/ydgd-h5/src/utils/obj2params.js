export default (obj) => {
  const params = Object.keys(obj)
    .map(key => `${key}=${obj[key]}`)
    .join('&')
  if (params) {
    return '?' + params
  } else {
    return ''
  }
}
