export default () => {
  let staffInfo = JSON.parse(window.sessionStorage.getItem('staffInfo'))
  return staffInfo
}
