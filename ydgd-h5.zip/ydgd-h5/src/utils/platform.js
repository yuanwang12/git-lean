
const u = navigator.userAgent
const isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 // android终端
const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) // ios终端

let OS
if (isAndroid) OS = 'android'
if (isiOS) OS = 'ios'

const Platform = {
  OS
}

export { Platform }
