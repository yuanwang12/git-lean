import Vue from 'vue'
import { AjaxPlugin, LoadingPlugin, ToastPlugin } from 'vux'
// import CryptoJS from 'crypto-js'
import qs from 'qs'
// import store from '../store'
// import API from './api'

Vue.use(LoadingPlugin)
Vue.use(ToastPlugin)

const axios = AjaxPlugin.$http
const $vux = Vue.$vux

// CryptoJS.mode.ECB = (function () {
//   var ECB = CryptoJS.lib.BlockCipherMode.extend()
//   ECB.Encryptor = ECB.extend({
//     processBlock: function (words, offset) {
//       this._cipher.encryptBlock(words, offset)
//     }
//   })
//   ECB.Decryptor = ECB.extend({
//     processBlock: function (words, offset) {
//       this._cipher.decryptBlock(words, offset)
//     }
//   })
//   return ECB
// }())

export function post (url, params, notShowLoading) {
  if (!notShowLoading) {
    $vux.loading.show({
      text: 'Loading'
    })
  }
  // if (window.ifly) {
  //   return new Promise((resolve, reject) => {
  //     const userInfo = store.state.userInfo
  //     if (!params) {
  //       params = {}
  //     }
  //     // console.log(params)
  //     url = url.replace('api/', '')
  //     params = Object.assign(params, {
  //       token: userInfo.token,
  //       userId: userInfo.userAccount,
  //       userAccount: userInfo.userAccount,
  //       methodCode: API[url]
  //     })
  //     // 数据加密
  //     params = JSON.stringify(params)
  //     let dataKey = CryptoJS.enc.Utf8.parse(userInfo.securityKey)
  //     let dataSrcs = CryptoJS.enc.Utf8.parse(params)
  //     let encrypted = CryptoJS.AES.encrypt(dataSrcs, dataKey, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 })
  //     let securityData = { 'securityData': encrypted.toString() }
  //     securityData = JSON.stringify(securityData)
  //     // url = location.origin + '/freeride/' + url.replace('api/', '')
  //     // alert(JSON.stringify(params))
  //     axios.post('http://60.166.12.119:9080/TyTransService/tytranservice/transfer/transInterface', securityData)
  //     // axios.post('http://iflyapp.iflytek.com:580/TyTransService/tytranservice/transfer/transInterface', securityData)
  //       .then(response => {
  //         if (!notShowLoading) {
  //           $vux.loading.hide()
  //         }
  //         // debugger
  //         let securityData = response.data
  //         // 数据解密
  //         // let securityData = JSON.parse(res)
  //         securityData = securityData.securityData
  //         let decrypt = CryptoJS.AES.decrypt(securityData, dataKey, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 })
  //         decrypt = CryptoJS.enc.Utf8.stringify(decrypt).toString()
  //         // alert(params + ',,,' + decrypt)
  //         try {
  //           var jsonData = JSON.parse(decrypt)
  //           // console.log(jsonData)
  //           if ('flag' in jsonData && jsonData.flag === true) {
  //             resolve(jsonData)
  //           } else {
  //             console.log(params)
  //             // 判断token是否失效
  //             if (jsonData.msg === 'tokenFail') {
  //               if (window.isiOS) {
  //                 window.illegalTokenAction()
  //               } else {
  //                 window.iflyapp.illegalTokenAction()
  //               }
  //             }
  //             $vux.toast.show({
  //               type: 'warn',
  //               text: jsonData.message || jsonData.msg
  //             })
  //             reject(jsonData)
  //           }
  //         } catch (error) {
  //           // console.log(decrypt)
  //           // console.log(error)
  //         }
  //       })
  //       .catch((error) => {
  //         $vux.loading.hide()
  //         $vux.toast.show({
  //           type: 'warn',
  //           text: '网络请求异常，请重新尝试'
  //         })
  //         reject(error)
  //       })
  //   })
  // } else {
  return new Promise((resolve, reject) => {
    // const userInfo = store.state.userInfo
    let userInfo
    try {
      userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'))
    } catch (error) {
      reject(error)
    }
    if (!userInfo) {
      userInfo = {}
    }
    if (!params) {
      params = {}
    }
    params = {
      ...params,
      token: userInfo.token,
      userAccount: userInfo.userAccount
    }
    // params = Object.assign(params, {
    //   token: userInfo.token,
    //   userId: userInfo.userAccount,
    //   userAccount: userInfo.userAccount
    // })
    // url = process.env.NODE_ENV === 'development' ? '/api' + url : 'http://172.31.0.210/elite-mobileWokerOrder-service/' + url
    url = process.env.NODE_ENV === 'development' ? '/api' + url : 'https://xfkfapi.iflytek.com/elite-mobileWokerOrder-service/' + url
    // url = location.origin + '/freeride/' + url.replace('api/', '')
    // alert(JSON.stringify(params))
    axios.post(url, qs.stringify(params), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      },
      timeout: 10000
    }).then(response => {
      if (!notShowLoading) {
        $vux.loading.hide()
      }
      const res = response.data
      if (res.result) {
        resolve(res)
      } else {
        $vux.toast.show({
          type: 'warn',
          text: res.message
        })
        reject(res)
      }
    }).catch((error) => {
      const code = error.response.status
      let msg = ''

      if (code === 504) {
        msg = '请求超时'
      } else if (code === 404) {
        msg = '地址错误'
      } else if (code === 200) {
        msg = error.message
      } else {
        msg = code
      }
      $vux.loading.hide()
      $vux.toast.show({
        type: 'warn',
        text: msg
      })
      reject(error)
    })
  })
  // }
}
