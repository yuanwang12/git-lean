const majorevents = [
  {
    key: 'majorevent1',
    value: '重大事件'
  },
  {
    key: 'majorevent2',
    value: '政府'
  },
  {
    key: 'majorevent3',
    value: '紧急'
  },
  {
    key: 'majorevent4',
    value: '是否多次'
  },
  {
    key: 'majorevent5',
    value: '对外'
  },
  {
    key: 'majorevent6',
    value: '升级'
  },
  {
    key: 'majorevent7',
    value: '高额赔偿'
  },
  {
    key: 'majorevent8',
    value: '媒体'
  }
]

export { majorevents }
