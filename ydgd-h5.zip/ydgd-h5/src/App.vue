<template>
  <div id="app">
    <view-box ref="viewBox"
              body-padding-top="46px"
              body-padding-bottom="0">
      <x-header class="vux-1px-b"
                :title="title"
                :left-options="{backText: ''}">
        <!-- <x-icon v-if="path =='/'" slot="overwrite-left" type="ios-home" size="35" style="fill:#fff;position:relative;top:-8px;left:-3px;"></x-icon> -->
        <img src="./assets/icon_home.png"
             v-if="path =='/'"
             slot="overwrite-left"
             class="icon-home"
             alt=""
             srcset=""
             @click="backHome">
        <img src="./assets/creatConnect.png"
             v-if="routename =='OrderDetail'"
             slot="right"
             class="icon-home"
             @click="toNewConnectOrder"
             alt=""
             srcset="">
        <a slot="right"
           v-if="path =='/customQuery'"
           @click="addCustom">新增客户</a>
        <a @click="reminder"
           slot="right"
           v-if="routename ==='OrderFinished'">催单</a>
      </x-header>
      <transition>
        <router-view class="router-view"></router-view>
      </transition>
    </view-box>
  </div>
</template>

<script>
import { Platform } from '@/utils/platform.js'
import getStaffInfo from '@/utils/getStaffInfo.js'
import API from '@/utils/api.js'
import { post } from '@/utils/service.js'
import { ViewBox, XHeader } from 'vux'

const vm = {
  name: 'app',
  components: {
    ViewBox,
    XHeader
  },
  mounted () {
    window.transferTokenAndUserIDCallBack = this.transferTokenAndUserIDCallBack
    this.init()
  },
  watch: {
    $route (to, from) {
      if (
        // 列表到新建（关联）
        (to.name === 'NewOrder' && from.name === 'MyOrders') ||
        // 列表到详情
        (to.name === 'OrderDetail' && from.name === 'MyOrders') ||
        // 详情到详情
        (to.name === 'OrderDetail' && from.name === 'OrderDetail') ||
        // 详情到新建（关联）
        (to.name === 'NewOrder' && from.name === 'OrderDetail') ||
        // 详情到完成
        (to.name === 'OrderFinished' && from.name === 'OrderDetail') ||
        // 列表到完成
        (to.name === 'OrderFinished' && from.name === 'MyOrders') ||
        // 完成到完成
        (to.name === 'OrderFinished' && from.name === 'OrderFinished') ||
        // 完成到新建（关联）
        (to.name === 'NewOrder' && from.name === 'OrderFinished') ||
        // 完成到详情
        (to.name === 'OrderDetail' && from.name === 'OrderFinished')
      ) {
        let routeDepth = window.localStorage.getItem('routeDepth')
        if (routeDepth) {
          routeDepth = Number(routeDepth) + 1
        } else {
          // console.log('没有depoth')
          routeDepth = 1
        }
        window.localStorage.setItem('routeDepth', routeDepth)
      }
    }
  },
  computed: {
    title () {
      let title = this.$route.meta.title
      // if (['OrderDetail', 'OrderFinished'].includes(this.$route.name)) {
      //   title = '工单编号：' + this.$route.params.id
      // }
      return title
    },
    path () {
      return this.$route.path
    },
    routename () {
      return this.$route.name
    }
  },
  methods: {
    init () {
      // const isIOS = this.$route.query.isIOS === 'true' ? 'true' : 'false'
      const isIOS = Platform.OS === 'ios'
      window.localStorage.setItem('isIOS', isIOS)
      if (process.env.NODE_ENV === 'development') {
        // hyjiang3 技术组 gjliu 工单组 
        window.transferTokenAndUserIDCallBack('ymtang', 'token', 'userName', 'userOrgId', 'userCode')
      } else {
        /* eslint-disable no-undef */
        isIOS === true ? getTokenAndUserAccount() : iflyapp.getTokenAndUserAccount()
      }
    },
    transferTokenAndUserIDCallBack (userAccount, token, userName, userOrgId, userCode) {
      let userInfo = {
        'userAccount': userAccount,
        'token': token,
        'userName': userName,
        'userOrgId': userOrgId,
        'userCode': userCode
      }
      userInfo = JSON.stringify(userInfo)
      window.sessionStorage.setItem('userInfo', userInfo)
      this.getStaffList(userAccount)//请求离开公司内网找不到
    },
    getStaffList (loginname) {
      post(API['mobileStaffQuery/getStaffList'], { loginname })
        .then(res => {
          // console.log(res)
          // let res = {
          //   content: {
          //     list: [{
          //       'genderObj': {
          //         'gender': '1',
          //         'genderdescription': '男'
          //       },
          //       'staffId': '9IM3VF',
          //       'agentId': 'dongye2',
          //       'extension': null,
          //       'staffname': '叶东',
          //       'title': null,
          //       'reportto': null,
          //       'tel1': null,
          //       'tel2': null,
          //       'fax': null,
          //       'eMail': null,
          //       'mobile': null,
          //       'deptId': null,
          //       'defaultrolegroup': 'W0ZJAT',
          //       'workstatus': 'ONLINE',
          //       'address': null,
          //       'birthday': null,
          //       'gender': '1',
          //       'stringfield': null,
          //       'createdby': 'EDISON',
          //       'createddate': 1524886396000,
          //       'modifiedby': '100000',
          //       'modifieddate': 1532414923000,
          //       'password': null,
          //       'passwordmodifieddate': null,
          //       'issupervisor': 1,
          //       'loginname': 'dongye2',
          //       'domain': null,
          //       'webchatAlias': null,
          //       'webchatRole': 2,
          //       'departNo': null,
          //       'branchNo': null,
          //       'clerkNo': null,
          //       'deptClass': null,
          //       'clerkGrade': null,
          //       'duty': null,
          //       'idNo': null,
          //       'accStatus': null,
          //       'zipcode': null,
          //       'centerCode': null,
          //       'clerkNo2': null,
          //       'cityId': null,
          //       'issale': null,
          //       'ismanager': null,
          //       'age': null,
          //       'nationality': null,
          //       'nativeplace': null,
          //       'loginstatus': null,
          //       'wrongpwdcount': null,
          //       'headimg': null,
          //       'beareaId': null,
          //       'deptid': null,
          //       'weixinid': null,
          //       'gholiday': null,
          //       'employeddate': null,
          //       'citycode': null,
          //       'areaId': null,
          //       'provinceId': null,
          //       'rolegrouptype': null,
          //       'qq': null,
          //       'ewuId': null,
          //       'webchatDefaultStatus': null,
          //       'webchatMaxSessionAllowed': 0,
          //       'openid': null,
          //       'vcid': null,
          //       'webchatComment': null,
          //       'skillLevel': null,
          //       'pwdmodify': null,
          //       'stringfield1': null,
          //       'stringfield2': null,
          //       'webchatWelcomeMessage': null,
          //       'rolegroupId': 'SYSTEM',
          //       'rolegroupdescription': '系统组'
          //     }]
          //   }
          // }
          if (res.content.list.length === 0) {
            this.$vux.toast.show({
              type: 'cancel',
              text: '当前账号没有权限',
              time: 1000,
              onHide: () => {
                this.backHome()
              }
            })
          } else {
            const staffInfo = JSON.stringify(res.content.list[0])
            window.sessionStorage.setItem('staffInfo', staffInfo)
          }
        }).catch(err => console.log(err))
    },
    addCustom: function () {
      this.$router.push('/addCustom')
    },
    backHome: function () {
      window.location.href = 'http://60.166.12.119:6080/jump/jumptomain.html'
      console.log('返回首页')
    },
    toNewConnectOrder () {
      // let storage = window.localStorage
      // let returnData = stor age.getItem('new_order')
      // storage.setItem('my_order', returnData)
      this.$router.push({
        name: 'NewOrder',
        // name: 'NewConnectOrder',
        query: {
          objectiveGuid: this.$route.query.objectiveGuid,
          isRelationWorkorder: '1'
        }
      })
    },
    reminder () {
      this.$vux.confirm.show({
        title: '提示',
        content: '确定催单?',
        onConfirm: () => {
          console.log(this)
          this.urgeWorkerOrder()
        }
      })
    },
    urgeWorkerOrder () {
      post(API['workerOrderOperation/urgeWorkerOrder'], {
        objectiveGuid: this.$route.query.objectiveGuid,
        staffId: getStaffInfo().staffId
      }).then(res => {
        console.log(res)
        this.$vux.toast.show({
          type: 'success',
          text: res.message,
          time: 1000,
          onHide: () => {
            this.$vux.loading.hide()
            let routeDepth = window.localStorage.getItem('routeDepth')
            this.$router.go(-Number(routeDepth))
          }
        })
      }).catch(err => console.log(err))
    }
  }
}

// window.transferTokenAndUserIDCallBack = function (userAccount, token, userName, userOrgId, userCode) {
//   var userInfo = {
//     'userAccount': userAccount,
//     'token': token,
//     'userName': userName,
//     'userOrgId': userOrgId,
//     'userCode': userCode
//   }
//   userInfo = JSON.stringify(userInfo)
//   window.sessionStorage.setItem('userInfo', userInfo)
//   vm.methods.getStaffList(userAccount)
// }

export default vm
</script>

<style lang="less">
@import '~vux/src/styles/reset.less';
@import '~vux/src/styles/1px.less';
html,
body {
  overflow-x: hidden;
  width: 100%;
  height: 100%;
}
#app {
  height: 100%;
  background-color: #f5f5f5;
  font-family: PingFang-SC-Medium;
}

#vux_view_box_body > .vux-header .vux-header-left .left-arrow {
  left: 2px;
}

#vux_view_box_body > .vux-header {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 100;
  background-color: #fff;
  .vux-header-title {
    color: #333;
    font-size: 16px;
  }
  .vux-header-right a {
    font-size: 14px;
    color: #333;
  }
}

.page {
  position: relative;
  z-index: 10;
  height: 100%;
}
.icon-home {
  position: relative;
  top: -4px;
  left: -3px;
  width: 24px;
  height: 24px;
}
</style>
