$(function() {

    function change() {
        debugger    
        code = $("#code");  

        // 验证码组成库   
        var arrays = new Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');    

        // 重新初始化验证码  
        codes = ''; 
        // 随机获取一个数组的下标
        for (var i = 0; i < 4; i++) {      
            var r = parseInt(Math.random() * arrays.length);   
            codes += arrays[r];  
        }  
        // 验证码添加到input里  
        code.val(codes);  
    }  
    change();

    //单击验证
    code.click(change);

    $("#nextStep").click(function() { 
        debugger  
        var inputCode = $(".checkcode-input").val().toUpperCase(); //取得输入的验证码并转化为大写 
           
        console.log(inputCode);
        if (inputCode.length == 0) { //若输入的验证码长度为0
               
            alert("请输入验证码！"); //则弹出请输入验证码
        } else if (inputCode != codes.toUpperCase()) { //若输入的验证码与产生的验证码不一致时
               
            alert("验证码输入错误!请重新输入"); //则弹出验证码输入错误
               
            change(); //刷新验证码
               
            $("#checkcode-input").val(''); //清空文本框
        }
    })
});

// 校验
var check = function() {
    // 获取当前输入值
    var str = $('.email-input').val();
    // 验证邮箱正则
    var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$");
    // 验证手机号正则
    var regtel = new RegExp("^((13[0-9])|(15[^4,\\D])|(14[57])|(17[0-9])|(18[0,0-9]))\\d{8}$");

    // 验证 
    if (!reg.test(str) || !(regtel.test(str)) || str.length == 0 || !str) {
        if (str.length == 0 || !str) {
            alert('请填写邮箱或手机号!');
            return false;
        }
        if (!(reg.test(str) || (regtel.test(str)))) {
            alert('手机或邮箱不合法!');
            return false;
        }
    }
    return true;
}

// 取消
var back = function() {
    window.history.go(-1);
}

// 下一步
var nextStep = function() {
    if (check()) {
        // 跳转
        window.location.href = "./second.html";
    }
}