$(function() {

});

// 取消
var back = function() {
    window.history.go(-1);
}

// 下一步
var nextStep = function() {
    window.location.href = "./third.html";
}