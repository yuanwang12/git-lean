$(function() {

});


// 下一步
var nextStep = function() {
    window.location.href = "";
}

// 立即登录

var login = function() {

}