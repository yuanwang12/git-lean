<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
import TodoList from './components/todolist'
export default {
  components: {
    'to-do-list': TodoList
  },
  name: 'App',
  data () {
    return {}
  },
  // 页面加载完执行的生命周期函数（钩子函数）
  mounted () {
    this.$nextTick(function () {
      console.log('页面加载完成')
    })
  },
  methods: {
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  background-color: rgb(238, 234, 234);
}
</style>
