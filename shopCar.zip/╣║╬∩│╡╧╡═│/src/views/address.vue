<template>
  <div id="main">
    <div class="title-wrapp">
      <span class="line"></span>
      <span class="msg">{{msg}}</span>
      <span class="line"></span>
    </div>
    <div class="addreList-wrapp">
      <div class="listCpas"
           v-for="(item, index) in listItem"
           :key="index"
           :class="{check: selectedId === index}"
           @click="selectedId = index;">
        <span>{{item.username}}</span>
        <span>{{item.address}}</span>
        <span>{{item.tel}}</span>
        <span class="setDef"
              @click="setDefault(item)"
              v-if="isDefault">{{issetdefault}}</span>
      </div>
    </div>
    <div class="load-more">more
      <i class="loadIcon"></i>
    </div>
    <button class="btn-primary"
            @click="back">返回上一步</button>
  </div>
</template>

<script>
export default ({
  data () {
    return {
      msg: '配送地址',
      selectedId: '',
      limti: 3,
      issetdefault: '设为默认',
      list: [
        {
          username: '张三',
          address: '安徽省芜湖市弋江区',
          tel: '15755329580',
          isDefault: false
        }, {
          username: '李四',
          address: '安徽省芜湖市弋江区',
          tel: '15755329580',
          isDefault: false
        }, {
          username: '王五',
          address: '安徽省芜湖市弋江区',
          tel: '15755329580',
          isDefault: false
        }, {
          username: '赵六',
          address: '安徽省芜湖市弋江区',
          tel: '15755329580',
          isDefault: false
        }
      ]
    }
  },
  methods: {
    back () {
      this.$router.back()
    },
    setDefault (item) {
      let _this = this
      this.list.forEach(function (item, index) {
        if (_this.selectedId === _this.index) {
          _this.isDefault = true
        } else {
          _this.isDefault = false
        }
      })
    }
  },
  computed: {
    listItem () {
      if (this.list.length > 3) {
        return this.list.slice(0, this.limti)
      }
    },
    isDefault () {
      if (this.selectedId === this.index) { }
      return true
    }
  }
})
</script>

<style scoped>
* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
.btn-primary {
  padding: 5px 20px;
  border: 0;
  box-sizing: border-box;
  border-radius: 2px;
  color: #fff;
  background-color: #6c8be0;
}
.btn-primary:active {
  background-color: #2b5ad9;
}
.title-wrapp {
  width: 100%;
}
.line {
  display: inline-block;
  height: 1px;
  width: 44%;
  background-color: #2b5ad9;
}
.msg {
  display: inline-block;
  width: 10%;
}
.addreList-wrapp {
  display: flex;
  justify-content: flex-start;
  padding: 50px 80px 0 80px;
  width: 100%;
}
.listCpas {
  margin: 15px 10px;
  padding-top: 10px;
  width: 200px;
  height: 150px;
  border: 1px solid #ffffff;
  box-sizing: border-box;
}
.check {
  border: 2px solid #ffb885;
}
.listCpas span {
  display: block;
  margin: 10px 0;
  max-width: 200px;
  height: 20px;
  line-height: 20px;
  cursor: pointer;
}
.setDef {
  color: #fdb388;
  font-size: 10px;
}
.load-more {
  margin: 0 0 50px 0;
  color: #ffb885;
}
.loadIcon {
  /* background: url(../assets/loadmore.png) no-repeat center center; */
}
.no-load {
  /* background: url(../assets/loadmore.png) no-repeat center center; */
}
</style>
