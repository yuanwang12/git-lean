<template>
  <div id="main">
    <h4 class="productTitle">购物车系统</h4>
    <input type="text"
           class="input"
           placeholder="请输入商品名称"
           @keyup.enter="search"
           v-model="inputValue">
    <button class="btn-primary"
            @click="search">搜索</button>
    <ul>
      <to-do-list v-for="(item,index) in items"
                  :key="index"
                  :index="index"
                  :content="item"
                  @delete-item="deleteItem"></to-do-list>
    </ul>
    <div class="list-wrapp">
      <tbody>
        <tr>
          <td style="width:150px;">
            <span class="checkbox"
                  :class="{selectAll: ischecked}"
                  @click="checkAllFlag"></span>
          </td>
          <td>商品信息</td>
          <td>商品数量</td>
          <td>价格</td>
          <td>总价</td>
          <td>操作</td>
        </tr>
        <tr v-if="nodata"
            class="nodata">
          <td></td>
          <td></td>{{nodata}}
          <td></td>
          <td></td>
        </tr>
        <tr v-for="(value, index) of list"
            :key="index">
          <td>
            <span class="checkbox"
                  :class="{selectIcon: value.isselected}"
                  @click="isSelected(value)"></span>
          </td>
          <td>{{value.productName}}</td>
          <td class="productNum">
            <span @click="deleteNum(value)">-</span><input class="input-num"
                   type="text"
                   v-model="value.productNum">
            <span @click="addNum(value)">+</span>
          </td>
          <td>￥{{value.price | formtmoney}}/kg</td>
          <td>￥{{value.price*value.productNum | formtmoney}}</td>
          <td>
            <i class="deletebtn"
               @click="deletetd(value)"></i>
          </td>
        </tr>
        <tr>
          <div style="float: right">
            <span>总金额：{{totalMoney | formtmoney}}</span>
            <button class="btn-primary"
                    @click="toAddress">结账</button>
          </div>
        </tr>
      </tbody>
    </div>
  </div>
</template>

<script>
import TodoList from '../components/todolist'
export default {
  components: {
    'to-do-list': TodoList
  },
  name: 'index',
  data () {
    return {
      items: [],
      inputValue: '',
      ischecked: false,
      isselected: false,
      totalMoney: 0,
      resFlag: '',
      listrows: [
        {

          productName: '西瓜',
          productNum: 2,
          price: 12
        }, {
          productName: '苹果',
          productNum: 1,
          price: 12
        }, {
          productName: '橘子',
          productNum: 1,
          price: 12
        }, {
          productName: '芒果',
          productNum: 5,
          price: 26
        }, {
          productName: '榴莲',
          productNum: 3,
          price: 68.5
        }],
      rows: []
    }
  },
  // 页面加载完执行的生命周期函数（钩子函数）
  mounted () {
    this.$nextTick(function () {
      console.log('页面加载完成')
    })
  },
  methods: {
    // 计算商品总金额
    calcTotalMoney () {
      let _this = this
      this.ischecked = this.isCheckAll()
      this.totalMoney = 0
      this.listrows.forEach((item, index) => {
        if (item.isselected) {
          _this.totalMoney += item.productNum * item.price
        }
      })
    },

    // 全选事件
    checkAllFlag () {
      this.ischecked = !this.ischecked
      this.listrows.forEach((value, index) => {
        if (this.ischecked === true) {
          value.isselected = true
        } else {
          value.isselected = false
        }
      })
      this.calcTotalMoney()
    },

    // 是否全选事件
    isCheckAll () {
      let _this = this
      let resflag = true
      _this.listrows.forEach(function (value, index) {
        if (!value.isselected) {
          resflag = false
          return false
        }
      })
      return resflag
    },

    // 复选事件
    isSelected (value) {
      if (typeof value.isselected === 'undefined') {
        this.$set(value, 'isselected', true)
      } else {
        value.isselected = !value.isselected
      }
      this.calcTotalMoney()
    },
    // 搜索
    search () {
      this.rows = []
      if (this.inputValue !== '') {
        this.listrows.forEach((value, index) => {
          if (value.productName === this.inputValue) {
            this.rows.push(this.listrows[index])
          }
        })
      }
    },
    addNum (value) {
      value.productNum++
      this.calcTotalMoney()
    },
    deleteNum (value) {
      if (value.productNum > 0) {
        value.productNum--
        this.calcTotalMoney()
      }
    },
    // 删除单行数据
    deletetd (value) {
      console.log('删除')
      let item = value
      let index = this.listrows.indexOf(item)
      this.listrows.splice(index, 1)
    },
    // 跳转到地址列表
    toAddress () {
      console.log('跳转到地址列表')
      this.$router.push({
        path: '/address'
      })
    }
  },

  // 计算属性
  computed: {
    list () {
      if (this.rows.length === 0) {
        return this.listrows
      } else {
        return this.rows
      }
    },
    nodata () {
      if (this.listrows.length === 0) {
        return '暂无数据'
      }
    }
  },

  // 监控对象
  watch: {

  },
  filters: {
    formtmoney (value) {
      return value.toFixed(2)
    }
  }
}
</script>

<style scoped>
tbody {
  display: table;
  width: 100%;
}
.input {
  height: 21px;
}
.productTitle {
  color: #000;
}
.btn-primary {
  padding: 5px 20px;
  border: 0;
  box-sizing: border-box;
  border-radius: 2px;
  color: #fff;
  background-color: #6c8be0;
}
.btn-primary:active {
  background-color: #2b5ad9;
}

tr {
  text-align: center;
}

.list-wrapp {
  width: 100%;
  text-align: center;
}
.checkbox {
  display: inline-block;
  height: 16px;
  width: 16px;
  border-radius: 4px;
  border: 1px rgb(0, 0, 0) solid;
}
.selectAll {
  background: url(../assets/selectAll.png) no-repeat center center;
}
.selectIcon {
  background: url(../assets/selectIcon.png) no-repeat center center;
}
.productNum span {
  display: inline-block;
  width: 20px;
  height: 20px;
  cursor: pointer;
}
.input-num {
  text-align: center;
  width: 50px;
}
.deletebtn {
  display: inline-block;
  height: 20px;
  width: 20px;
  cursor: pointer;
  background: url(../assets/deleteIcon.png) no-repeat center center;
}
.nodata {
  color: rgb(226, 107, 107);
}
</style>
