<template>
  <div class="hello">
    <li @click="deleteItem">{{content}}</li>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },
  props: ['content', 'index'],
  methods: {
    deleteItem () {
      this.$emit('delete-item', this.index)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
