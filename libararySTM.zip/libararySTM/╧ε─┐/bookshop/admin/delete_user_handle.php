﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}

?>
<?php   
        
              require("conn.php");
              $id=$_GET['id'];
			   echo $id;
			  $delete="delete from user where id='$id'";
              $link=mysqli_connect("localhost","root","","bookshop");
			  $result=mysqli_query($link,$delete);
			 
			 
			  if($rows=mysqli_affected_rows($link)>0){
			      echo "<script  type='text/javascript'>alert('删除成功！');location.href='delete_user.php';</script>";
			  }
			  else
			       echo "<script  type='text/javascript'>alert('删除失败！');location.href='delete_user.php';</script>";
				  
			  
              
 
 
 




?>

