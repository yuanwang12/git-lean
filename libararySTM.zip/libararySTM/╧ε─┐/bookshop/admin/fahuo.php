﻿<html>
  <head></head>
  <body>
        <table cols=5 border=1 cellspacing=0 cellpadding=0 width="655px">
                   <tr>
				      <td colspan=5><b>待发货</td>
				   </tr>
				   <tr>
				      <th>书名</th>
					  <th>数量</th>
					  <th>住址</th>
					  <th>电话</th>
					  <th>发货</th>
				   </tr>
				   <?php
				       require("conn.php");
					   $sql="select * from  book where pay='1'";
					   $link=mysqli_connect("localhost","root","","bookshop");
					   $query=mysqli_query($link,$sql);
					
					  
				        while($result=mysqli_fetch_array($query))
						{
				   ?>
				    <tr>
					   <td align="center"><?php   echo $result['book_name'];?></td>
					   <td align="center"><?php    echo $result['buy_num'];?></td>
					   <td align="center"><?php  echo  $result['address'];?></td>
					   <td align="center">
					     <?php   echo  $result['telephone'];?>
					   </td>
					   <td align="center"><input type="button" name="submit" onclick="return confirm('确认发货么？')" value="发货" style="width:45px;height:35px"></td>
					</tr>
					<?php
					}
					?>
        </table>
  </body>
</html>