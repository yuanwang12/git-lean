﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}


?>
<?php
       if(isset($_POST['submit']) && $_POST['submit']=="添加" ){
	              require("conn.php");
				  $book_name=$_POST['book_name'];
				  $book_num=$_POST['book_num'];
				  $book_price=$_POST['book_price'];
				  $author=$_POST['author'];
				  $type=$_POST['type'];
				  $detail=$_POST['detail'];
				  echo $book_name;
				  echo "+";
				      echo  $book_num ;
					    echo "+";
					 echo   $book_price;
					   echo "+";
					 echo   $author;
					   echo "+";
					 echo   $type;
					   echo "+";
					 echo   $detail;
				  
				  $sql="insert  into book (book_name,book_num,book_price,author,type,detail) values('$book_name','$book_num','$book_price','$author','$type','$detail') ";
		   	  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				  $rows=mysqli_affected_rows($link);
				  if($rows>0){
				      echo  "<script type='text/javascript'>alert('添加成功！');location.href='add_book.php';</script>";
				  }
				  else{
				     echo  "<script type='text/javascript'>alert('添加失败！');location.href='add_book.php';</script>";
				  }
	   
	   }



?>