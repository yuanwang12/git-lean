﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}

?>
<?php   
          if(isset($_POST['submit'])&& $_POST['submit']=="修改"){
         
		   require("conn.php");
		   $id=$_POST['id'];
		   $type=$_POST['type'];
		   $book_name=$_POST['book_name'];
		   $book_num=$_POST['book_num'];
		   $book_price=$_POST['book_price'];
		 
		   $sql="update book set book_name='$book_name',type='$type',book_num='$book_num',book_price='$book_price' where id='$id'";
		   $link=mysqli_connect("localhost","root","","bookshop");
		   $query=mysqli_query($link,$sql);
		   if(mysqli_affected_rows($link)>0)
          { 
		    echo
			"<script type='text/javascript'>alert('更新成功！');location.href='update_list.php';</script>";
   		  }
		else
			  echo  "<script type='text/javascript'>alert('更新失败！');location.href='update_list.php';</script>";
			  }
?>