﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}

?>
<?php
      
	         require("conn.php");
	         $id=$_GET['id'];
			 $sql="select * from book where id='$id'";
			 $link=mysqli_connect("localhost","root","","bookshop");
			 $query=mysqli_query($link,$sql);
			 $result=mysqli_fetch_array($query);
			
	  
	
 ?>
 <html>
 <head>
 </head>
 <style>
.body{
    margin-left:250px;
	margin-top:100px;
}
</style>
<div class="body">
 <body>
        <form action="update_book_ok.php" method="post">
       <table cellspacing=0 cellpadding=0 border=1 width="525px" height="355">
		    <tr>
			 <td colspan=4 align="center"><b>更新书籍</td>
			</tr>
			<tr>
			  <td align="center">书名</td>
			  <td><input type="text" name="book_name" value="<?php echo $result['book_name'];  ?>"
			   style="width:185px;height:25px"></td>
			</tr>
			<tr>
			  <td align="center">库存</td>
			  <td>
			  <input type="text" name="book_num" value="<?php echo $result['book_num'];?>"
			   style="width:185px;height:25px"> </td>
			</tr>
			<tr>
			  <td align="center">单价</td>
			  <td><input type="text" name="book_price" value="<?php echo $result['book_price'];  ?>"
			   style="width:185px;height:25px"> </td>
			</tr>
			<tr>
			  <td align="center">类型</td>
			  <td><input type="text" name="type" value="<?php echo $result['type'];?>"
			   style="width:185px;height:25px"><input type="hidden" name="id" value="<?php echo $result['id']; ?>>"></td>
			</tr>
				
			<tr align="center">
			
			 <td align="center" width="150px" colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" style="width:45px;height:25px" value="修改"></td>
			 
			</tr>
			
			
		 </table>
    </form>
 
 </body>
 
 <div>
 
 
 </html>