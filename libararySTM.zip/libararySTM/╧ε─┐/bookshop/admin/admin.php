﻿<?php   session_start();
header('Content-Type: text/html; charset=utf-8');



 ?>


<html>
<head>
   <title>学海书店系统管理后台</title>
</head>
<frameset cols="15%,*">
       <frame  src="list.php" ></frame>
	   <frame  src="personal.php"  name="right"></frame>


</frameset>
</html>