﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}

?>

<html>
<head>
<style>
    .table1{
	   margin-left:255px;
	   margin-top:80px;
	}
</style>

</head>

<body>
    <div  class="table1">
	<form action="add_book_handle.php" method="post">
         <table cellspacing=0 cellpadding=0 border=1 width="505px" height="355">
		    <tr>
			 <td colspan=2 align="center"><b>添加图书</td>
			</tr>
			<tr>
			 <td align="center" width="89px"><b>书名</td>
			 <td><input type="text" name="book_name" style="width:155px;height:25px"></td>
			</tr>
			<tr>
			 <td align="center"width="89px"><b>作者</td>
			 <td><input type="text" name="author" style="width:155px;height:25px"></td>
			</tr>
			<tr>
			 <td align="center"width="89px"><b>数量</td>
			 <td><input type="text" name="book_num" style="width:155px;height:25px"></td>
			</tr>
			<tr>
			 <td align="center"width="89px"><b>单价</td>
			 <td><input type="text" name="book_price" style="width:155px;height:25px"></td>
			</tr>
			<tr>
			 <td align="center"width="89px"><b>类型</td>
			 <td>
			     <select style="width:95px;height:25px" name="type">
				    <option>武侠</option>
					<option>言情</option>
					<option>玄幻</option>
					<option>名著</option>
					<option>历史</option>
				 </select>
			 </td>
			</tr>
			<tr>
			 <td align="center"width="89px"><b>详情</td>
			 <td><textarea  name="detail" cols=45 rows=10 ></textarea></td>
			</tr>
			<tr>
			 <td align="center" colspan=2><input type="submit" name="submit" style="width:35px;height:25px" value="添加"></td>
			</tr>
			
		 </table>
		 </form>
 </div>
</body>
</html>