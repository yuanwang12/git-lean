﻿
<?php
   session_start();
   if(isset($_GET['submit']) && $_GET['submit']=="修改"){
       $username=$_POST['username'];
		 $password=$_POST['password'];
		 $id=$_COOKIE['id'];
		 require("conn.php");
		
		 $sql="update admin set username='$username',password='$password' where id='$id'";
       $link=mysqli_connect("localhost","root","","bookshop");
		 $query=mysqli_query($link,$sql);

		 if($rows=mysqli_affected_rows($link)>0)
		    echo  
 			"<script type='text/javascript'>alert('修改成功！');location.href='personal.php';</script>";
        else
		    "<script type='text/javascript'>alert('修改失败！');location.href='personal.php';</script>";
   }


?>