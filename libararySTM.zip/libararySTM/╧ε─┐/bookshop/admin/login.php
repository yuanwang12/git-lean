﻿
<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<TITLE>学海书店管理员登录页面</TITLE> 
<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../Css/common.css">
</head>
 
<STYLE>
  /* .body{
   margin-left:340px;
	 margin-top:200px;
  } */
</STYLE>
     
<script type="text/javascript">
         function inputcheck(){
		   if(form.username.value=="")
		     { 
			    form.username.focus();
				alert("用户名不能为空！");
				return false;
			    }
		   if(form.password.value=="")
		     {
		        form.password.focus();
                alert("密码不能为空！");
                return false;	
		   }
		   
		 
		 }
</script>
<div class="body">
<body >

<form class="form-horizontal perInfor" role="form" name="form" onsubmit="return inputcheck();" action="login_handle.php" method="post">
   <div class="input-box">
		<div class="form-group">
				<label for="firstname" class="col-sm-3 control-label">用户名：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="firstname" 
							placeholder="请输入用户名" id="username" type="text" name="username" value="">
				</div>
		</div>
		<div class="form-group">
				<label for="lastname" class="col-sm-3 control-label">密码：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="lastname" 
							placeholder="请输入密码" id="password" type="password" name="password" value="">
				</div>
		</div>
		<div class="form-group">
				<div class="col-sm-offset-2 col-sm-12 undate-box">
					<input type="button" class="btn btn-default goBack" onclick="location.href='../index/index.php'" value="返回" />
					<input type="submit" class="btn btn-primary updateInfo" name="submit" value="登录">
				</div>
		</div>
	 </div>
	 </form>
</body>
</div></html>
