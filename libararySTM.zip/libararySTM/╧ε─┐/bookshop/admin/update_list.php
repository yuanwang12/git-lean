﻿<?php
     if(!isset($_COOKIE['username'])){
	echo'<script type="text/javascript"> alert("非法登录!");location.href="login.php"; </script>';	
	exit;
}

?>

<html>
<head>
<style>
    .table1{
	   margin-left:255px;
	   margin-top:80px;
	}
</style>

</head>

<body>
    <div  class="table1">
	<form action="add_book_handle.php" method="post">
         <table cellspacing=0 cellpadding=0 border=1 width="525px" height="355">
		    <tr>
			 <td colspan=4 align="center"><b>更新书籍</td>
			</tr>
			<th >书名</th>
			<th>单价</th>
			<th>数量</th>
			<th>更新</th>
			<?php
			   require("conn.php");
			   $sql="select * from book ";
			   $link=mysqli_connect("localhost","root","","bookshop");
			   $query=mysqli_query($link,$sql);
			  
			   while( $result=mysqli_fetch_array($query))
			   {
			 ?>			
			
			<tr>
			 <td align="center" width="150px"><?php  echo $result['book_name'];?></td>
			 <td align="center" width="150px"><?php  echo $result['book_price'];?></td>
			 <td align="center" width="150px"><?php  echo $result['book_num'];?></td>
		
			 <td align="center" width="150px"><a href="delete_book.php?id=<?php echo $result['id']; ?>" >删除</a>|<a href="update_book.php?id=<?php  echo $result['id']; ?>">编辑</a></td>
			 
			</tr>
			
			<?php
			   }
			?>
		 </table>
		 </form>
 </div>
</body>
</html>