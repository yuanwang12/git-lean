﻿<html>
  <head></head>
  <style>
      .table1{
	   margin-left:200px;
	   margin-top:120px;
	  
	  }
  </style>
  <body>
  <div class="table1">
   
    <table border=1 width="455px" height="255" cols=2>
	   <tr>
	     <td colspan=5 align="center" height="25px"><b>用户信息</td>
	   </tr>
	    <th height="25px">序号</th>
		<th>用户名</th>
	    <th>电话</th>
	    <th>地址</th>
		<th>删除</th>
		<?php
		   require("conn.php");
		   $sql="select * from user ";
       $link=mysqli_connect("localhost","root","","bookshop");
		   $query=mysqli_query($link,$sql);
		   
		   while($result=mysqli_fetch_array($query))
		   {
		?>
		<tr>
		  <td height="25px"><?php echo $result['id']; ?></td>
		  <td><?php echo $result['username']; ?></td>
		  <td><?php echo $result['telephone']; ?></td>
		  <td><?php echo $result['address']; ?></td>
		  <td><a href="delete_user_handle.php?id=<?php  echo $result['id']  ;?>">删除 </a>  </td>
		</tr>
		<?php
		  }
		?>
	</table>

  </div>
  
  </body>

</html>