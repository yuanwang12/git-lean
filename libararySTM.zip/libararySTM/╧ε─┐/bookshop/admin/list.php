﻿
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="Css/1024_768.css">
<link rel="stylesheet" type="text/css" href="Css/pad.css">
<link rel="stylesheet" type="text/css" href="Css/pad_heng.css">
<link rel="stylesheet" type="text/css" href="Css/reset.css">
<link rel="stylesheet" type="text/css" href="Css/tel.css">
<link rel="stylesheet" type="text/css" href="Css/tel_heng.css">
<link rel="stylesheet" href="../Css/common.css">
<style>
	.siderBar{
		/* border: 1px solid #ff5000; */
    /* border-top: none; */
    padding-bottom: 3px;
		background: #fff;
    margin: 0 0 20px 0;
    padding: 4px;
    -moz-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1)
	}
	.siderTop{
    width: 100%;
    text-align: center;
    font-size: 21px;
    /* background: #ff5000; */
		background-color: #f2f2f2;
	}
	table{
		width:100%;
	}
	td{
		height:32px;
		line-height: 32px;
    background-color: #f6f4f0;
    text-decoration: none;
    display: block;
    padding: 4px;
    border-bottom: 1px solid #efefef;
    color: #000;
		text-align:center;
	}
	a{
    display: inline-block;
		width: 100%;
    text-decoration: none;
		color: #000;
		text-decoration: none;
	}
	td a:hover{
		color: #fff;
		background-color: #00a4ff;
	}
</style>
</head>
<div class="siderTop">菜单栏</div>
<body class="siderBar" align="center" background="">
<table rows=9 cols=1  align="center" class="table">
    <tr>
	  <td height="35px"><a href="personal.php" target="right">个人信息</a></td>
	</tr>
	<!-- <tr>
	   <td>用户管理</td>
	</tr> -->
	
	
    <tr><td align="center" height="25px"><a href="delete_user.php" target="right">删减用户</a></td>
	</tr>
	<!-- <tr>
	  <td height="35px" align="center">图书管理</td>
	 <tr> -->
	  <td align="center"><a href="add_book.php" target="right">添加图书</a></td>
	  </tr>
	  <tr>
	  <td align="center"><a href="update_list.php" target="right">更新书籍</a></td>
	  
	  </tr>
	<tr>
	  <td height="35px" align="center"><a href="fahuo.php"  target="right">待发货</a></td>
	</tr>
	<tr>
	  <td height="35px" align="center"><a href="logout.php?action=logout"  target="_top">安全退出</a></td>
	</tr>
	



</table>
</body>

</html>