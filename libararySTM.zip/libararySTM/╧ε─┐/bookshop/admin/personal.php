﻿

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../Css/common.css">
<style>

</style>
<!-- <meta http-equiv="refresh" content="10"> -->
</head>

<body>
<div class="table1">
<!-- 新样式 -->
<form class="form-horizontal perInfor" role="form" action="personal_update.php" method="get">
   <div class="input-box">
		<div class="form-group">
				<label for="firstname" class="col-sm-3 control-label">用户名：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="firstname" 
								placeholder="请输入名字" value="<?php 
								require("conn.php");
								$id=$_COOKIE['id'];
								$sql="select username from admin  where id='$id'";
								$link=mysqli_connect("localhost","root","","bookshop");
								$query=mysqli_query($link,$sql);
								$result=mysqli_fetch_array($query);
								echo $result['username'];?>">
				</div>
		</div>
		<div class="form-group">
				<label for="lastname" class="col-sm-3 control-label">密码：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="lastname" 
							placeholder="请输入姓" value="<?php  
							require("conn.php");
								$id=$_COOKIE['id'];
								$sql="select password from admin  where id='$id'";
								$link=mysqli_connect("localhost","root","","bookshop");
								$query=mysqli_query($link,$sql);
								$result=mysqli_fetch_array($query);
								$password=$result['password'];
								echo $password;?>">
				</div>
		</div>
		<div class="form-group">
				<div class="col-sm-offset-2 col-sm-12 undate-box">
					<!-- <button type="submit" class="btn btn-default">登录</button> -->
					<input type="submit" class="btn btn-primary updateInfo" name="submit" value="修改">
				</div>
		</div>
	 </div>
	 </form>
</div>


</body>

</html>
