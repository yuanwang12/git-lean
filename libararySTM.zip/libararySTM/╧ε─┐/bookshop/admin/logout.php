<?php
   
   if($_GET['action'] == "logout"){
    unset($_COOKIE['id']);
    unset($_COOKIE['username']);
    unset($_COOKIE['password']);
    echo "<script type='text/javascript'>alert('退出成功!');location.href='../index/index.php';</script>";
    exit;
}
?>