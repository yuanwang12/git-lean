﻿

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="Css/reset.css" />
    <link type="text/css" rel="stylesheet" href="Css/1024_768.css" />
    <link rel="stylesheet" href="../Css/common.css">
    <link type="text/css" rel="stylesheet" media="screen and (min-width:861px) and (max-width:960px)" href="Css/pad_heng.css" />
    <link type="text/css" rel="stylesheet" media="screen and (min-width:601px) and (max-width:860px)" href="Css/pad.css" />
    <link type="text/css" rel="stylesheet" media="screen and (
    min-width:481px) and (max-width:600px)" href="Css/tel_heng.css" />
    <link type="text/css" rel="stylesheet" media="screen and (max-width:480px)" href="Css/tel.css" />
</head>
<body>
    
<div class="w_100_l">
        <div class="main">
            <div class="advWrapp">
                <div class="advWrappText">
                    <广告位>
                </div>
            </div>
            <nav class="nav"></nav>
            <div class="top_banner">
                <div class="top_menu">
                    <ul>
                        <li class="sel"><a href="#"><b>书店首页</a></li>
                        <li><a href="research.php"><b>书籍搜索</a></li>
                        <li><a href="regist.php"><b>用户注册</a></li>
                        <li><a href="login.php"><b>用户登录</a></li>
                        <li><a href="../admin/login.php"><b>管理登录</a></li>
                    </ul>
                </div>
            </div>

            <span class="index_img"><img src="Images/03.jpg" alt="Dan Cederholm" border="0" usemap="#Map" />
        <map name="Map" id="Map">
          <area shape="rect" coords="857,230,930,269" href="#" alt="购买 now" />
        </map>
        </span>
            <p class="index_hr"></p>

            <div class="content">
                <h1 class="h1_book_title">最新上市</h1>
                <ul>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_01.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：狂人笔记</a></p>
                            <p class="book_inline">价格：￥45</p>
                            <a class="book_buy"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_02.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：莫言论</a></p>
                            <p class="book_inline">价格：￥75</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_03.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：于丹解读诗经</a></p>
                            <p class="book_inline">价格：￥55</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/20.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：红楼梦</a></p>
                            <p class="book_inline">价格：￥40</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_05.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：唐门绝世</a></p>
                            <p class="book_inline">价格：￥38</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_06.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：狂神</a></p>
                            <p class="book_inline">价格：￥40</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_07.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：狂神</a></p>
                            <p class="book_inline">价格：￥65</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_08.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：第三种爱情</a></p>
                            <p class="book_inline">价格：￥76</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_09.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：凤歌九阙</a></p>
                            <p class="book_inline">价格：￥54</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_10.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：修行爱情</a></p>
                            <p class="book_inline">价格：￥49</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/book_11.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：来不及说爱你</a></p>
                            <p class="book_inline">价格：￥53</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                    <li>
                        <dl>
                            <dd>
                                <a href="#"><img src="Images/16.jpg" alt="book" /></a>
                            </dd>
                            <dt>
                        	<p class="book_title"><a href="#" target="_blank">书名：春秋史</a></p>
                            <p class="book_inline">价格：￥64</p>
                            <a class="book_buy" href="#" target="_blank"><a href="alert.php">购买</a>
                        </dt>
                        </dl>
                    </li>
                </ul>
            </div>
            <p class="index_hr"></p>
            <div class="content_press">
                <div class="press_porsen_01">
                    <h1>学海书店简介</h1>
                    <dl>
                        <dd><img src="Images/02.jpg" alt="person" /></dd>
                        <dt>
                    	<p class="date">简介</p>
                        <p class="book_title"><a href="#" target="_blank">山西大学商务学院</a></p>
                        <p class="book_intro">
                        学海书店是山西大学商务学院自主开发设计的网上购书网店，该书店默认快递是申通快递，请用户特别注意，如果您所在的地区没有申通快递，请与我们及时联系，我们的电话是：0351-8888888.
                        </p>
                    </dt>
                    </dl>
                </div>
                <div class="press_porsen_02">

                    <dl>
                        </br>
                        </br>
                        <dd><img src="Images/02.jpg" alt="book img" /></dd>
                        <dt>
                    	</br>
						</br>
                        <p class="book_intro">
						
                          &nbsp; &nbsp; &nbsp;学海书店主要是一些历史、名著、言情、武侠等小说类型，在以后我们店会陆续增加书籍类型以方便用户可以购买到您需要的书籍。如果您需要购买我店的书籍，请先注册登录，请确保您的注册信息正确，方便我们联系您，谢谢合作。                     </p>
                    </dt>
                    </dl>;
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div>
            底部
        </div>
    </footer>
</body>
</html>