﻿<html>
   <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="../Css/common.css">
	</head>
   <style>
      .li{
	     list-style-type:none;
	  }
	  .t1{
	     margin-left:220px;
		 margin-top:0px;
		 
	  }
   </style>
   <body>
      <div class="t1">
        <table border=1 cellspacing=0 cellpadding=0 width="798px">
		    <tr>
			   <td colspan=2 background="Images/daohang.jpg"><b>历史小说</td>
			</tr>
			<?php
			      require("conn.php");
				  $sql="select * from book where type='历史'";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query( $link,$sql);
				
				  while( $result=mysqli_fetch_array($query))
				  
				  {
			
			?>
			<tr>
			    <!-- <td height="35px" width="75"><img src="<?php  echo $result['img']; ?>" width="100px" height="85px"></td> -->
			    <td height="35px" width="75"><img src="../Images/16.jpg" width="100px" height="85px"></td>
				<td>
				    <div class="li">
				      <li>书名：<b><?php  echo $result['book_name'];  ?></b></li>
					  <li>作者：<?php  echo $result['author'];  ?></li>
					  <li>价格：<?php  echo $result['book_price'];  ?></li>
					  <li><a href="buy.php?id=<?php echo $result['id']; ?>" target="bottom"><img src="Images/bt_buy.jpg"></a><a href="car.php?id=<?php echo $result['id']  ; ?>" target="bottom"><img src="Images/car.jpg"></a></li>
				  
				    </div>
				</td>
			</tr>
			<?php
			   }
			?>
		
		</table>
		<input type="button" class="btn btn-default goBack" onclick="location.href='../index/user_admin.php'" value="返回" />
		</div>
   </body>
</html>