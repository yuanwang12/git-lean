﻿<html>
   <head>
   </head>
   <style>
      .table1{
	     margin-left:220px;
	  }
   
   </style>
   <body>
      <div class="table1">
       <table border=1 cellspacing=0 cellpadding=0  width="795px">
	        <tr>
			   <td colspan=5>我的购物车|<a href="payed.php" target="bottom">已付款</a>|<a href="no_payed.php" target="bottom">未付款</a></td>
			</tr>
			 <th>图书</th>
			 <th>价格</th>
			 <th>电话</th>
			 <th>地址</th>
			 <th>支付</th>
			 
			<?php
			      $id=$_GET['id'];
				
				  $buyer=$_COOKIE['username'];
				
				  require("conn.php");
				  $select="select * from user where username='$buyer'";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$select);
				  $result=mysqli_fetch_array($query);
				  $telephone=$result['telephone'];
				
				  
				  $address=$result['address'];
				  
				  $update="update book set buyer='$buyer',address='$address',telephone='$telephone',pay='0' where id='$id'";
				  $query=mysqli_query($link,$update);
				  $sql="select * from book  where buyer='$buyer' and pay='0'";
				  $query=mysqli_query($link,$sql);
				 
			       while($result=mysqli_fetch_array($query))
				   {
			?>
			<tr>
			     <td align="center"><img src="<?php  echo $result['img'];  ?>" width="100px" height="85px"></td>
				 <td align="center"><?php  echo  $result['book_price'];?></td>
				 <td align="center"><?php  echo  $result['telephone'];?></td>
				 <td align="center"><?php  echo  $result['address'];?></td>
			     <td align="center"><input  type="submit" value="支付" style="width:45px;height:35px" /></td>
			</tr>
	        <?php
			   }
			?>
	   </table>
     </div>
   </body>
</html>