<?php
    echo  "<script type='text/javascript'>alert('请先登录');location.href='index.php';</script>"
?>