﻿<?php
header('Content-Type: text/html; charset=utf-8');
    require("conn.php");
	$sql="select * from book ";
//	$query=mysql_query($sql);
//	$result=mysql_fetch_array($query);
$link=mysqli_connect("localhost","root","","bookshop");
$query = mysqli_query($link, $sql);
$result=mysqli_fetch_array($query);
?>

<html>
   <head>
       <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
      <title>学海书店-搜索</title>
   </head>
   <style>
    .table1{
	   margin-left:270px;
	
	}
	.table2{
	   margin-left:270px;
	   margin-top:0px;
	}
   </style>
   <body>
   <div class="table1">
        <form action="research.php" method="post">
         <table border=1 width="755px" height="200px" cellspacing=0 cellpadding=0 rows=3 cols=4>
		    <tr>
			   <td colspan=4 background="../Images/main.jpg" height="115px"></td>
			</tr>
			<tr>
			  <td colspan=4 height="15px"><b>书籍搜索|<a href="index.php" target="_self">返回首页</a></td>
			</tr>
			  <tr>
			   <td  height="15px">作者：
			    <select name="author" style="width:87px;height:25px">
				     <?php
					 require("conn.php");
	                 $sql="select * from book";
                   $link=mysqli_connect("localhost","root","","bookshop");
	                 $query=mysqli_query($link,$sql);
	                 $result=mysqli_fetch_array($query);
					    while($result=mysqli_fetch_array($query))
						{
					 ?>
					 <option><?php  echo $result['author']; ?></option>
					 <?php
					 }
					 ?>
				  </select>
			   </td>
			   <td>价格：
			      <select name="book_price1" style="width:55px;height:25px">
				      
					 <option>50</option>
					  <option>60</option>
					   <option>70</option>
					   <option>80</option>
					   <option>90</option>
					  
				 </select>
				 <img src="../Images/small.png">
			   <select name="book_price2" style="width:55px;height:25px">
				      
					 <option>60</option>
					  <option>70</option>
					   <option>80</option>
					   <option>90</option>
					   <option>100</option>
					  
				 </select>
			   </td>
			   <td >类型：
			    <select name="type" style="width:87px;height:25px">
				      
					 <option>言情</option>
					 <option>名著</option>
				     <option>历史</option>
			         <option>玄幻</option>
					 <option>武侠</option>
					
				  </select>
			   </td>
			   <td  align="center">
			     <input  type="submit" name="submit" value="搜索" style="width:55px;height:35px">
			   </td>
			</tr>
		     
		   </form> 
		 </table>
	</div>
	<?php
	       
            if(isset($_POST['submit'])&& $_POST['submit']=="搜索"){
			         require("conn.php");
					 $author=$_POST['author'];
					 $book_price1=$_POST['book_price1'];
					 $book_price2=$_POST['book_price2'];
					 $type=$_POST['type'];
					 
					 if($book_price1>$book_price2){
					    echo  "<script type='text/javascript'>alert('请重新选择价格区间！');</script>"; 
					 }
			          else{
					     $sql="select * from book where author='$author' or type='$type' or (book_price > '$book_price1' and book_price < '$book_price2') ";
					     $link=mysqli_connect("localhost","root","","bookshop");
					     $query=mysqli_query($link,$sql);
    				  }
				}

?>
              <div class="table2">
			  <form action="research.php" method="get">
	            <table border=1 cellpadding=0 cellspacing=0  width="755px" >
				     <th height="25px">书名</th>
					 <th height="25px">作者</th>
					 <th>价格</th>
				     <th>库存</th>  
					 <th>购买</th>
	    		     <?php
//					       while( $result=mysql_fetch_array($query))
                     while( $result=mysqli_fetch_array($query))
						   {
					   ?>
					   <tr>
					    
					      <td align="center"><?php echo $result['book_name']; ?></td>
					      <td align="center"><?php echo $result['author']; ?></td>
						  <td align="center"><?php echo $result['book_price']; ?></td>
						  <td align="center"><?php echo $result['book_num']; ?></td>
					      <td align="center"><input type="submit" name="submit" style="width:45px;height:25px" value="购买"></td>
						  
					   </tr>
					   <?php
					     }
					   ?>
					   
				</table>
				</form>
				</div>
			<?php
			if(isset($_GET['submit']) && $_GET['submit']=="购买"){
			          echo  "<script type='text/javascript'>alert('请先登录!');location.href='login.php';</script>"; 
			
			}
			?>
   </body>
</html>