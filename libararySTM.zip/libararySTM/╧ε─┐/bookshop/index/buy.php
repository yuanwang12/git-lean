﻿<?php
				  if(isset($_GET['submit'])){
				         $num=$_GET['num'];
						 $price=$_GET['price'];
						 $total=$num*$price;
						 
				  }    
					
?>
	<?php
			      require("conn.php");
				   $id=$_GET['id'];
				  $sql="select * from book where id='$id'";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				  $result=mysqli_fetch_array($query);
?>				  
<html>
   <head></head>
   <style>
      .li{
	     list-style-type:none;
	  }
	  .t1{
	     margin-left:220px;
		 margin-top:0px;
		 
	  }
   </style>
   <body>
      <div class="t1">
	    <form action="buy_ok.php" method="get"  >
        <table border=1 cellspacing=0 cellpadding=0 width="798px">
		    <tr>
			   <td colspan=2 background="Images/daohang.jpg"><b>支付中心</td>
			</tr>
			<th>图书</th>
			<th>书名</th>
			<th>单价</th>
			<th>数量</th>
			<th>共计</th>
		
			<?php
			      require("conn.php");
				   $id=$_GET['id'];
				  $sql="select * from book where id='$id'";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				
				  while( $result=mysqli_fetch_array($query))
				  
				  {
			
			?>
			<tr>
			  <td align="center"> <img src="<?php  echo $result['img']; ?>" width="100px" height="85px"></td>
			  <td align="center"><?php echo $result['book_name'];  ?></td>
			  <td align="center"><?php echo $result['book_price'];  ?></td>
			  <td align="center">
			    <input type="text" name="num" style="width:75px;height:25px">
				  <input type="hidden" name="id" value="<?php  echo $result['id']; ?>">
			  </td>
	          <td align="center"><input type="submit" name="submit" value="支付" style="width:45px;height:35px"></td>
			</tr>
			<?php
			   }
			?>
		
		</table>
		</form>
		</div>
   </body>
</html>