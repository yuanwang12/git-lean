<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../Css/common.css">
	<title></title>
	<style>
      .t1{
	    margin-left:220px;
	  }
  </style>
</head>
  <body>
  <!-- <div class="t1">
      <table border=1 cellspacing=0 cellpadding=0 >
	       <tr>
		    <td colspan=8><img src="Images/main.jpg"></td>
		   </tr>
		   <tr>
		   <div class="td1">
		     <td background="Images/cheng.gif" align="center"><a href="personal.php" target="bottom">个人中心</a></td><td background="Images/cheng.gif" align="center"><a href="no_payed.php" target="bottom">我的购物车</a></td>
			 <td background="Images/cheng.gif" align="center"><a href="yanqing.php" target="bottom">言情</a></td>
			 <td background="Images/cheng.gif" align="center"><a href="wuxia.php" target="bottom">武侠</a></td>
			 <td background="Images/cheng.gif" align="center"><a href="mingzhu.php" target="bottom">名著</a></td>
			 <td background="Images/cheng.gif" align="center"> <a href="lishi.php" target="bottom">历史</a></td>
			 <td background="Images/cheng.gif" align="center"> <a href="xuanhuan.php" target="bottom">玄幻</a></td>
			 <td background="Images/cheng.gif" align="center"> <a href="index.php" target="_top">退出</a></td>
			 </div>
		   </tr>
	     
	  </table>
  </div> -->
  </body>
</html>