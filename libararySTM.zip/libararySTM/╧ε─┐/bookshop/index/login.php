﻿<html>

<head>
	<META http-equiv="Content-Type" content="text/html; charset=utf-8">
	<TITLE>学海书店登录页面</TITLE>
	<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.css">
	<link rel="stylesheet" href="../Css/common.css">
	<script type="text/javascript" src="../pluging/jquery-3.3.1/jquery-3.3.1.min.js"></script>
</head>

<script type="text/javascript">
	function inputcheck() {
		if (form.username.value == "") {
			form.username.focus();
			alert("用户名不能为空！");
			return false;
		}
		if (form.password.value == "") {
			form.password.focus();
			alert("密码不能为空！");
			return false;
		}


	}
</script>
<div class="body">

	<body>
		<!-- <form name="form" onsubmit="return inputcheck();" action="login_handle.php" method="post">
			<table rows=4 cols=2 height="260px" width="550px" border=1 cellpadding="0" cellspacing="0" background="">
				<tr>
					<td colspan=2 height="100px" width="340px" align="center">
						<font size="35"><b>学海书店登录</b></font>
					</td>
				</tr>
				<tr>
					<td height="45px" align="center" width="225px"><b>用户名</b></td>
					<td><INPUT id="username" type="text" name="username" value="" size="35px"></td>
				</tr>
				<tr>
					<td height="45px" align="center"><b>密码</b></td>
					<td><INPUT id="password" type="password" name="password" value="" size="35px"></td>
				</tr>
				<tr>
					<td align="center" colspan=2><input type="button" onclick="location.href='index.php'" value="返回"
							style="width:45px;height:35px" />
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<input type="submit" name="submit" value="登录"
							style="width:45px;height:35px" /></td>
				</tr>

			</table>



		</form> -->

<form class="form-horizontal perInfor" role="form" name="form" onsubmit="return inputcheck();" action="login_handle.php" method="post">
   <div class="input-box">
		<div class="form-group">
				<label for="firstname" class="col-sm-3 control-label">用户名：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="firstname" 
							placeholder="请输入用户名" id="username" type="text" name="username" value="">
				</div>
		</div>
		<div class="form-group">
				<label for="lastname" class="col-sm-3 control-label">密码：</label>
				<div class="col-sm-7">
					<input type="text" class="form-control" id="lastname" 
							placeholder="请输入密码" id="password" type="password" name="password" value="">
				</div>
		</div>
		<div class="form-group">
				<div class="col-sm-offset-2 col-sm-12 undate-box">
					<input type="button" class="btn btn-default goBack" onclick="location.href='index.php'" value="返回" />
					<input type="submit" class="btn btn-primary updateInfo" name="submit" value="登录">
				</div>
		</div>
	 </div>
</form>
	</body>
</div>

</html>