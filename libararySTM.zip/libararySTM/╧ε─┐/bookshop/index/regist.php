﻿<html>
   <head>
      <title>学海书店-注册</title>
   </head>
   <style>
          .table1{
		     margin-top:120px;
			 margin-left:320px;
		  }
   </style>
   <script type="text/javascript">
         function inputcheck(){
		   if(form.username.value=="")
		     { 
			    form.username.focus();
				alert("用户名不能为空！");
				return false;
			    }
		   if(form.password.value=="")
		     {
		        form.password.focus();
                alert("密码不能为空！");
                return false;				
		   }
		   if(form.telephone.value=="")
		     {
		        form.telephone.focus();
                alert("电话不能为空！");
                return false;				
		   }
		   if(form.address.value=="")
		     {
		        form.address.focus();
                alert("地址不能为空！");
                return false;				
		   }
		 
		 }
</script>

   <body>
      <div  class="table1">
	     <form action="regist_handle.php" method="post" onsubmit="return inputcheck()" name="form">
           <table rows=4 cols=2 border=1 cellspacing=0 cellpadding=0 width="555" height="355px">
		     <tr>
			   <td colspan=2 align="center"><b>学海书店注册</td>
			 </tr>
			 <tr>
			   <td align="center">用户名</td>
			   <td ><input type="text" name="username" style="width:185px;height:35px" ></td>
			 </tr>
			 <tr>
			   <td align="center">密码</td>
			   <td ><input type="password" name="password" style="width:185px;height:35px"></td>
			 </tr>
			 <tr>
			   <td align="center">电话</td>
			   <td ><input type="text" name="telephone" style="width:185px;height:35px" ></td>
			 </tr>
			 <tr>
			   <td align="center">地址</td>
			   <td ><input type="text" name="address" style="width:185px;height:35px" ></td>
			 </tr>
			 <tr>
			   <td colspan=2 align="center"><input type="button" onclick="location.href='index.php'" value="返回" style="width:45px;height:35px"/>
		  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<input type="submit" name="submit" value="注册" style="width:45px;height:35px"/></td></td>
			   
			 </tr>
		     
		   </table>
		   </form>
		   </div>
   </body>
</html>