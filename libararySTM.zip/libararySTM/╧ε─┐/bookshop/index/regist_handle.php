﻿<?php
       if(isset($_POST['submit']) && $_POST['submit']=="注册" ){
	              require("conn.php");
				  $username=$_POST['username'];
				  $password=$_POST['password'];
				  $address=$_POST['address'];
				  $telephone=$_POST['telephone'];
				
				  $sql="insert  into user (username,password,telephone,address) values('$username','$password','$telephone','$address') ";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				  $rows=mysqli_affected_rows($link);
				  if($rows>0){
				      echo  "<script type='text/javascript'>alert('注册成功！');location.href='login.php';</script>";
				  }
				  else{
				     echo  "<script type='text/javascript'>alert('注册失败！');location.href='regist.php';</script>";
				  }
	   
	   }



?>