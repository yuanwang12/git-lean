﻿<?php
               if(isset($_GET['submit']) && $_GET['submit']=="支付"){
			            $id=$_GET['id'];
						$num=$_GET['num'];
						
						require("conn.php");
						$sql="select * from book where id='$id'";
						$link=mysqli_connect("localhost","root","","bookshop");
						$query=mysqli_query($link,$sql);
						$result=mysqli_fetch_array($query);
						
						$total=$num*$result['book_price'];
						
						$book_num=$result['book_num']-$num;	
						
                        $buyer=$_COOKIE['username'];
                    
                       
                        $sql="update book set buyer='$buyer',buy_num='$num',pay='1',book_num='$book_num' where id='$id'";
						mysqli_query($link,$sql);
                        if(mysqli_affected_rows($link)>0){
						       echo  "<script type='text/javascript'>alert('支付成功!');history.go(-2);</script>";
						}						
			   }



?>