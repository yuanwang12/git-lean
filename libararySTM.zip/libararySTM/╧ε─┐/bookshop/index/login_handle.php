﻿
<?php
        session_start();
       if(isset($_POST['submit'])&& $_POST['submit']=="登录"){
	            require("conn.php");
				
				$username=trim($_POST['username']);
				$password=trim($_POST['password']);
				$sql="select * from user where username='$username' and password='$password' ";
//				$query=mysql_query($sql);
//				$record=mysql_num_rows($query);
//				$result=mysql_fetch_array($query);
                $link=mysqli_connect("localhost","root","","bookshop");
                $query = mysqli_query($link, $sql);
                $record=mysqli_num_rows($query);
                $result=mysqli_fetch_array($query);

				$id=$result['id'];
				if($record)
				   {
				   setcookie("username",$username,time()+3600);
				   setcookie("password",$password,time()+3600);
				   setcookie("id",$id,time()+3600);
				   echo "<script type='text/javascript'>alert('登录成功');location.href='user_admin.php';</script>";
				    
					 
					 
	            
			       }else
				   echo  "<script type='text/javascript'>alert('用户名或密码错误，请重新填写！');location.href='login.php';</script>";
	   
	   
	   
	   
	   }







?>