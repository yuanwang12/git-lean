<?php
            $id=$_GET['id'];
			require("conn.php");
			$sql="update book set pay='1' where id='$id'";
            $link=mysqli_connect("localhost","root","","bookshop");
			$query=mysqli_query($link,$sql);
			 if(mysqli_affected_rows($link)>0){
			    echo  "<script type='text/javascript'>alert('支付成功');location.href='payed.php';</script>";
			 
			 }
?>