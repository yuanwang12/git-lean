<?php
//    $conn=mysql_connect("localhost","root","root") or die("���ݿ����Ӵ���");
//	mysql_select_db("bookshop") or die("���ݿ����Ӵ���");
//	 mysql_query("set names 'utf8' ");

/* Connect to a MySQL server  连接数据库服务器 */
$link = mysqli_connect(
    'localhost',  /* The host to connect to 连接MySQL地址 */
    'root',      /* The user to connect as 连接MySQL用户名 */
    '',  /* The password to use 连接MySQL密码 */
    'bookshop');    /* The default database to query 连接数据库名称*/
    $link=mysqli_connect("localhost","root","","bookshop");
    mysqli_query($link,"set names 'utf8' ");

if (!$link) {
    printf("Can't connect to MySQL Server. Errorcode: %s ", mysqli_connect_error());
    exit;
}

/* Close the connection 关闭连接*/
mysqli_close($link);

?>