<?php        
		?>
<form action="" method="get">

	<input type="text" name="type" width="45px">
</form>