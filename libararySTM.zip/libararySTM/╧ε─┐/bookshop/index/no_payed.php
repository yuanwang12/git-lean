﻿<html>
   <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="../Css/common.css">
   </head>
   <style>
      .table1{
	     margin-left:220px;
	  }
   
   </style>
   <body>
      <div class="table1">
	   
       <table border=1 cellspacing=0 cellpadding=0  width="800px">
	        <tr>
			   <td colspan=5>我的购物车--未付款|<a href="payed.php" target="bottom">已支付订单</a>
			</tr>
			 <th>图书</th>
			 <th>价格</th>
			 <th>电话</th>
			 <th>地址</th>
			 <th>支付</th>
			 
			<?php
			      require("conn.php");
				  $buyer=$_COOKIE['username'];
				  $sql="select * from book  where buyer='$buyer' and pay='0'";
				  $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				  while($result=mysqli_fetch_array($query))
				   {
			?>
			<tr>
			     <td align="center"><img src="<?php  echo $result['img'];  ?>" width="100px" height="85px"></td>
				 <td align="center"><?php  echo  $result['book_price'];?></td>
				 <td align="center"><?php  echo  $result['telephone'];?></td>
				 <td align="center"><?php  echo  $result['address'];?></td>
			     <td align="center"><a href="no_payed_handle.php?id=<?php echo $result['id']; ?>"><b>支付</a></td>
			</tr>
	        <?php
			   }
			?>
	   </table>
		<input type="button" class="btn btn-default goBack" onclick="javascript:history.go(-1)" value="返回" />
     </div>
   </body>
</html>