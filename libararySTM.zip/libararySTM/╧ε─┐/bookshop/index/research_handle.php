﻿<?php
            if(isset($_POST['submit'])&& $_POST['submit']=="搜索"){
			         require("conn.php");
					 $author=$_POST['author'];
					 $book_price1=$_POST['book_price1'];
					 $book_price2=$_POST['book_price2'];
					 $type=$_POST['type'];
					 if($book_price1>$book_price2){
					    echo  "<script type='text/javascript'>alert('请重新选择价格区间！');</script>"; 
					 }
			          else{
					     $sql="select * from book where auhtor='$author' or type='$type' or (book_price > '$book_price1' and book_price < '$book_price2') ";
						 $link=mysqli_connect("localhost","root","","bookshop");
						 $query=mysqli_query($link,$sql);
						 $result=mysqli_fetch_array($query);
					  }
			
			
			
			}




?>