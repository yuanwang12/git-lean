﻿<html>
   <head>
   </head>
   <style>
      .table1{
	     margin-left:220px;
	  }
   
   </style>
   <body>
      <div class="table1">
       <table border=1 cellspacing=0 cellpadding=0  width="800px">
	        <tr>
			   <td colspan=5>我的购物车--已付款|<a href="no_payed.php" target="bottom">未支付订单</a>
			</tr>
			 <th>图书</th>
			 <th>价格</th>
			 <th>电话</th>
			 <th>地址</th>
			 <th>支付</th>
			 
			<?php
			      require("conn.php");
				  $buyer=$_COOKIE['username'];
				  $sql="select * from book  where buyer='$buyer' and pay='1'";
              $link=mysqli_connect("localhost","root","","bookshop");
				  $query=mysqli_query($link,$sql);
				  while($result=mysqli_fetch_array($query))
				   {
			?>
			<tr>
			     <td align="center"><img src="<?php  echo $result['img'];  ?>" width="100px" height="85px"></td>
				 <td align="center"><?php  echo  $result['book_price'];?></td>
				 <td align="center"><?php  echo  $result['telephone'];?></td>
				 <td align="center"><?php  echo  $result['address'];?></td>
			     <td align="center"><input  type="submit" value="已支付" style="width:55px;height:35px" /></td>
			</tr>
	        <?php
			   }
			?>
	   </table>
     </div>
   </body>
</html>