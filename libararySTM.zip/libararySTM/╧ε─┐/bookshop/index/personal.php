﻿

<html>
<head>
<link rel="stylesheet" href="../pluging/bootstrap-3.3.7-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../Css/common.css">
<style>
    .table1{
	   margin-left:220px;
	   margin-top:0px;
	}
</style>
    <meta http-equiv='Content-Type; refresh' content='text/html; charset=utf-8'/>
<!--<meta http-equiv="refresh" content="10">-->
</head>

<body>
<div class="table1">
   <form action="personal_update.php" method="post">
<table  rows=4 cols=2 border=1 height="355px" width="800px" cellspacing=0  cellpadding=0>
          <tr>
		    <td colspan=2 align="center"><b>个人信息</td>
		  </tr>
		  <tr>
		    <td align="center" >用户名</td>
		    <td><input type="text" size="35px" name="username" value="<?php 
			     require("conn.php");
	            $id=$_COOKIE['id'];
	            $sql="select * from user where id='$id'";
              $link=mysqli_connect("localhost","root","","bookshop");
	            $query=mysqli_query($link,$sql);
			    $result=mysqli_fetch_array($query);
				echo $result['username'];
			?>"></td>
		  </tr>
		  <tr>
		    <td align="center">密码</td>
		    <td><input type="text" size="35px" name="password" value="<?php  
			      require("conn.php");
	            $id=$_COOKIE['id'];
	            $sql="select password from user  where id='$id'";
              $link=mysqli_connect("localhost","root","","bookshop");
	            $query=mysqli_query($link,$sql);
				$result=mysqli_fetch_array($query);
				$password=$result['password'];
				echo $password;
			?>">
			</td>
		  </tr>
		  <tr>
		    <td align="center">收货地址</td>
		    <td><input type="text" size="35px" name="address" value="<?php  
			      require("conn.php");
	            $id=$_COOKIE['id'];
	            $sql="select address from user  where id='$id'";
              $link=mysqli_connect("localhost","root","","bookshop");
	            $query=mysqli_query($link,$sql);
				$result=mysqli_fetch_array($query);
				$address=$result['address'];
				echo $address;
			?>">
			</td>
		  </tr>
		  <tr>
		    <td colspan=2 align="center" height="25px">
			<input type="button" class="btn btn-default goBack" onclick="location.href='../index/user_admin.php'" value="返回" />
			<input type="submit"  class="btn btn-primary updateInfo" name="submit" value="修改"></td>
		  </tr>
  
</table>
</form>
</div>


</body>

</html>
