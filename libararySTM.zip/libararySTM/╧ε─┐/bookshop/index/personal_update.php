﻿
<?php
   if(isset($_POST['submit']) && $_POST['submit']=="修改"){
         $username=$_POST['username'];
		 $password=$_POST['password'];
		 $address=$_POST['address'];
		 $id=$_COOKIE['id'];
		 require("conn.php");
		 
		 $sql="update user set username='$username',password='$password' ,address='$address' where id='$id'";
       $link=mysqli_connect("localhost","root","","bookshop");
		 $query=mysqli_query($link,$sql);
		 $rows=mysqli_affected_rows($link);

		 if($rows>0)
		    echo  
 			"<script type='text/javascript'>alert('修改成功！');location.href='personal.php';</script>";
        else
		    "<script type='text/javascript'>alert('修改失败！');location.href='personal.php';</script>";
   }


?>