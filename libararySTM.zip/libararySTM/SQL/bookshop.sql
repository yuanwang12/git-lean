﻿-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 04 月 02 日 07:32
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `bookshop`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `book_price` int(15) NOT NULL,
  `detail` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `book_num` int(15) NOT NULL,
  `buyer` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `buy_num` int(15) NOT NULL,
  `type` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `pay` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `book`
--

INSERT INTO `book` (`id`, `book_name`, `book_price`, `detail`, `book_num`, `buyer`, `buy_num`, `type`, `author`, `img`, `pay`, `telephone`, `address`) VALUES
(1, '平凡的世界', 45, '《你可以爱我》由最世签约作家琉玄所写的一篇关于青春', 9, 'user1', 1, '言情', '琉玄', 'Images/book_01.jpg', '1', '13488886666', '山西大学'),
(2, '雪山飞狐', 55, '《雪山飞狐》根据金庸同名小说改编，是香港导演王晶首', 20, 'user2', 0, '武侠', '金庸', 'Images/12.jpg', '1', '13488886666', '山西大学'),
(3, '岛', 66, '《岛》是英国作家维多利亚·希斯洛普（Victori', 11, '', 0, '言情', '维多利亚·希斯洛普', 'Images/dao.jpg', '0', '', ''),
(4, '笑傲江湖', 76, '2013年版《笑傲江湖》是由于正工作室与华夏视听环', 39, '', 0, '武侠', '金庸', 'Images/13.jpg', '', '', ''),
(5, '侠客行', 46, '金庸的一部武侠小说《侠客行》，初次发表于1965年', 12, 'user2', 0, '武侠', '金庸', 'Images/14.jpg', '0', '13488886666', '山西大学'),
(6, '书籍的历史', 100, '书籍的历史首先是从文字开始的，正是由于有了文字。才', 11, 'user2', 1, '历史', '王明', 'Images/15.jpg', '0', '13488886666', '山西大学'),
(8, '宋祖江山', 87, '《宋祖江山》内容简介：宋太祖是中国历史中有代表性的', 20, 'user3', 0, '历史', '宋文', 'Images/17.jpg', '0', '13411111111', '山西大学'),
(9, '大变革时代', 77, '强弩之末的晚清与百废待兴的民国，经济大转型、军事大', 21, 'user2', 0, '历史', '李曲', 'Images/19.jpg', '0', '13488886666', '山西大学'),
(10, '红楼梦', 65, '《红楼梦》，中国古典四大名著之首，清代作家曹雪芹创', 22, 'user2', 0, '名著', '曹雪芹', 'Images/20.jpg', '1', '13488886666', '山西大学'),
(11, '钢铁是怎样炼成的', 65, '《钢铁是怎样炼成的》是前苏联作家尼古拉·奥斯特洛夫', 10, '', 0, '名著', '奥斯特洛夫斯基', 'Images/21.jpg', '', '', ''),
(12, '挪威的森林', 88, '《挪威的森林》是日本作家村上春树于1987年所著的', 50, '', 0, '名著', '村上春树', 'Images/22.jpg', '', '', ''),
(13, '骆驼祥子', 35, '《骆驼祥子》是老舍的代表作之一，以现实主义的笔法与', 40, '', 0, '名著', '老舍', 'Images/23.jpg', '', '', ''),
(14, '西游记', 88, '《西游记》是中国古典四大名著之一，是由明代小说家吴', 40, '', 0, '名著', '吴承恩', 'Images/25.jpg', '', '', ''),
(15, '水浒传', 55, '《水浒传》，是中国四大名著之一，全书描写北宋末年以', 33, '', 0, '名著', '施耐庵', 'Images/26.jpg', '', '', ''),
(16, '三国演义', 55, '《三国演义》是中国古典四大名著之一。元末明初小说家', 22, '', 0, '名著', '罗贯中', 'Images/27.jpg', '0', '', ''),
(17, '夜郎', 67, '夜郎，是秦汉时期在西南地区由少数民族建立的国家，是', 20, 'user1', 0, '玄幻', '白玉郎', 'Images/book_07.jpg', '0', '13466668888', '山西大学'),
(18, '时间简史', 56, '这本书是霍金先生对于时间、空间、宇宙的探索', 22, '', 0, '名著', '霍金', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `password` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `password`, `username`, `address`, `telephone`) VALUES
(4, 'admin', 'admin', '山西大学', '13466668888'),
(5, '222', 'user2', '山西大学', '13488886666'),
(6, '333', 'user3', '山西大学', '13411111111');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
